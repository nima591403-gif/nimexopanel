import React from "react";
import ReactDOM from "react-dom/client";
import { createBrowserRouter, Navigate, RouterProvider } from "react-router-dom";

import Layout from "./components/Layout";
import { ToastProvider } from "./components/ui";
import { getToken } from "./lib/api";
import Certificates from "./pages/Certificates";
import Connections from "./pages/Connections";
import Dashboard from "./pages/Dashboard";
import Groups from "./pages/Groups";
import Login from "./pages/Login";
import Logs from "./pages/Logs";
import Migrate from "./pages/Migrate";
import Migration from "./pages/Migration";
import Nodes from "./pages/Nodes";
import Portal from "./pages/Portal";
import Protocols from "./pages/Protocols";
import Resellers from "./pages/Resellers";
import Settings from "./pages/Settings";
import UserPage from "./pages/UserPage";
import Users from "./pages/Users";
import "./styles/index.css";

function Guard({ children }: { children: React.ReactNode }) {
  if (!getToken()) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

const router = createBrowserRouter([
  { path: "/login", element: <Login /> },
  { path: "/u/:subId", element: <UserPage /> },
  { path: "/migrate", element: <Migrate /> },
  { path: "/portal", element: <Portal /> },
  {
    path: "/",
    element: (
      <Guard>
        <Layout />
      </Guard>
    ),
    children: [
      { index: true, element: <Dashboard /> },
      { path: "users", element: <Users /> },
      { path: "groups", element: <Groups /> },
      { path: "connections", element: <Connections /> },
      { path: "nodes", element: <Nodes /> },
      { path: "protocols", element: <Protocols /> },
      { path: "certificates", element: <Certificates /> },
      { path: "resellers", element: <Resellers /> },
      { path: "migration", element: <Migration /> },
      { path: "logs", element: <Logs /> },
      { path: "settings", element: <Settings /> },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ToastProvider>
      <RouterProvider router={router} />
    </ToastProvider>
  </React.StrictMode>,
);
