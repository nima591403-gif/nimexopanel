import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import {
  AccountHeader,
  AccountSummary,
  ProtocolCards,
  SubscriptionCard,
} from "../components/AccountView";
import { Spinner } from "../components/ui";
import { api } from "../lib/api";
import type { SubInfo } from "../lib/types";

export default function UserPage() {
  const { subId } = useParams();
  const [info, setInfo] = useState<SubInfo | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get<SubInfo>(`/api/sub/${subId}/info`)
      .then(setInfo)
      .catch((e) => setError(e.message));
  }, [subId]);

  if (error)
    return (
      <div className="grid min-h-screen place-items-center p-6 text-center">
        <div className="card max-w-sm">
          <p className="mb-2 text-4xl">🔎</p>
          <h1 className="mb-1 font-bold">اشتراک پیدا نشد</h1>
          <p className="text-xs text-ink-400">{error}</p>
          <div className="mt-4 flex justify-center gap-2">
            <a className="btn-ghost inline-flex" href="/portal">
              ورود با نام کاربری
            </a>
            <a className="btn-ghost inline-flex" href="/migrate">
              انتقال حساب از پنل قبلی
            </a>
          </div>
        </div>
      </div>
    );

  if (!info)
    return (
      <div className="grid min-h-screen place-items-center">
        <Spinner className="h-6 w-6 text-brand-400" />
      </div>
    );

  return (
    <div className="mx-auto max-w-2xl space-y-5 p-4 pb-16">
      <AccountHeader info={info} />
      <AccountSummary info={info} />
      <SubscriptionCard info={info} />
      <ProtocolCards info={info} />
      <footer className="pt-4 text-center text-[11px] text-ink-600">
        © {new Date().getFullYear()} {info.brand} — تمامی حقوق محفوظ است
      </footer>
    </div>
  );
}
