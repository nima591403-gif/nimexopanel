import { useEffect } from "react";
import { Navigate } from "react-router-dom";

/**
 * The portal now migrates an old account on the first lookup, so there is one
 * link to hand out instead of two pages that do almost the same thing.
 */
export default function Migrate() {
  useEffect(() => {
    document.title = "انتقال حساب";
  }, []);
  return <Navigate to="/portal" replace />;
}
