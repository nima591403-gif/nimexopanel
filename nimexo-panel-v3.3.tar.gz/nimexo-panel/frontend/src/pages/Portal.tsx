import { useEffect, useState } from "react";

import {
  AccountHeader,
  AccountSummary,
  ProtocolCards,
  SubscriptionCard,
} from "../components/AccountView";
import { CopyButton, Spinner, useToast } from "../components/ui";
import { api } from "../lib/api";
import type { SubInfo } from "../lib/types";

interface PortalConfig {
  brand: string;
  enabled: boolean;
  note: string;
  telegram: boolean;
  support: string;
  migrate: boolean;
}

type Account = SubInfo & {
  telegram_id?: string;
  telegram_enabled?: boolean;
  page_url?: string;
  /** true the first time an old-panel account is moved across */
  migrated?: boolean;
};

const REMEMBER_KEY = "nimexo:last-username";

/** Telegram id capture: reminders before the plan runs out + admin notices. */
function TelegramCard({
  username,
  current,
  onSaved,
}: {
  username: string;
  current: string;
  onSaved: (id: string) => void;
}) {
  const toast = useToast();
  const [value, setValue] = useState(current);
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      const res = await api.post<{ telegram_id: string; message: string }>(
        "/api/portal/telegram",
        { username, telegram_id: value.trim() },
      );
      onSaved(res.telegram_id);
      toast(res.message);
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card">
      <h2 className="mb-2 text-sm font-semibold">یادآوری تلگرام</h2>
      <p className="mb-3 text-[11px] leading-6 text-ink-400">
        آی‌دی عددی تلگرامت را وارد کن تا چند روز قبل از تمام‌شدن حجم یا زمان
        اشتراک، همان‌جا خبرت کنیم. آی‌دی عددی را از ربات{" "}
        <span className="font-mono" dir="ltr">
          @userinfobot
        </span>{" "}
        بگیر و اول ربات ما را هم یک‌بار استارت کن.
      </p>
      <div className="flex gap-2">
        <input
          className="input font-mono"
          dir="ltr"
          inputMode="numeric"
          placeholder="123456789"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
        <button className="btn-primary shrink-0" onClick={save} disabled={busy}>
          {busy ? <Spinner /> : current ? "بروزرسانی" : "ثبت"}
        </button>
      </div>
      {current && (
        <p className="mt-2 text-[11px] text-emerald-400">
          ● یادآوری برای آی‌دی {current} فعال است
        </p>
      )}
    </section>
  );
}

export default function Portal() {
  const toast = useToast();
  const [config, setConfig] = useState<PortalConfig | null>(null);
  const [username, setUsername] = useState("");
  const [account, setAccount] = useState<Account | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get<PortalConfig>("/api/portal/config")
      .then(setConfig)
      .catch(() => setConfig(null));
    try {
      const saved = localStorage.getItem(REMEMBER_KEY);
      if (saved) setUsername(saved);
    } catch {
      /* private mode */
    }
  }, []);

  const lookup = async (name?: string) => {
    const value = (name ?? username).trim();
    if (!value) return toast("نام کاربری را وارد کن", "error");
    setBusy(true);
    setError("");
    try {
      const res = await api.post<Account>("/api/portal/lookup", { username: value });
      setAccount(res);
      try {
        localStorage.setItem(REMEMBER_KEY, value);
      } catch {
        /* private mode */
      }
    } catch (e) {
      setAccount(null);
      setError(e instanceof Error ? e.message : "خطا");
    } finally {
      setBusy(false);
    }
  };

  if (config && !config.enabled)
    return (
      <div className="grid min-h-screen place-items-center p-6 text-center">
        <div className="card max-w-sm">
          <h1 className="font-bold">این صفحه فعلاً در دسترس نیست</h1>
        </div>
      </div>
    );

  return (
    <div className="mx-auto max-w-2xl space-y-5 p-4 pb-16">
      {!account ? (
        <>
          <header className="pt-10 text-center">
            <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-brand-400 text-3xl font-bold text-white shadow-glow">
              N
            </span>
            <h1 className="text-xl font-bold">{config?.brand || "پنل کاربری"}</h1>
            <p className="mt-2 text-xs leading-6 text-ink-400">
              نام کاربری‌ات را وارد کن تا حجم مصرفی، زمان باقی‌مانده، لینک اشتراک و
              کانفیگ همه‌ی پروتکل‌ها را ببینی.
              {config?.migrate && (
                <>
                  <br />
                  اگر هنوز روی پنل قبلی هستی، همین‌جا حسابت با همان حجم و زمان
                  باقی‌مانده به‌صورت خودکار منتقل می‌شود.
                </>
              )}
            </p>
          </header>

          <section className="card">
            <div className="flex gap-2">
              <input
                className="input"
                dir="ltr"
                autoFocus
                placeholder="نام کاربری"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && lookup()}
              />
              <button
                className="btn-primary shrink-0"
                onClick={() => lookup()}
                disabled={busy}
              >
                {busy ? <Spinner /> : "نمایش اطلاعات"}
              </button>
            </div>
            {error && (
              <p className="mt-3 rounded-lg bg-rose-500/10 px-3 py-2 text-[11px] leading-5 text-rose-300">
                {error}
              </p>
            )}
            {config?.note && (
              <p className="mt-3 rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-6 text-ink-300">
                {config.note}
              </p>
            )}
          </section>

          <p className="text-center text-[11px] text-ink-500">
            {config?.support && (
              <>
                <a
                  className="text-brand-300 underline"
                  href={`https://t.me/${config.support.replace("@", "")}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  پشتیبانی
                </a>
              </>
            )}
          </p>
        </>
      ) : (
        <>
          <div className="flex items-center justify-between pt-4">
            <button
              className="btn-ghost px-3 py-1.5 text-xs"
              onClick={() => {
                setAccount(null);
                setError("");
              }}
            >
              ← حساب دیگر
            </button>
            <button
              className="btn-ghost px-3 py-1.5 text-xs"
              onClick={() => lookup(account.username)}
              disabled={busy}
            >
              {busy ? <Spinner /> : "بروزرسانی"}
            </button>
          </div>

          {account.migrated && (
            <p className="rounded-xl bg-emerald-500/15 px-4 py-3 text-center text-sm leading-6 text-emerald-300">
              حسابت با موفقیت به پنل جدید منتقل شد ✅
              <span className="mt-1 block text-[11px] text-emerald-200/80">
                لینک اشتراک و کانفیگ‌های زیر جدید هستند — لینک قبلی را از برنامه‌ات
                حذف کن و این را جایگزین کن.
              </span>
            </p>
          )}

          <AccountHeader info={account} />
          <AccountSummary info={account} />
          <SubscriptionCard info={account} />

          {account.telegram_enabled && (
            <TelegramCard
              username={account.username}
              current={account.telegram_id || ""}
              onSaved={(id) => setAccount({ ...account, telegram_id: id })}
            />
          )}

          <ProtocolCards info={account} />

          {account.page_url && (
            <section className="card">
              <h2 className="mb-2 text-sm font-semibold">صفحه شخصی</h2>
              <p className="mb-3 text-[11px] text-ink-400">
                این آدرس مخصوص حساب توست؛ ذخیره‌اش کن تا دفعه بعد بدون وارد کردن نام
                کاربری باز شود.
              </p>
              <div className="flex gap-2">
                <input
                  className="input font-mono text-[11px]"
                  readOnly
                  dir="ltr"
                  value={account.page_url}
                />
                <CopyButton value={account.page_url} />
              </div>
            </section>
          )}

          <footer className="pt-4 text-center text-[11px] text-ink-600">
            © {new Date().getFullYear()} {account.brand} — تمامی حقوق محفوظ است
          </footer>
        </>
      )}
    </div>
  );
}
