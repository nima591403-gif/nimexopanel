import { useEffect, useState } from "react";

import { Card, Chip, Field, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import { duration } from "../lib/format";

interface SystemInfo {
  brand: string;
  version: string;
  python: string;
  platform: string;
  timezone: string;
  sub_base_url: string;
  uptime: number;
}

interface AdminRow {
  id: number;
  username: string;
  role: string;
  is_active: boolean;
}

interface PanelSettings {
  brand_name: string;
  panel_domain: string;
  panel_public_url: string;
  sub_domain: string;
  sub_path: string;
  sub_port: number;
  sub_https: boolean | null;
  sub_profile_title: string;
  sub_base_url: string;
  page_base_url: string;
  client_domain: string;
  portal_enabled: boolean;
  portal_note: string;
  telegram_bot_token: string;
  telegram_support: string;
  notify_days_before: number;
  notify_traffic_percent: number;
  migrate_enabled: boolean;
  migrate_group_id: number;
}

interface GroupRow {
  id: number;
  name: string;
  title: string;
}

interface TelegramStatus {
  configured: boolean;
  ok: boolean;
  detail: string;
  subscribers: number;
}

export default function Settings() {
  const toast = useToast();
  const [info, setInfo] = useState<SystemInfo | null>(null);
  const [admins, setAdmins] = useState<AdminRow[]>([]);
  const [panel, setPanel] = useState<PanelSettings | null>(null);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);
  const [tg, setTg] = useState<TelegramStatus | null>(null);
  const [broadcast, setBroadcast] = useState("");
  const [testId, setTestId] = useState("");
  const [sending, setSending] = useState(false);
  const [groups, setGroups] = useState<GroupRow[]>([]);

  const loadPanel = () =>
    api.get<PanelSettings>("/api/panel-settings").then(setPanel).catch(() => {});

  useEffect(() => {
    api.get<SystemInfo>("/api/system/info").then(setInfo).catch(() => {});
    api.get<AdminRow[]>("/api/admins").then(setAdmins).catch(() => {});
    loadPanel();
    loadTelegram();
    api.get<GroupRow[]>("/api/groups").then(setGroups).catch(() => {});
  }, []);

  const loadTelegram = () =>
    api.get<TelegramStatus>("/api/telegram/status").then(setTg).catch(() => setTg(null));

  const sendBroadcast = async (test: boolean) => {
    if (!broadcast.trim()) return toast("متن پیام خالی است", "error");
    if (!test && !confirm("این پیام برای همه کاربرانی که آی‌دی تلگرام ثبت کرده‌اند ارسال شود؟"))
      return;
    setSending(true);
    try {
      const res = await api.post<{ sent: number; errors: string[] }>(
        "/api/telegram/broadcast",
        {
          text: broadcast,
          only_active: false,
          test_chat_id: test ? testId.trim() : "",
        },
      );
      toast(
        res.sent
          ? `${res.sent} پیام ارسال شد`
          : `ارسال نشد: ${res.errors[0] || "خطای نامشخص"}`,
        res.sent ? "ok" : "error",
      );
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSending(false);
    }
  };

  const savePanel = async () => {
    if (!panel) return;
    setBusy(true);
    try {
      const saved = await api.patchPut<PanelSettings>("/api/panel-settings", {
        brand_name: panel.brand_name,
        panel_domain: panel.panel_domain,
        panel_public_url: panel.panel_public_url,
        sub_domain: panel.sub_domain,
        sub_path: panel.sub_path,
        sub_port: Number(panel.sub_port),
        sub_https: panel.sub_https,
        sub_profile_title: panel.sub_profile_title,
        client_domain: panel.client_domain,
        portal_enabled: panel.portal_enabled,
        portal_note: panel.portal_note,
        telegram_bot_token: panel.telegram_bot_token,
        telegram_support: panel.telegram_support,
        notify_days_before: Number(panel.notify_days_before),
        notify_traffic_percent: Number(panel.notify_traffic_percent),
        migrate_enabled: panel.migrate_enabled,
        migrate_group_id: Number(panel.migrate_group_id),
      });
      setPanel(saved);
      toast("ذخیره شد — لینک‌های جدید از همین آدرس ساخته می‌شوند");
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const changePassword = async () => {
    setBusy(true);
    try {
      await api.post("/api/auth/change-password", {
        current_password: current,
        new_password: next,
      });
      toast("گذرواژه تغییر کرد");
      setCurrent("");
      setNext("");
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const maintenance = async (path: string, label: string) => {
    setBusy(true);
    try {
      await api.post(`/api/system/${path}`);
      toast(`${label} انجام شد`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">تنظیمات</h1>
        <p className="mt-1 text-xs text-ink-400">اطلاعات پنل، حساب مدیریت و عملیات نگهداری</p>
      </div>

      <Card
        title="دامنه و لینک اشتراک"
        subtitle="این مقادیر تعیین می‌کنند لینک کاربران با چه آدرسی ساخته شود"
      >
        {!panel ? (
          <Spinner />
        ) : (
          <>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="نام برند">
                <input
                  className="input"
                  value={panel.brand_name}
                  onChange={(e) => setPanel({ ...panel, brand_name: e.target.value })}
                />
              </Field>
              <Field label="دامنه پنل" hint="برای صفحه‌ی کاربر و مستندات">
                <input
                  className="input font-mono"
                  dir="ltr"
                  value={panel.panel_domain}
                  onChange={(e) => setPanel({ ...panel, panel_domain: e.target.value })}
                />
              </Field>
              <Field label="آدرس عمومی پنل" hint="مثلاً https://panel.example.com:2067">
                <input
                  className="input font-mono text-[11px]"
                  dir="ltr"
                  value={panel.panel_public_url}
                  onChange={(e) =>
                    setPanel({ ...panel, panel_public_url: e.target.value })
                  }
                />
              </Field>
              <Field label="دامنه لینک اشتراک" hint="می‌تواند دامنه‌ی سرور ایران باشد">
                <input
                  className="input font-mono"
                  dir="ltr"
                  value={panel.sub_domain}
                  onChange={(e) => setPanel({ ...panel, sub_domain: e.target.value })}
                />
              </Field>
              <Field label="پورت لینک اشتراک" hint="مثلاً ۲۰۹۷">
                <input
                  type="number"
                  className="input"
                  value={panel.sub_port}
                  onChange={(e) => setPanel({ ...panel, sub_port: Number(e.target.value) })}
                />
              </Field>
              <Field label="مسیر لینک" hint="پیش‌فرض sub">
                <input
                  className="input font-mono"
                  dir="ltr"
                  value={panel.sub_path}
                  onChange={(e) => setPanel({ ...panel, sub_path: e.target.value })}
                />
              </Field>
              <Field label="عنوان پروفایل در کلاینت">
                <input
                  className="input"
                  value={panel.sub_profile_title}
                  onChange={(e) =>
                    setPanel({ ...panel, sub_profile_title: e.target.value })
                  }
                />
              </Field>
              <div className="flex items-end">
                <Toggle
                  checked={panel.sub_https === true}
                  onChange={(v) => setPanel({ ...panel, sub_https: v })}
                  label="لینک اشتراک با https"
                />
              </div>
              <Field
                label="دامنه پیش‌فرض کانفیگ کاربران"
                hint="هر نودی که «آدرس عمومی» نداشته باشد از این استفاده می‌کند — همین باعث می‌شود آی‌پی سرور در لینک‌ها دیده نشود"
                className="sm:col-span-2"
              >
                <input
                  className="input font-mono"
                  dir="ltr"
                  placeholder="مثلاً de1.example.com"
                  value={panel.client_domain}
                  onChange={(e) => setPanel({ ...panel, client_domain: e.target.value })}
                />
              </Field>
            </div>

            <p className="mt-4 rounded-lg bg-white/5 px-3 py-2 font-mono text-[11px] text-ink-300" dir="ltr">
              {panel.sub_base_url}/&lt;sub_id&gt;
            </p>
            <p className="mt-2 text-[11px] leading-5 text-ink-500">
              پورتی که خود پنل روی آن گوش می‌دهد از فایل{" "}
              <span className="font-mono">/opt/nimexo/.env</span> خوانده می‌شود
              (<span className="font-mono">PORT</span> و{" "}
              <span className="font-mono">SUB_PORT</span>). بعد از تغییر آن‌ها یک‌بار
              <span className="font-mono"> systemctl restart nimexo-panel </span>
              لازم است.
            </p>

            <button className="btn-primary mt-4" onClick={savePanel} disabled={busy}>
              {busy ? <Spinner /> : "ذخیره"}
            </button>
          </>
        )}
      </Card>

      {panel && (
        <Card
          title="صفحه کاربران"
          subtitle="کاربر با وارد کردن نام کاربری، حجم و زمان و کانفیگ‌هایش را می‌بیند"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="flex items-end">
              <Toggle
                checked={panel.portal_enabled}
                onChange={(v) => setPanel({ ...panel, portal_enabled: v })}
                label="صفحه کاربران فعال باشد"
              />
            </div>
            <Field label="آی‌دی پشتیبانی در تلگرام" hint="مثلاً nimexo_support">
              <input
                className="input font-mono"
                dir="ltr"
                value={panel.telegram_support}
                onChange={(e) => setPanel({ ...panel, telegram_support: e.target.value })}
              />
            </Field>
            <div className="flex items-end">
              <Toggle
                checked={panel.migrate_enabled}
                onChange={(v) => setPanel({ ...panel, migrate_enabled: v })}
                label="انتقال خودکار از پنل قبلی"
              />
            </div>
            <Field
              label="پلن کاربران منتقل‌شده"
              hint="فقط تعیین می‌کند به کدام سرورها و پروتکل‌ها وصل شوند؛ حجم و زمانشان از پنل قبلی می‌آید"
            >
              <select
                className="input"
                value={panel.migrate_group_id}
                onChange={(e) =>
                  setPanel({ ...panel, migrate_group_id: Number(e.target.value) })
                }
              >
                <option value={0}>— بدون پلن (فقط اینباندهای پیش‌فرض) —</option>
                {groups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.title || g.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="متن راهنما در صفحه کاربران" className="sm:col-span-2">
              <textarea
                className="input h-20"
                value={panel.portal_note}
                onChange={(e) => setPanel({ ...panel, portal_note: e.target.value })}
              />
            </Field>
          </div>
          <p className="mt-3 rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-6 text-ink-300">
            همین یک آدرس را برای همه بفرست — کاربر قدیمی با وارد کردن نام کاربری
            خودکار منتقل می‌شود و کاربر جدید فقط اطلاعاتش را می‌بیند:
            <span className="mt-1 block font-mono text-brand-200" dir="ltr">
              {panel.page_base_url}/portal
            </span>
          </p>
          <button className="btn-primary mt-4" onClick={savePanel} disabled={busy}>
            {busy ? <Spinner /> : "ذخیره"}
          </button>
        </Card>
      )}

      {panel && (
        <Card title="تلگرام" subtitle="یادآوری اتمام حجم/زمان و ارسال پیام همگانی">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field
              label="توکن ربات"
              hint="از @BotFather بگیر — بدون آن یادآوری و پیام همگانی کار نمی‌کند"
              className="sm:col-span-2"
            >
              <div className="flex gap-2">
                <input
                  className="input font-mono text-[11px]"
                  dir="ltr"
                  type="password"
                  value={panel.telegram_bot_token}
                  onChange={(e) =>
                    setPanel({ ...panel, telegram_bot_token: e.target.value })
                  }
                />
                <button
                  className="btn-ghost shrink-0 text-xs"
                  onClick={async () => {
                    await savePanel();
                    loadTelegram();
                  }}
                  disabled={busy}
                >
                  ذخیره و تست
                </button>
              </div>
            </Field>
            <Field label="چند روز قبل از انقضا یادآوری شود">
              <input
                type="number"
                className="input"
                value={panel.notify_days_before}
                onChange={(e) =>
                  setPanel({ ...panel, notify_days_before: Number(e.target.value) })
                }
              />
            </Field>
            <Field label="در چند درصد مصرف حجم یادآوری شود">
              <input
                type="number"
                className="input"
                value={panel.notify_traffic_percent}
                onChange={(e) =>
                  setPanel({ ...panel, notify_traffic_percent: Number(e.target.value) })
                }
              />
            </Field>
          </div>

          {tg && (
            <p className="mt-3 text-[11px] text-ink-400">
              {tg.ok ? (
                <span className="text-emerald-400">● ربات {tg.detail} متصل است</span>
              ) : (
                <span className="text-amber-300">● {tg.detail || "ربات تنظیم نشده"}</span>
              )}
              {" · "}
              {tg.subscribers} کاربر آی‌دی ثبت کرده‌اند
            </p>
          )}

          <div className="mt-4 border-t border-white/5 pt-4">
            <Field label="پیام همگانی" hint="برای همه کاربرانی که آی‌دی تلگرام ثبت کرده‌اند">
              <textarea
                className="input h-24"
                value={broadcast}
                onChange={(e) => setBroadcast(e.target.value)}
                placeholder="مثلاً: سرور جدید آلمان اضافه شد، لینک اشتراک را یک‌بار بروزرسانی کنید."
              />
            </Field>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <input
                className="input max-w-[200px] font-mono"
                dir="ltr"
                placeholder="آی‌دی خودت برای تست"
                value={testId}
                onChange={(e) => setTestId(e.target.value)}
              />
              <button
                className="btn-ghost text-xs"
                onClick={() => sendBroadcast(true)}
                disabled={sending || !testId.trim()}
              >
                ارسال آزمایشی
              </button>
              <button
                className="btn-primary"
                onClick={() => sendBroadcast(false)}
                disabled={sending}
              >
                {sending ? <Spinner /> : "ارسال به همه"}
              </button>
            </div>
          </div>
        </Card>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="اطلاعات پنل">
          {info ? (
            <dl className="space-y-2 text-sm">
              <Row k="نسخه" v={info.version} />
              <Row k="پایتون" v={info.python} />
              <Row k="سیستم" v={<span className="text-xs">{info.platform}</span>} />
              <Row k="منطقه زمانی" v={info.timezone} />
              <Row k="زمان کارکرد" v={duration(info.uptime)} />
              <Row
                k="آدرس پایه‌ی اشتراک"
                v={<code className="text-[11px]">{info.sub_base_url}</code>}
              />
            </dl>
          ) : (
            <Spinner />
          )}
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("sync-all", "همگام‌سازی همه نودها")}
            >
              همگام‌سازی همه نودها
            </button>
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("collect", "خواندن آمار")}
            >
              خواندن آمار ترافیک
            </button>
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("enforce", "بررسی محدودیت‌ها")}
            >
              بررسی انقضا و حجم
            </button>
            <a className="btn-ghost text-xs" href="/api/docs" target="_blank" rel="noreferrer">
              مستندات API
            </a>
          </div>
        </Card>

        <Card title="تغییر گذرواژه">
          <div className="space-y-3">
            <Field label="گذرواژه فعلی">
              <input
                type="password"
                className="input"
                value={current}
                onChange={(e) => setCurrent(e.target.value)}
              />
            </Field>
            <Field label="گذرواژه جدید">
              <input
                type="password"
                className="input"
                value={next}
                onChange={(e) => setNext(e.target.value)}
              />
            </Field>
            <button className="btn-primary" onClick={changePassword} disabled={busy || !next}>
              {busy ? <Spinner /> : "ذخیره"}
            </button>
          </div>
        </Card>
      </div>

      <Card title="مدیران" subtitle="فقط مدیر ارشد می‌تواند مدیران را ببیند و تغییر دهد">
        {admins.length ? (
          <div className="space-y-2">
            {admins.map((a) => (
              <div
                key={a.id}
                className="flex items-center justify-between rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
              >
                <span className="text-sm">{a.username}</span>
                <div className="flex gap-2">
                  <Chip tone="brand">
                    {a.role === "sudo" ? "مدیر ارشد" : a.role === "reseller" ? "نماینده" : "مدیر"}
                  </Chip>
                  <Chip tone={a.is_active ? "green" : "default"}>
                    {a.is_active ? "فعال" : "غیرفعال"}
                  </Chip>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-ink-500">
            دسترسی مدیر ارشد لازم است یا هنوز مدیری ثبت نشده.
          </p>
        )}
      </Card>
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between border-b border-white/5 pb-2">
      <dt className="text-ink-400">{k}</dt>
      <dd>{v}</dd>
    </div>
  );
}
