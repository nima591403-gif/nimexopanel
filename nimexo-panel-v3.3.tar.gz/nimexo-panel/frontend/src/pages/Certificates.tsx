import { useEffect, useState } from "react";

import { Card, Chip, Empty, Field, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import type { Inbound, Node } from "../lib/types";

interface NodeCerts {
  node_id: number;
  node: string;
  certbot?: boolean;
  error: string;
  certs: { domain: string; cert: string; key: string; expires: string; self_signed?: boolean }[];
}

interface Suggestion {
  domain: string;
  why: string;
  node_id: number;
}

/** node_id 0 is the panel's own machine, where the subscription link lives. */
const PANEL_NODE = 0;

export default function Certificates() {
  const toast = useToast();
  const [rows, setRows] = useState<NodeCerts[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const [nodeId, setNodeId] = useState<number>(PANEL_NODE);
  const [domain, setDomain] = useState("");
  const [email, setEmail] = useState("");
  const [method, setMethod] = useState<"http" | "cloudflare">("cloudflare");
  const [cfToken, setCfToken] = useState("");
  const [staging, setStaging] = useState(false);
  const [applyTo, setApplyTo] = useState<number | "">("");
  const [setNodeAddress, setSetNodeAddress] = useState(true);
  const [applyAllTls, setApplyAllTls] = useState(true);
  const [useForSub, setUseForSub] = useState(false);
  const [result, setResult] = useState<string>("");

  const load = () => {
    setLoading(true);
    api
      .get<NodeCerts[]>("/api/certificates")
      .then(setRows)
      .catch((e) => toast(e.message, "error"))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    api.get<Node[]>("/api/nodes").then(setNodes);
    api.get<Inbound[]>("/api/inbounds").then(setInbounds).catch(() => {});
    api
      .get<Suggestion[]>("/api/certificates/suggestions")
      .then((s) => {
        setSuggestions(s);
        if (s.length && !domain) setDomain(s[0].domain);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const issue = async () => {
    if (!domain.trim()) return toast("دامنه لازم است", "error");
    setBusy(true);
    setResult("");
    try {
      const res = await api.post<{
        domain: string;
        cert: string;
        expires: string;
        applied_to?: string;
        applied_to_all?: string[];
        node_address?: string;
        subscription?: string;
      }>("/api/certificates/issue", {
        node_id: nodeId,
        domain: domain.trim(),
        email,
        method,
        cf_token: cfToken,
        staging,
        apply_to_inbound_id: applyTo || null,
        apply_to_all_tls: applyAllTls,
        set_node_address: nodeId !== PANEL_NODE && setNodeAddress,
        use_for_subscription: nodeId === PANEL_NODE && useForSub,
      });
      setResult(
        [
          `گواهی ${res.domain} صادر شد — انقضا: ${res.expires}`,
          res.applied_to ? `روی اینباند ${res.applied_to} اعمال شد` : "",
          res.applied_to_all?.length
            ? `روی همه اینباندهای TLS اعمال شد: ${res.applied_to_all.join("، ")}`
            : "",
          res.node_address ? `آدرس عمومی نود روی ${res.node_address} تنظیم شد` : "",
          res.subscription || "",
        ]
          .filter(Boolean)
          .join(" · "),
      );
      toast("گواهی صادر شد");
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
      setResult(e instanceof Error ? e.message : "");
    } finally {
      setBusy(false);
    }
  };

  const selfSign = async () => {
    if (!domain.trim()) return toast("دامنه (یا هر نامی) لازم است", "error");
    setBusy(true);
    try {
      const res = await api.post<{ domain: string; cert: string }>(
        "/api/certificates/self-signed",
        {
          node_id: nodeId,
          domain: domain.trim(),
          apply_to_inbound_id: applyTo || null,
          apply_to_all_tls: applyAllTls,
        },
      );
      setResult(`گواهی خودامضا برای ${res.domain} ساخته شد — ${res.cert}`);
      toast("گواهی خودامضا ساخته شد");
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const tlsInbounds = inbounds.filter((i) => i.core === "xray" && i.security === "tls");

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">گواهی‌ها</h1>
        <p className="mt-1 text-xs leading-6 text-ink-400">
          گواهی رایگان Let's Encrypt برای دامنه‌ات — روی هر نود (برای اینباندهای TLS)
          یا روی خودِ سرور پنل (برای اینکه لینک اشتراک با https و دامنه باز شود).
        </p>
      </div>

      <Card title="صدور گواهی جدید">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="کجا صادر شود؟">
            <select
              className="input"
              value={nodeId}
              onChange={(e) => setNodeId(Number(e.target.value))}
            >
              <option value={PANEL_NODE}>خود پنل (این سرور) — برای لینک اشتراک</option>
              {nodes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.country ? `${n.country} ` : ""}
                  {n.name}
                </option>
              ))}
            </select>
          </Field>
          <Field
            label="دامنه"
            hint="باید به آی‌پی همان سرور اشاره کند. دامنه‌های شناخته‌شده در فهرست زیر هستند."
          >
            <input
              className="input font-mono"
              dir="ltr"
              list="known-domains"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
            />
            <datalist id="known-domains">
              {suggestions.map((s) => (
                <option key={s.domain} value={s.domain}>
                  {s.why}
                </option>
              ))}
            </datalist>
          </Field>

          {suggestions.length > 0 && (
            <div className="sm:col-span-2 flex flex-wrap gap-2">
              {suggestions.map((s) => (
                <button
                  key={s.domain}
                  type="button"
                  onClick={() => setDomain(s.domain)}
                  className={
                    domain === s.domain
                      ? "rounded-full bg-brand-500/25 px-3 py-1 text-[11px] text-brand-100"
                      : "rounded-full border border-white/10 px-3 py-1 text-[11px] text-ink-400"
                  }
                  title={s.why}
                >
                  <span className="font-mono" dir="ltr">
                    {s.domain}
                  </span>
                  <span className="mr-1 text-ink-500">· {s.why}</span>
                </button>
              ))}
            </div>
          )}

          <Field label="روش تأیید">
            <select
              className="input"
              value={method}
              onChange={(e) => setMethod(e.target.value as "http" | "cloudflare")}
            >
              <option value="cloudflare">Cloudflare DNS (بدون نیاز به پورت ۸۰)</option>
              <option value="http">HTTP روی پورت ۸۰</option>
            </select>
          </Field>
          <Field label="ایمیل" hint="برای هشدار انقضا — اختیاری">
            <input className="input" dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          {method === "cloudflare" && (
            <Field
              label="توکن API کلادفلر"
              hint="توکن با دسترسی Zone:DNS:Edit روی همان دامنه"
              className="sm:col-span-2"
            >
              <input
                className="input font-mono text-[11px]"
                dir="ltr"
                type="password"
                value={cfToken}
                onChange={(e) => setCfToken(e.target.value)}
              />
            </Field>
          )}
          {method === "http" && (
            <p className="sm:col-span-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] leading-5 text-amber-300">
              این روش پورت ۸۰ را برای چند ثانیه لازم دارد و باید از بیرون قابل دسترس باشد.
              اگر ارائه‌دهنده‌ات پورت ۸۰ را بسته، روش Cloudflare را انتخاب کن.
            </p>
          )}

          {nodeId !== PANEL_NODE && (
            <>
              <Field label="اعمال روی اینباند" hint="مسیر گواهی خودکار در اینباند ذخیره می‌شود">
                <select
                  className="input"
                  value={applyTo}
                  onChange={(e) => setApplyTo(e.target.value ? Number(e.target.value) : "")}
                >
                  <option value="">— هیچ‌کدام —</option>
                  {tlsInbounds.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.remark || i.tag} · {i.protocol}/{i.network}
                    </option>
                  ))}
                </select>
              </Field>
              <div className="flex items-end">
                <Toggle
                  checked={setNodeAddress}
                  onChange={setSetNodeAddress}
                  label="این دامنه، آدرس عمومی نود شود"
                />
              </div>
              <div className="flex items-end">
                <Toggle
                  checked={applyAllTls}
                  onChange={setApplyAllTls}
                  label="روی همه اینباندهای TLS اعمال شود"
                />
              </div>
              <p className="sm:col-span-2 rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-5 text-ink-400">
                با روشن بودن گزینه بالا، از این به بعد در لینک اشتراک و همه کانفیگ‌های
                این نود به‌جای آی‌پی، همین دامنه نوشته می‌شود.
              </p>
            </>
          )}

          {nodeId === PANEL_NODE && (
            <>
              <div className="flex items-end">
                <Toggle
                  checked={useForSub}
                  onChange={setUseForSub}
                  label="برای لینک اشتراک استفاده شود (https)"
                />
              </div>
              <div className="flex items-end">
                <Toggle checked={staging} onChange={setStaging} label="حالت آزمایشی (staging)" />
              </div>
              <p className="sm:col-span-2 rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-5 text-ink-400">
                با این گزینه، دامنه و گواهی روی لینک اشتراک تنظیم می‌شود و لینک کاربران
                به‌شکل <span className="font-mono" dir="ltr">https://دامنه:پورت/sub/…</span>{" "}
                در می‌آید. بعد از صدور، یک‌بار سرویس پنل را ری‌استارت کن.
              </p>
            </>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button className="btn-primary" onClick={issue} disabled={busy}>
            {busy ? <Spinner /> : "صدور گواهی"}
          </button>
          <button className="btn-ghost text-xs" onClick={selfSign} disabled={busy}>
            ساخت گواهی خودامضا (بدون دامنه)
          </button>
          {busy && <span className="text-xs text-ink-400">ممکن است تا یک دقیقه طول بکشد…</span>}
        </div>
        {result && (
          <p className="mt-3 rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-5 text-ink-300">
            {result}
          </p>
        )}
      </Card>

      {loading ? (
        <div className="grid place-items-center py-12">
          <Spinner className="h-6 w-6" />
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {rows.map((row) => (
            <Card key={row.node_id} title={row.node}>
              {row.error ? (
                <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-[11px] text-rose-300">
                  {row.error}
                </p>
              ) : !row.certs.length ? (
                <Empty text="گواهی‌ای اینجا نیست." />
              ) : (
                <div className="space-y-2">
                  {row.certs.map((c) => (
                    <div
                      key={c.cert}
                      className="rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-sm" dir="ltr">
                          {c.domain}
                        </span>
                        <Chip tone={c.self_signed ? "brand" : "green"}>
                          {c.self_signed ? "خودامضا" : "معتبر"}
                        </Chip>
                      </div>
                      <p className="mt-1 text-[11px] text-ink-500" dir="ltr">
                        {c.cert}
                      </p>
                      {c.expires && <p className="text-[11px] text-ink-500">انقضا: {c.expires}</p>}
                    </div>
                  ))}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
