import { useEffect, useRef, useState } from "react";

import { Card, Chip, Empty, Field, MultiSelect, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import { bytes, dateOnly, number } from "../lib/format";
import type { Group, Inbound, Node } from "../lib/types";

interface Preview {
  path: string;
  table: string;
  accounts: number;
  inbounds: { id: number; tag?: string; remark?: string; protocol?: string; port?: number }[];
  sample: Record<string, unknown>[];
}

interface InboundPreview {
  legacy_id: number;
  remark: string;
  legacy_protocol: string;
  port: number;
  supported: boolean;
  reason: string;
  warnings: string[];
  payload?: {
    tag: string;
    protocol: string;
    network?: string;
    security?: string;
    port: number;
  };
}

interface LegacyRow {
  username: string;
  data_limit: number;
  used_traffic: number;
  expire_at: string | null;
  enabled: boolean;
  claimed: boolean;
}

export default function Migration() {
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [busy, setBusy] = useState(false);
  const [groups, setGroups] = useState<Group[]>([]);
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [legacy, setLegacy] = useState<LegacyRow[]>([]);
  const [result, setResult] = useState<Record<string, unknown> | null>(null);

  const [groupId, setGroupId] = useState<number | "">("");
  const [inboundIds, setInboundIds] = useState<number[]>([]);
  const [nodeIds, setNodeIds] = useState<number[]>([]);
  const [keepSub, setKeepSub] = useState(true);
  const [keepUuid, setKeepUuid] = useState(true);
  const [snapshotOnly, setSnapshotOnly] = useState(false);
  const [keepUsage, setKeepUsage] = useState(true);
  const [inboundPreview, setInboundPreview] = useState<InboundPreview[] | null>(null);
  const [makeDefault, setMakeDefault] = useState(true);
  const [importedInbounds, setImportedInbounds] = useState<{
    created: { tag: string; warnings: string[] }[];
    updated: { tag: string }[];
    skipped: { remark: string; reason: string }[];
  } | null>(null);

  const loadLegacy = () =>
    api.get<LegacyRow[]>("/api/migration/legacy?limit=300").then(setLegacy).catch(() => {});

  useEffect(() => {
    api.get<Group[]>("/api/groups").then(setGroups).catch(() => {});
    api.get<Inbound[]>("/api/inbounds").then(setInbounds).catch(() => {});
    api.get<Node[]>("/api/nodes").then(setNodes).catch(() => {});
    loadLegacy();
  }, []);

  const previewInbounds = async (path: string) => {
    try {
      setInboundPreview(await api.post<InboundPreview[]>("/api/migration/inbounds", {
        db_path: path,
      }));
    } catch {
      setInboundPreview(null);
    }
  };

  const importInbounds = async () => {
    if (!preview) return;
    setBusy(true);
    try {
      const res = await api.post<NonNullable<typeof importedInbounds>>(
        "/api/migration/inbounds/import",
        {
          db_path: preview.path,
          node_ids: nodeIds,
          make_default: makeDefault,
          overwrite: false,
        },
      );
      setImportedInbounds(res);
      toast(`${res.created.length} اینباند ساخته شد`);
      api.get<Inbound[]>("/api/inbounds").then(setInbounds).catch(() => {});
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const upload = async (file: File) => {
    setBusy(true);
    setResult(null);
    try {
      const res = await api.upload<Preview>("/api/migration/upload", file);
      setPreview(res);
      previewInbounds(res.path);
      toast(`${res.accounts} حساب در فایل پیدا شد`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const run = async (dryRun: boolean) => {
    if (!preview) return;
    setBusy(true);
    try {
      const res = await api.post<Record<string, unknown>>("/api/migration/run", {
        db_path: preview.path,
        group_id: groupId || null,
        inbound_ids: inboundIds,
        node_ids: nodeIds,
        keep_sub_id: keepSub,
        keep_uuid: keepUuid,
        keep_usage: keepUsage,
        dry_run: dryRun,
        snapshot_only: snapshotOnly,
      });
      setResult(res);
      toast(dryRun ? "شبیه‌سازی انجام شد" : "مهاجرت انجام شد");
      loadLegacy();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">مهاجرت از پنل قدیمی</h1>
        <p className="mt-1 text-xs text-ink-400">
          فایل دیتابیس vpn-ui (‎/opt/vpn-ui/vpn-ui.db) را آپلود کنید تا کاربران با حجم،
          مصرف، تاریخ انقضا و همان شناسه‌ی اشتراک منتقل شوند. فایل مبدأ فقط خوانده می‌شود.
        </p>
      </div>

      <Card title="۱) فایل دیتابیس">
        <input
          ref={fileRef}
          type="file"
          accept=".db,.sqlite,.sqlite3"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
        />
        <div className="flex flex-wrap items-center gap-3">
          <button className="btn-primary" onClick={() => fileRef.current?.click()} disabled={busy}>
            {busy ? <Spinner /> : "انتخاب فایل vpn-ui.db"}
          </button>
          {preview && (
            <>
              <Chip tone="green">{number(preview.accounts)} حساب</Chip>
              <Chip>جدول: {preview.table}</Chip>
              <Chip>{preview.inbounds.length} اینباند در مبدأ</Chip>
            </>
          )}
        </div>
        <p className="mt-3 text-[11px] text-ink-500">
          روی سرور:{" "}
          <code className="font-mono" dir="ltr">
            scp root@old-server:/opt/vpn-ui/vpn-ui.db .
          </code>
        </p>
      </Card>

      {preview && inboundPreview && (
        <Card
          title="۲) اینباندهای پنل قبلی"
          subtitle="با همان پورت و همان کلیدهای Reality ساخته می‌شوند، پس کانفیگ‌های فعلی کاربران از کار نمی‌افتند"
        >
          <div className="-mx-5 overflow-x-auto px-5">
            <table className="w-full min-w-[620px]">
              <thead className="border-b border-white/5">
                <tr>
                  <th className="th">نام</th>
                  <th className="th">پروتکل</th>
                  <th className="th">پورت</th>
                  <th className="th">وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {inboundPreview.map((row) => (
                  <tr key={row.legacy_id}>
                    <td className="td">{row.remark}</td>
                    <td className="td font-mono text-[11px]">
                      {row.legacy_protocol}
                      {row.payload?.network ? ` · ${row.payload.network}` : ""}
                      {row.payload?.security && row.payload.security !== "none"
                        ? ` · ${row.payload.security}`
                        : ""}
                    </td>
                    <td className="td tabular-nums">{row.port}</td>
                    <td className="td max-w-sm whitespace-normal">
                      {row.supported ? (
                        <Chip tone="green">قابل انتقال</Chip>
                      ) : (
                        <span className="text-[11px] text-amber-300">{row.reason}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <Toggle
              checked={makeDefault}
              onChange={setMakeDefault}
              label="به همه کاربران داده شود (مثل پنل قبلی)"
            />
            <button className="btn-primary" onClick={importInbounds} disabled={busy}>
              {busy ? <Spinner /> : "ساخت اینباندها"}
            </button>
            <span className="text-[11px] text-ink-500">
              اول لوکیشن‌ها را پایین انتخاب کن تا روی همان نودها بالا بیایند
            </span>
          </div>
          {importedInbounds && (
            <div className="mt-3 space-y-1 text-[11px] leading-6">
              <p className="text-emerald-300">
                ساخته شد: {importedInbounds.created.map((x) => x.tag).join("، ") || "—"}
              </p>
              {importedInbounds.created
                .flatMap((x) => x.warnings.map((w) => `${x.tag}: ${w}`))
                .map((w) => (
                  <p key={w} className="text-amber-300">
                    ⚠ {w}
                  </p>
                ))}
              {importedInbounds.skipped.map((x) => (
                <p key={x.remark} className="text-ink-500">
                  رد شد — {x.remark}: {x.reason}
                </p>
              ))}
            </div>
          )}
        </Card>
      )}

      {preview && (
        <Card title="۳) تنظیمات انتقال کاربران">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="گروه مقصد">
              <select
                className="input"
                value={groupId}
                onChange={(e) => setGroupId(e.target.value ? Number(e.target.value) : "")}
              >
                <option value="">بدون گروه</option>
                {groups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.title || g.name}
                  </option>
                ))}
              </select>
            </Field>
            <div className="flex flex-wrap items-end gap-5">
              <Toggle checked={keepSub} onChange={setKeepSub} label="حفظ لینک اشتراک قدیمی" />
              <Toggle checked={keepUuid} onChange={setKeepUuid} label="حفظ UUID" />
              <Toggle checked={keepUsage} onChange={setKeepUsage} label="انتقال مصرف" />
              <Toggle
                checked={snapshotOnly}
                onChange={setSnapshotOnly}
                label="فقط ثبت — کاربر خودش منتقل شود"
              />
            </div>
            <p className="sm:col-span-2 rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-6 text-ink-400">
              با روشن بودن «فقط ثبت»، هیچ کاربری همین حالا ساخته نمی‌شود؛ اطلاعات پنل
              قبلی ذخیره می‌شود و هرکس که آدرس صفحه‌ی کاربران را باز کند و نام کاربری‌اش
              را بزند، همان لحظه با همان حجم و روز باقی‌مانده منتقل می‌شود. اگر خاموش
              باشد، هر ۹۴۴ کاربر همین حالا ساخته می‌شوند.
            </p>
            <Field label="اینباندهایی که به کاربران داده شود" className="sm:col-span-2">
              <MultiSelect
                options={inbounds}
                selected={inboundIds}
                onChange={setInboundIds}
                render={(i) => `${i.remark || i.tag} · ${i.protocol}`}
              />
            </Field>
            <Field label="لوکیشن‌ها" className="sm:col-span-2">
              <MultiSelect
                options={nodes}
                selected={nodeIds}
                onChange={setNodeIds}
                render={(n) => `${n.country ? n.country + " " : ""}${n.name}`}
              />
            </Field>
          </div>
          <div className="mt-4 flex gap-2">
            <button className="btn-ghost" onClick={() => run(true)} disabled={busy}>
              شبیه‌سازی (بدون تغییر)
            </button>
            <button className="btn-primary" onClick={() => run(false)} disabled={busy}>
              {busy ? <Spinner /> : "شروع مهاجرت"}
            </button>
          </div>
          {result && (
            <pre
              className="mt-4 overflow-auto rounded-xl bg-ink-950 p-3 text-left font-mono text-[11px] text-ink-300"
              dir="ltr"
            >
              {JSON.stringify(result, null, 2)}
            </pre>
          )}
        </Card>
      )}

      <Card
        title="حساب‌های پنل قدیمی"
        subtitle="کاربرانی که هنوز خودشان را منتقل نکرده‌اند می‌توانند از صفحه‌ی /migrate استفاده کنند"
        actions={
          <a className="btn-ghost text-xs" href="/migrate" target="_blank" rel="noreferrer">
            صفحه‌ی خودانتقالی
          </a>
        }
      >
        {!legacy.length ? (
          <Empty text="هنوز چیزی ایمپورت نشده است." />
        ) : (
          <div className="-mx-5 overflow-x-auto px-5">
            <table className="w-full min-w-[600px]">
              <thead className="border-b border-white/5">
                <tr>
                  <th className="th">کاربر</th>
                  <th className="th">حجم</th>
                  <th className="th">مصرف</th>
                  <th className="th">انقضا</th>
                  <th className="th">وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {legacy.map((row) => (
                  <tr key={row.username}>
                    <td className="td font-medium">{row.username}</td>
                    <td className="td tabular-nums">
                      {row.data_limit ? bytes(row.data_limit) : "نامحدود"}
                    </td>
                    <td className="td tabular-nums">{bytes(row.used_traffic)}</td>
                    <td className="td text-xs">{dateOnly(row.expire_at)}</td>
                    <td className="td">
                      <Chip tone={row.claimed ? "green" : "default"}>
                        {row.claimed ? "منتقل شده" : "در انتظار"}
                      </Chip>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
