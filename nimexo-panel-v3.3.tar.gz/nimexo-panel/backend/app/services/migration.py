"""Import accounts from the old vpn-ui / 3X-UI style panel.

The importer is deliberately defensive: it introspects the source schema
instead of assuming fixed column names, because vpn-ui forks rename things
between releases.

Known semantics of vpn-ui (confirmed against a live panel):
  * accounts.total_gb    -> BYTES despite the name, 0 = unlimited
  * accounts.expiry_time -> unix timestamp in MILLISECONDS, 0 = never
  * usage                -> SUM(up + down) over account_inbounds
  * accounts.password    -> stored in plaintext
  * sub_id == vpn_username == the part of the email before '@'
"""
from __future__ import annotations

import json
import logging
import re
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable

from sqlalchemy.orm import Session

from app.models import Group, Inbound, LegacyAccount, Node, User, utcnow
from app.models.enums import UserStatus
from app.services import users as user_service

logger = logging.getLogger(__name__)

ACCOUNT_TABLES = ("accounts", "clients", "inbound_clients", "users")
USERNAME_COLUMNS = ("vpn_username", "username", "email", "remark", "name")
UUID_COLUMNS = ("uuid", "id_uuid", "client_id", "subid")
LIMIT_COLUMNS = ("total_gb", "total", "data_limit", "traffic_limit")
EXPIRY_COLUMNS = ("expiry_time", "expire", "expiry", "expire_time")
ENABLE_COLUMNS = ("enable", "enabled", "is_active", "active")


@dataclass
class LegacyRow:
    username: str
    email: str = ""
    password: str = ""
    uuid: str = ""
    sub_id: str = ""
    data_limit: int = 0
    used_traffic: int = 0
    lifetime_used: int = 0
    device_limit: int = 0
    telegram_id: int | None = None
    note: str = ""
    expire_at: datetime | None = None
    enabled: bool = True
    raw: dict = field(default_factory=dict)


def _columns(cur: sqlite3.Cursor, table: str) -> list[str]:
    cur.execute(f"PRAGMA table_info({table})")
    return [r[1] for r in cur.fetchall()]


def _tables(cur: sqlite3.Cursor) -> list[str]:
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    return [r[0] for r in cur.fetchall()]


def _pick(columns: Iterable[str], candidates: Iterable[str]) -> str:
    cols = {c.lower(): c for c in columns}
    for candidate in candidates:
        if candidate in cols:
            return cols[candidate]
    return ""


def _to_datetime(value) -> datetime | None:
    """vpn-ui stores milliseconds; other forks store seconds."""
    try:
        number = int(value or 0)
    except (TypeError, ValueError):
        return None
    if number <= 0:
        return None
    if number > 10_000_000_000:      # milliseconds
        number //= 1000
    try:
        return datetime.utcfromtimestamp(number)
    except (OverflowError, OSError, ValueError):
        return None


def inspect(db_path: str) -> dict:
    """Return a short description of the source database."""
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        cur = conn.cursor()
        tables = _tables(cur)
        table = next((t for t in ACCOUNT_TABLES if t in tables), "")
        if not table:
            raise ValueError(
                f"no recognizable account table in {db_path} (found: {', '.join(tables)})"
            )
        cols = _columns(cur, table)
        cur.execute(f"SELECT COUNT(*) FROM {table}")
        count = cur.fetchone()[0]

        inbounds = []
        if "inbounds" in tables:
            in_cols = _columns(cur, "inbounds")
            wanted = [c for c in ("id", "tag", "remark", "protocol", "port", "enable")
                      if c in in_cols]
            cur.execute(f"SELECT {', '.join(wanted)} FROM inbounds")
            inbounds = [dict(zip(wanted, row)) for row in cur.fetchall()]

        sample = []
        cur.execute(f"SELECT * FROM {table} LIMIT 3")
        for row in cur.fetchall():
            sample.append({k: row[i] for i, k in enumerate(cols)})

        return {
            "table": table,
            "tables": tables,
            "columns": cols,
            "accounts": count,
            "inbounds": inbounds,
            "sample": sample,
        }
    finally:
        conn.close()


def read_accounts(db_path: str) -> list[LegacyRow]:
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        tables = _tables(cur)
        table = next((t for t in ACCOUNT_TABLES if t in tables), "")
        if not table:
            raise ValueError("no account table found in the source database")
        cols = _columns(cur, table)

        col_user = _pick(cols, USERNAME_COLUMNS)
        col_uuid = _pick(cols, UUID_COLUMNS)
        col_limit = _pick(cols, LIMIT_COLUMNS)
        col_expire = _pick(cols, EXPIRY_COLUMNS)
        col_enable = _pick(cols, ENABLE_COLUMNS)
        col_sub = _pick(cols, ("sub_id", "subid", "sub"))
        col_pass = _pick(cols, ("password", "passwd", "pass"))
        col_email = _pick(cols, ("email",))
        col_id = "id" if "id" in cols else ""

        # usage: prefer the per-inbound table, fall back to columns on the row
        usage: dict[str, int] = {}
        if "account_inbounds" in tables:
            ai_cols = _columns(cur, "account_inbounds")
            key = _pick(ai_cols, ("account_id", "client_id", "user_id"))
            if key and "up" in ai_cols and "down" in ai_cols:
                cur.execute(
                    f"SELECT {key}, SUM(COALESCE(up,0) + COALESCE(down,0)) "
                    f"FROM account_inbounds GROUP BY {key}"
                )
                usage = {str(r[0]): int(r[1] or 0) for r in cur.fetchall()}
        # lifetime counters, when the source keeps them separately
        lifetime: dict[str, int] = {}
        if "account_inbounds" in tables:
            ai_cols = _columns(cur, "account_inbounds")
            key = _pick(ai_cols, ("account_id", "client_id", "user_id"))
            if key and "all_time" in ai_cols:
                cur.execute(
                    f"SELECT {key}, SUM(COALESCE(all_time,0)) "
                    f"FROM account_inbounds GROUP BY {key}"
                )
                lifetime = {str(r[0]): int(r[1] or 0) for r in cur.fetchall()}

        # vpn-ui keeps the same numbers in two places and they drift apart;
        # the larger one is what the old panel shows the customer, and
        # undercounting here would hand out free traffic.
        by_email: dict[str, int] = {}
        if "client_traffics" in tables:
            ct_cols = _columns(cur, "client_traffics")
            key = _pick(ct_cols, ("email", "username"))
            if key and "up" in ct_cols and "down" in ct_cols:
                cur.execute(
                    f"SELECT {key}, SUM(COALESCE(up,0) + COALESCE(down,0)) "
                    f"FROM client_traffics GROUP BY {key}"
                )
                by_email = {str(r[0]): int(r[1] or 0) for r in cur.fetchall()}
        if not usage:
            usage = by_email
            by_email = {}

        rows: list[LegacyRow] = []
        cur.execute(f"SELECT * FROM {table}")
        for record in cur.fetchall():
            data = dict(record)
            raw_user = str(data.get(col_user) or "").strip()
            if not raw_user:
                continue
            username = raw_user.split("@")[0].lower()
            used = 0
            if col_id and str(data.get(col_id)) in usage:
                used = usage[str(data.get(col_id))]
            elif col_email and str(data.get(col_email)) in usage:
                used = usage[str(data.get(col_email))]
            elif raw_user in usage:
                used = usage[raw_user]
            elif "up" in data and "down" in data:
                used = int(data.get("up") or 0) + int(data.get("down") or 0)

            if col_email:
                used = max(used, by_email.get(str(data.get(col_email)), 0))
            key = str(data.get(col_id)) if col_id else ""
            try:
                telegram_id = int(data.get("tg_id") or 0) or None
            except (TypeError, ValueError):
                telegram_id = None

            rows.append(
                LegacyRow(
                    username=username,
                    email=str(data.get(col_email) or raw_user),
                    password=str(data.get(col_pass) or ""),
                    uuid=str(data.get(col_uuid) or ""),
                    sub_id=str(data.get(col_sub) or username),
                    data_limit=int(data.get(col_limit) or 0),
                    used_traffic=used,
                    lifetime_used=max(lifetime.get(key, 0), used),
                    # vpn-ui calls the per-account device cap "limit_ip"
                    device_limit=int(data.get("limit_ip") or 0),
                    telegram_id=telegram_id,
                    note=str(data.get("comment") or ""),
                    expire_at=_to_datetime(data.get(col_expire)),
                    enabled=bool(data.get(col_enable, 1)),
                    raw=data,
                )
            )
        return rows
    finally:
        conn.close()


def run_import(
    db: Session,
    db_path: str,
    *,
    group_id: int | None = None,
    inbound_ids: list[int] | None = None,
    node_ids: list[int] | None = None,
    keep_sub_id: bool = True,
    keep_uuid: bool = True,
    keep_usage: bool = True,
    dry_run: bool = False,
    snapshot_only: bool = False,
    default_status: UserStatus = UserStatus.ACTIVE,
    owner_id: int | None = None,
) -> dict:
    rows = read_accounts(db_path)
    imported = updated = skipped = 0
    errors: list[str] = []
    touched: list[str] = []

    group = db.query(Group).get(group_id) if group_id else None
    inbounds = (
        db.query(Inbound).filter(Inbound.id.in_(inbound_ids)).all()
        if inbound_ids
        else []
    )
    nodes = db.query(Node).filter(Node.id.in_(node_ids)).all() if node_ids else []

    for row in rows:
        try:
            snapshot = (
                db.query(LegacyAccount)
                .filter(LegacyAccount.username == row.username)
                .one_or_none()
            )
            if snapshot is None:
                snapshot = LegacyAccount(username=row.username)
                db.add(snapshot)
            snapshot.email = row.email
            snapshot.password = row.password
            snapshot.uuid = row.uuid
            snapshot.sub_id = row.sub_id
            snapshot.data_limit = row.data_limit
            snapshot.used_traffic = row.used_traffic
            snapshot.lifetime_used = row.lifetime_used
            snapshot.device_limit = row.device_limit
            snapshot.telegram_id = row.telegram_id
            snapshot.note = row.note
            snapshot.expire_at = row.expire_at
            snapshot.enabled = row.enabled
            snapshot.raw = {k: str(v) for k, v in (row.raw or {}).items()}
            snapshot.imported_at = utcnow()

            existing = (
                db.query(User).filter(User.username == row.username).one_or_none()
            )
            status = default_status if row.enabled else UserStatus.DISABLED

            if existing:
                existing.data_limit = row.data_limit
                if keep_usage:
                    existing.used_traffic = row.used_traffic
                    existing.lifetime_used_traffic = max(
                        existing.lifetime_used_traffic, row.used_traffic
                    )
                existing.expire_at = row.expire_at
                existing.status = status
                if row.device_limit and not existing.device_limit:
                    existing.device_limit = row.device_limit
                if row.telegram_id and not existing.telegram_id:
                    existing.telegram_id = row.telegram_id
                if row.note and not existing.note:
                    existing.note = row.note
                existing.legacy_source = "vpn-ui"
                existing.legacy_id = row.username
                if row.password:
                    existing.password = row.password
                if keep_uuid and row.uuid:
                    existing.uuid = row.uuid
                if group and existing.group_id is None:
                    existing.group_id = group.id
                if inbounds and not existing.inbounds:
                    existing.inbounds = inbounds
                if nodes and not existing.nodes:
                    existing.nodes = nodes
                snapshot.claimed_user_id = existing.id
                snapshot.claimed_at = utcnow()
                db.add(existing)
                updated += 1
                touched.append(row.username)
                continue

            if dry_run or snapshot_only:
                # snapshot_only records the old account without creating a user:
                # the account appears the moment its owner opens the portal and
                # types their username, so nobody who never comes across is
                # created at all.
                imported += 1
                touched.append(row.username)
                continue

            user = user_service.create_user(
                db,
                username=row.username,
                password=row.password,
                uuid=row.uuid if keep_uuid else "",
                sub_id=row.sub_id if keep_sub_id else "",
                group_id=group.id if group else None,
                data_limit=row.data_limit,
                expire_at=row.expire_at,
                status=status,
                email=row.email,
                owner_id=owner_id,
                inbound_ids=[i.id for i in inbounds] or None,
                node_ids=[n.id for n in nodes] or None,
                legacy_source="vpn-ui",
                legacy_id=row.username,
                used_traffic=row.used_traffic if keep_usage else 0,
                device_limit=row.device_limit or (group.device_limit if group else 0),
                note=row.note,
            )
            if row.telegram_id:
                user.telegram_id = row.telegram_id
            if keep_usage and row.lifetime_used:
                user.lifetime_used_traffic = row.lifetime_used
                db.add(user)
            snapshot.claimed_user_id = user.id
            snapshot.claimed_at = utcnow()
            imported += 1
            touched.append(row.username)
        except Exception as exc:  # noqa: BLE001
            skipped += 1
            errors.append(f"{row.username}: {exc}")
            logger.warning("import failed for %s: %s", row.username, exc)

    if dry_run:
        db.rollback()
    else:
        db.commit()

    return {
        "imported": imported,
        "updated": updated,
        "skipped": skipped,
        "errors": errors[:50],
        "users": touched[:200],
    }


def claim(db: Session, username: str, password: str = "",
          group_id: int | None = None) -> User | None:
    """Self-service migration: an end user moves their own old account across.

    The old panel's numbers win — usage, remaining days and data limit are the
    customer's, not the plan's. The group is only used to decide *what the
    account can connect to* (its inbounds and nodes) and to fill in a device
    limit the old panel never had.
    """
    username = username.strip().lower().split("@")[0]
    snapshot = (
        db.query(LegacyAccount).filter(LegacyAccount.username == username).one_or_none()
    )
    if snapshot is None:
        return None
    if snapshot.password and password and snapshot.password != password:
        return None
    if snapshot.claimed_user_id:
        return db.query(User).get(snapshot.claimed_user_id)

    group = db.query(Group).get(group_id) if group_id else None

    user = db.query(User).filter(User.username == username).one_or_none()
    if user is None:
        user = user_service.create_user(
            db,
            username=username,
            password=snapshot.password,
            uuid=snapshot.uuid,
            sub_id=snapshot.sub_id,
            group_id=group.id if group else None,
            data_limit=snapshot.data_limit or (group.data_limit if group else 0),
            device_limit=snapshot.device_limit or (group.device_limit if group else 0),
            expire_at=snapshot.expire_at,
            status=UserStatus.ACTIVE if snapshot.enabled else UserStatus.DISABLED,
            email=snapshot.email,
            note=snapshot.note or "",
            legacy_source="vpn-ui",
            legacy_id=username,
            used_traffic=snapshot.used_traffic,
        )
        if snapshot.telegram_id:
            user.telegram_id = snapshot.telegram_id
        if snapshot.lifetime_used:
            user.lifetime_used_traffic = snapshot.lifetime_used
        db.add(user)
    elif group and user.group_id is None:
        user.group_id = group.id
        db.add(user)

    snapshot.claimed_user_id = user.id
    snapshot.claimed_at = utcnow()
    db.commit()

    # give the account its configuration on every node it is entitled to
    try:
        from app.services import sync as sync_service

        sync_service.sync_nodes_for_user(db, user)
    except Exception:  # noqa: BLE001 — a node being down must not block a claim
        logger.warning("could not sync nodes after claim of %s", username)
    return user


# --------------------------------------------------------------------------
# inbound definitions
# --------------------------------------------------------------------------
# vpn-ui protocol name -> (our core, our protocol)
INBOUND_CORES = {
    "vless": ("xray", "vless"),
    "vmess": ("xray", "vmess"),
    "trojan": ("xray", "trojan"),
    "shadowsocks": ("xray", "shadowsocks"),
    "openvpn": ("openvpn", "openvpn"),
    "openconnect": ("ocserv", "ocserv"),
    "ocserv": ("ocserv", "ocserv"),
    "l2tp": ("l2tp", "l2tp"),
    "pptp": ("pptp", "pptp"),
    "wg-c": ("wireguard", "wireguard"),
    "wireguard": ("wireguard", "wireguard"),
}

# things the old panel had that this one does not implement
UNSUPPORTED_HINT = {
    "mtproto": "پروکسی MTProto تلگرام — این پنل آن را ندارد",
    "ssh": "تونل SSH — این پنل آن را ندارد",
    "awg": "AmneziaWG — این پنل فقط WireGuard معمولی دارد",
    "hysteria": "Hysteria — این پنل آن را ندارد",
    "tuic": "TUIC — این پنل آن را ندارد",
    "naive": "NaiveProxy — این پنل آن را ندارد",
}


def _slug(text: str, fallback: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "-", (text or "").strip()).strip("-").lower()
    return cleaned or fallback


def _first_range(ranges) -> str:
    """"10.7.0.2-10.7.0.254" -> "10.7.0.0/24" """
    if not isinstance(ranges, list) or not ranges:
        return ""
    start = str(ranges[0]).split("-")[0].strip()
    parts = start.split(".")
    if len(parts) != 4:
        return ""
    return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"


def read_inbounds(db_path: str) -> list[dict]:
    """Describe every inbound in the old panel as a payload this one can create."""
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        if "inbounds" not in _tables(cur):
            return []
        cols = _columns(cur, "inbounds")
        wanted = [c for c in ("id", "remark", "protocol", "port", "enable", "listen",
                              "settings", "stream_settings", "sniffing", "tag")
                  if c in cols]
        result = []
        for record in cur.execute(f"SELECT {', '.join(wanted)} FROM inbounds"):
            row = dict(record)
            protocol = str(row.get("protocol") or "").lower()
            entry = {
                "legacy_id": row.get("id"),
                "remark": row.get("remark") or "",
                "legacy_protocol": protocol,
                "port": int(row.get("port") or 0),
                "enabled": bool(row.get("enable", 1)),
                "supported": protocol in INBOUND_CORES,
                "reason": UNSUPPORTED_HINT.get(protocol, ""),
                "warnings": [],
            }
            if not entry["supported"]:
                entry["reason"] = entry["reason"] or f"پروتکل {protocol} پشتیبانی نمی‌شود"
                result.append(entry)
                continue
            entry["payload"] = _inbound_payload(row, protocol, entry)
            result.append(entry)
        return result
    finally:
        conn.close()


def _inbound_payload(row: dict, protocol: str, entry: dict) -> dict:
    core, our_protocol = INBOUND_CORES[protocol]
    try:
        settings = json.loads(row.get("settings") or "{}")
    except json.JSONDecodeError:
        settings = {}
    try:
        stream = json.loads(row.get("stream_settings") or "{}")
    except json.JSONDecodeError:
        stream = {}

    port = int(row.get("port") or 0)
    payload = {
        "tag": _slug(row.get("remark") or protocol, protocol) + f"-{port}",
        "remark": row.get("remark") or protocol,
        "core": core,
        "protocol": our_protocol,
        "listen": str(row.get("listen") or ""),
        "port": port,
        "is_enabled": bool(row.get("enable", 1)),
        "sniffing": bool(row.get("sniffing")),
        "settings": {},
    }

    if core == "xray":
        _xray_from_stream(payload, stream, settings, entry)
        if our_protocol == "shadowsocks":
            payload["settings"].update(
                {
                    "method": settings.get("method", "aes-256-gcm"),
                    "server_password": settings.get("password", ""),
                    "network": settings.get("network", "tcp,udp"),
                }
            )
        if our_protocol == "vless" and settings.get("decryption") not in (None, "", "none"):
            # VLESS Encryption: keeping the server side identical is what lets
            # the configs people already have keep working after the move.
            payload["settings"]["vless_decryption"] = settings["decryption"]
            payload["settings"]["vless_encryption"] = settings.get("encryption", "")
    elif core == "openvpn":
        payload["settings"] = {"port": port, "mtu": 1280}
    elif core == "ocserv":
        subnet = _first_range(settings.get("ipRanges"))
        payload["settings"] = {
            "port": port,
            "subnet": subnet.split("/")[0] if subnet else "10.30.0.0",
            "mtu": int(settings.get("mtu") or 1280),
            "dns": [d for d in (settings.get("dns1"), settings.get("dns2")) if d],
        }
        if settings.get("certificateFile"):
            entry["warnings"].append(
                "گواهی این اینباند در پنل قبلی بود؛ در پنل جدید یک گواهی صادر کن"
            )
    elif core == "l2tp":
        payload["settings"] = {
            "psk": settings.get("ipsecPsk", ""),
            "local_ip": settings.get("localIp", "10.40.0.1"),
            "range": (settings.get("ipRanges") or ["10.40.0.10-10.40.0.250"])[0],
            "mtu": int(settings.get("mtu") or 1280),
        }
    elif core == "wireguard":
        subnet = _first_range(settings.get("ipRanges")) or "10.66.0.0/24"
        payload["settings"] = {
            "subnet": subnet,
            "mtu": int(settings.get("mtu") or 1280),
            "dns": ", ".join(
                d for d in (settings.get("dns1"), settings.get("dns2")) if d
            ) or "1.1.1.1",
        }
    return payload


def _xray_from_stream(payload: dict, stream: dict, settings: dict, entry: dict) -> None:
    network = str(stream.get("network") or "tcp").lower()
    if network == "http":
        network = "h2"
    payload["network"] = network
    security = str(stream.get("security") or "none").lower()
    payload["security"] = security if security in ("none", "tls", "reality") else "none"

    ws = stream.get("wsSettings") or {}
    grpc = stream.get("grpcSettings") or {}
    hu = stream.get("httpupgradeSettings") or {}
    xh = stream.get("xhttpSettings") or {}
    tcp = stream.get("tcpSettings") or {}

    payload["path"] = ws.get("path") or hu.get("path") or xh.get("path") or ""
    payload["host"] = (
        ws.get("host") or (ws.get("headers") or {}).get("Host")
        or hu.get("host") or xh.get("host") or ""
    )
    payload["service_name"] = grpc.get("serviceName", "")
    if grpc.get("multiMode"):
        payload["settings"]["multi_mode"] = True
    header = ((tcp.get("header") or {}).get("type") or "")
    payload["header_type"] = "" if header in ("", "none") else header

    if payload["security"] == "tls":
        tls = stream.get("tlsSettings") or {}
        payload["sni"] = tls.get("serverName", "")
        payload["alpn"] = ",".join(tls.get("alpn") or [])
        certs = tls.get("certificates") or [{}]
        payload["cert_path"] = certs[0].get("certificateFile", "")
        payload["key_path"] = certs[0].get("keyFile", "")
        payload["fingerprint"] = (tls.get("settings") or {}).get("fingerprint", "chrome")
        if payload["cert_path"]:
            entry["warnings"].append(
                f"مسیر گواهی از پنل قبلی است ({payload['cert_path']}) — "
                "اگر روی نود جدید نیست، از صفحه گواهی‌ها یکی بگیر"
            )
    elif payload["security"] == "reality":
        reality = stream.get("realitySettings") or {}
        inner = reality.get("settings") or {}
        payload["reality_dest"] = reality.get("target") or reality.get("dest") or ""
        payload["reality_server_names"] = reality.get("serverNames") or []
        payload["reality_private_key"] = reality.get("privateKey", "")
        payload["reality_public_key"] = inner.get("publicKey", "")
        payload["reality_short_ids"] = reality.get("shortIds") or []
        payload["sni"] = (reality.get("serverNames") or [""])[0]
        payload["fingerprint"] = inner.get("fingerprint", "chrome")
        payload["settings"]["reality_spider_x"] = inner.get("spiderX", "/")

    # flow lives on each client in the old schema; take the first one that has it
    for client in settings.get("clients") or []:
        if client.get("flow"):
            payload["flow"] = client["flow"]
            break


def import_inbounds(db: Session, db_path: str, node_ids: list[int] | None = None,
                    overwrite: bool = False, only: list[int] | None = None,
                    make_default: bool = True) -> dict:
    """Recreate the old panel's inbounds here, keys and ports included."""
    from app.api.routes.inbounds import ensure_reality, ensure_shadowsocks
    from app.models import NodeInbound
    from app.models.enums import CoreType, Network, Protocol, Security
    from app.services.cores import wireguard as wg_core

    entries = read_inbounds(db_path)
    created, updated, skipped = [], [], []
    node_ids = node_ids or []

    for entry in entries:
        if only and entry["legacy_id"] not in only:
            continue
        if not entry["supported"]:
            skipped.append({"remark": entry["remark"], "reason": entry["reason"]})
            continue
        payload = entry["payload"]
        existing = db.query(Inbound).filter(Inbound.tag == payload["tag"]).one_or_none()
        if existing is not None and not overwrite:
            skipped.append(
                {"remark": entry["remark"], "reason": f"تگ {payload['tag']} از قبل هست"}
            )
            continue

        inbound = existing or Inbound(tag=payload["tag"])
        inbound.remark = payload["remark"]
        inbound.core = CoreType(payload["core"])
        inbound.protocol = Protocol(payload["protocol"])
        inbound.listen = payload.get("listen", "")
        inbound.port = payload["port"]
        inbound.is_enabled = payload["is_enabled"]
        # in the old panel every account had every inbound; keeping that means
        # a migrated user sees exactly the services they had before
        inbound.is_default = make_default
        inbound.sniffing = payload.get("sniffing", False)
        inbound.settings = payload.get("settings", {})
        if payload["core"] == "xray":
            inbound.network = Network(payload.get("network", "tcp"))
            inbound.security = Security(payload.get("security", "none"))
            for field_name in ("sni", "host", "path", "service_name", "header_type",
                               "alpn", "flow", "cert_path", "key_path",
                               "reality_private_key", "reality_public_key",
                               "reality_dest"):
                setattr(inbound, field_name, payload.get(field_name, "") or "")
            inbound.fingerprint = payload.get("fingerprint", "chrome") or "chrome"
            inbound.reality_short_ids = payload.get("reality_short_ids", []) or []
            inbound.reality_server_names = payload.get("reality_server_names", []) or []
            ensure_reality(inbound)
            ensure_shadowsocks(inbound)
        elif inbound.core == CoreType.WIREGUARD:
            wg_core.ensure_server_keys(inbound)

        db.add(inbound)
        db.flush()

        for node_id in node_ids:
            link = (
                db.query(NodeInbound)
                .filter(NodeInbound.inbound_id == inbound.id,
                        NodeInbound.node_id == node_id)
                .one_or_none()
            )
            if link is None:
                db.add(NodeInbound(inbound_id=inbound.id, node_id=node_id))

        target = updated if existing else created
        target.append(
            {
                "tag": inbound.tag,
                "remark": inbound.remark,
                "protocol": payload["protocol"],
                "port": inbound.port,
                "warnings": entry["warnings"],
            }
        )

    db.commit()
    return {"created": created, "updated": updated, "skipped": skipped}
