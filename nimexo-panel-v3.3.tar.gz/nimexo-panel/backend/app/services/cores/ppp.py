"""L2TP/IPsec and PPTP helpers.

Both cores authenticate from the same /etc/ppp/chap-secrets file on the node,
so the panel sends one account list and, alongside it, whichever server
sections are actually deployed there.
"""
from __future__ import annotations

from typing import Sequence

from app.models import Inbound, Node, User
from app.models.enums import CoreType
from app.utils.crypto import random_token

L2TP_DEFAULTS = {
    "port": 1701,
    "local_ip": "10.40.0.1",
    "range": "10.40.0.10-10.40.0.250",
    "subnet": "10.40.0.0/24",
    "mtu": 1280,
    "dns": ["1.1.1.1", "8.8.8.8"],
}

PPTP_DEFAULTS = {
    "local_ip": "10.50.0.1",
    "range": "10.50.0.10-10.50.0.250",
    "subnet": "10.50.0.0/24",
    "mtu": 1280,
    "dns": ["1.1.1.1", "8.8.8.8"],
}


def ensure_psk(inbound: Inbound) -> str:
    """L2TP needs a pre-shared key; generate one the first time."""
    settings = dict(inbound.settings or {})
    if not settings.get("psk"):
        settings["psk"] = random_token(16)
        inbound.settings = settings
    return inbound.settings["psk"]


def server_options(inbound: Inbound, port_override: int | None = None) -> dict:
    base = L2TP_DEFAULTS if inbound.core == CoreType.L2TP else PPTP_DEFAULTS
    opts = dict(base)
    opts.update({k: v for k, v in (inbound.settings or {}).items() if v not in (None, "")})
    if inbound.core == CoreType.L2TP:
        opts["psk"] = ensure_psk(inbound)
        opts["port"] = port_override or inbound.port or opts["port"]
    return opts


def build_payload(users: Sequence[User], l2tp: Inbound | None = None,
                  pptp: Inbound | None = None,
                  l2tp_port: int | None = None) -> dict:
    payload: dict = {
        "users": [
            {"username": u.username, "password": u.password} for u in users if u.password
        ]
    }
    if l2tp is not None:
        payload["l2tp"] = server_options(l2tp, l2tp_port)
    if pptp is not None:
        payload["pptp"] = server_options(pptp)
    return payload


def credentials(inbound: Inbound, node: Node, user: User,
                port_override: int | None = None,
                address_override: str = "", host: str = "") -> dict:
    opts = server_options(inbound, port_override)
    data = {
        "host": host or address_override or node.endpoint,
        "username": user.username,
        "password": user.password,
    }
    if inbound.core == CoreType.L2TP:
        data["psk"] = opts.get("psk", "")
        data["hint"] = "در تنظیمات VPN دستگاه، نوع را L2TP/IPsec PSK انتخاب کنید."
    else:
        data["hint"] = "نوع اتصال را PPTP انتخاب کنید (رمزنگاری MPPE)."
    return data
