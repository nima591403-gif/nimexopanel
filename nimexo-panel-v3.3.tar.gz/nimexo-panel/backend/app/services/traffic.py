"""Traffic collection, quota enforcement and online-user tracking."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import (
    Connection,
    CounterState,
    Node,
    TrafficRecord,
    User,
    UserCredential,
    UserNodeUsage,
    utcnow,
)
from app.models.enums import (
    CoreType,
    DataLimitStrategy,
    NodeStatus,
    Protocol,
    UserStatus,
)
from app.services.node_manager import NodeError, agent_for
from app.services.ssh import SSHError

logger = logging.getLogger(__name__)

ONLINE_WINDOW = timedelta(minutes=3)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _hour_bucket(moment: datetime | None = None) -> datetime:
    moment = moment or utcnow()
    return moment.replace(minute=0, second=0, microsecond=0)


def _user_map(db: Session) -> dict[str, User]:
    return {u.username: u for u in db.query(User).all()}


def _add_usage(db: Session, user: User, node: Node, up: int, down: int,
               bucket_cache: dict) -> None:
    if up <= 0 and down <= 0:
        return
    coefficient = node.usage_coefficient or 1.0
    counted_up = int(up * coefficient)
    counted_down = int(down * coefficient)

    usage = (
        db.query(UserNodeUsage)
        .filter(UserNodeUsage.user_id == user.id, UserNodeUsage.node_id == node.id)
        .one_or_none()
    )
    if usage is None:
        usage = UserNodeUsage(user_id=user.id, node_id=node.id)
        db.add(usage)
    usage.up += counted_up
    usage.down += counted_down

    user.used_traffic += counted_up + counted_down
    user.lifetime_used_traffic += counted_up + counted_down
    user.online_at = utcnow()
    if user.first_connected_at is None:
        user.first_connected_at = utcnow()
        if user.status == UserStatus.ON_HOLD and user.on_hold_duration_days:
            user.expire_at = utcnow() + timedelta(days=user.on_hold_duration_days)
            user.status = UserStatus.ACTIVE

    node.up_bytes += up
    node.down_bytes += down

    key = (_hour_bucket(), user.id, node.id)
    record = bucket_cache.get(key)
    if record is None:
        record = (
            db.query(TrafficRecord)
            .filter(
                TrafficRecord.bucket == key[0],
                TrafficRecord.user_id == user.id,
                TrafficRecord.node_id == node.id,
            )
            .one_or_none()
        )
        if record is None:
            record = TrafficRecord(bucket=key[0], user_id=user.id, node_id=node.id)
            db.add(record)
        bucket_cache[key] = record
    record.up += counted_up
    record.down += counted_down


def _counter_delta(db: Session, node: Node, kind: str, key: str,
                   up: int, down: int) -> tuple[int, int]:
    """Convert a cumulative reading into a delta, tolerating counter resets."""
    state = (
        db.query(CounterState)
        .filter(
            CounterState.node_id == node.id,
            CounterState.kind == kind,
            CounterState.key == key,
        )
        .one_or_none()
    )
    if state is None:
        state = CounterState(node_id=node.id, kind=kind, key=key, up=0, down=0)
        db.add(state)
    d_up = up - state.up if up >= state.up else up
    d_down = down - state.down if down >= state.down else down
    state.up, state.down = up, down
    state.updated_at = utcnow()
    return max(d_up, 0), max(d_down, 0)


def _touch_connection(db: Session, user: User, node: Node, protocol: Protocol,
                      ip: str = "", up: int = 0, down: int = 0) -> None:
    conn = (
        db.query(Connection)
        .filter(
            Connection.user_id == user.id,
            Connection.node_id == node.id,
            Connection.protocol == protocol,
            Connection.is_active.is_(True),
        )
        .one_or_none()
    )
    if conn is None:
        conn = Connection(
            user_id=user.id, node_id=node.id, protocol=protocol, ip=ip,
            started_at=utcnow(),
        )
        db.add(conn)
    if ip:
        conn.ip = ip
    conn.up += up
    conn.down += down
    conn.last_seen = utcnow()
    conn.is_active = True


# --------------------------------------------------------------------------
# collection
# --------------------------------------------------------------------------
def collect_node(db: Session, node: Node) -> dict:
    """Pull counters from a single node and fold them into the database."""
    summary = {"xray": 0, "wireguard": 0, "openvpn": 0, "errors": []}
    users = _user_map(db)
    buckets: dict = {}
    agent = agent_for(node)

    installed = set((node.installed_cores or {}).keys())

    # ---- Xray ----------------------------------------------------------
    if CoreType.XRAY.value in installed:
        try:
            stats = agent.xray_stats(reset=True)
            for ident, values in (stats.get("users") or {}).items():
                # emails are "<username>#<inbound tag>" so that the same account
                # in two inbounds does not collide in Xray's stats registry
                user = users.get(ident.rsplit("#", 1)[0]) or users.get(ident)
                if not user:
                    continue
                _add_usage(db, user, node, values.get("up", 0), values.get("down", 0),
                           buckets)
                summary["xray"] += values.get("up", 0) + values.get("down", 0)
        except (NodeError, SSHError) as exc:
            summary["errors"].append(f"xray: {exc}")

    # ---- WireGuard ------------------------------------------------------
    if CoreType.WIREGUARD.value in installed:
        try:
            stats = agent.wg_stats()
            peers = stats.get("peers") or {}
            if peers:
                cred_map = {
                    c.data.get("public_key"): c
                    for c in db.query(UserCredential).all()
                    if c.data and c.data.get("public_key")
                }
                id_to_user = {u.id: u for u in users.values()}
                for pubkey, values in peers.items():
                    cred = cred_map.get(pubkey)
                    if not cred:
                        continue
                    user = id_to_user.get(cred.user_id)
                    if not user:
                        continue
                    up, down = _counter_delta(
                        db, node, "wireguard", pubkey,
                        values.get("up", 0), values.get("down", 0),
                    )
                    _add_usage(db, user, node, up, down, buckets)
                    summary["wireguard"] += up + down
                    if values.get("last_handshake"):
                        seen = datetime.utcfromtimestamp(values["last_handshake"])
                        if utcnow() - seen < ONLINE_WINDOW:
                            _touch_connection(
                                db, user, node, Protocol.WIREGUARD,
                                (values.get("endpoint") or "").rsplit(":", 1)[0],
                                up, down,
                            )
        except (NodeError, SSHError) as exc:
            summary["errors"].append(f"wireguard: {exc}")

    # ---- OpenVPN --------------------------------------------------------
    if CoreType.OPENVPN.value in installed:
        try:
            stats = agent.ovpn_stats()
            for cn, values in (stats.get("clients") or {}).items():
                user = users.get(cn)
                if not user:
                    continue
                up, down = _counter_delta(
                    db, node, "openvpn", cn, values.get("up", 0), values.get("down", 0)
                )
                _add_usage(db, user, node, up, down, buckets)
                summary["openvpn"] += up + down
                sessions = values.get("sessions") or []
                _touch_connection(
                    db, user, node, Protocol.OPENVPN,
                    sessions[0]["ip"] if sessions else "", up, down,
                )
        except (NodeError, SSHError) as exc:
            summary["errors"].append(f"openvpn: {exc}")

    # ---- OpenConnect ----------------------------------------------------
    if CoreType.OCSERV.value in installed:
        try:
            stats = agent.ocserv_stats()
            for username, values in (stats.get("users") or {}).items():
                user = users.get(username)
                if not user:
                    continue
                up, down = _counter_delta(
                    db, node, "ocserv", username,
                    values.get("up", 0), values.get("down", 0),
                )
                _add_usage(db, user, node, up, down, buckets)
                summary["ocserv"] = summary.get("ocserv", 0) + up + down
                _touch_connection(
                    db, user, node, Protocol.OCSERV, values.get("ip", ""), up, down
                )
        except (NodeError, SSHError) as exc:
            summary["errors"].append(f"ocserv: {exc}")

    # ---- L2TP / PPTP (shared ppp accounting) ----------------------------
    if {CoreType.L2TP.value, CoreType.PPTP.value} & installed:
        try:
            stats = agent.ppp_stats()
            for username, values in (stats.get("users") or {}).items():
                user = users.get(username)
                if not user:
                    continue
                up, down = _counter_delta(
                    db, node, "ppp", username,
                    values.get("up", 0), values.get("down", 0),
                )
                _add_usage(db, user, node, up, down, buckets)
                summary["ppp"] = summary.get("ppp", 0) + up + down
                if values.get("online"):
                    protocol = (
                        Protocol.L2TP
                        if CoreType.L2TP.value in installed
                        else Protocol.PPTP
                    )
                    _touch_connection(db, user, node, protocol, "", up, down)
        except (NodeError, SSHError) as exc:
            summary["errors"].append(f"ppp: {exc}")

    if summary["errors"]:
        node.status = NodeStatus.ERROR
        node.status_message = "; ".join(summary["errors"])[:500]
    db.commit()
    return summary


def collect_all(db: Session) -> dict:
    result = {}
    for node in db.query(Node).filter(Node.is_enabled.is_(True)).all():
        try:
            result[node.name] = collect_node(db, node)
        except Exception as exc:  # noqa: BLE001
            logger.warning("traffic collection failed on %s: %s", node.name, exc)
            result[node.name] = {"errors": [str(exc)]}
    close_stale_connections(db)
    return result


def close_stale_connections(db: Session) -> int:
    threshold = utcnow() - ONLINE_WINDOW
    rows = (
        db.query(Connection)
        .filter(Connection.is_active.is_(True), Connection.last_seen < threshold)
        .all()
    )
    for row in rows:
        row.is_active = False
    db.commit()
    return len(rows)


# --------------------------------------------------------------------------
# enforcement
# --------------------------------------------------------------------------
def _next_reset_due(user: User) -> bool:
    if user.data_limit_strategy == DataLimitStrategy.NO_RESET:
        return False
    last = user.last_reset_at or user.created_at
    now = utcnow()
    spans = {
        DataLimitStrategy.DAILY: timedelta(days=1),
        DataLimitStrategy.WEEKLY: timedelta(days=7),
        DataLimitStrategy.MONTHLY: timedelta(days=30),
        DataLimitStrategy.YEARLY: timedelta(days=365),
    }
    return now - last >= spans[user.data_limit_strategy]


def enforce_limits(db: Session) -> dict:
    """Flip users between active / limited / expired and reset cyclic quotas."""
    changed = {"limited": [], "expired": [], "reactivated": [], "reset": []}
    now = utcnow()

    for user in db.query(User).all():
        original = user.status

        if _next_reset_due(user):
            user.used_traffic = 0
            user.last_reset_at = now
            # a fresh cycle deserves fresh reminders
            user.notify_state = {}
            changed["reset"].append(user.username)
            if user.status == UserStatus.LIMITED:
                user.status = UserStatus.ACTIVE

        if user.status in (UserStatus.ACTIVE, UserStatus.ON_HOLD):
            if user.expire_at and user.expire_at <= now:
                user.status = UserStatus.EXPIRED
                changed["expired"].append(user.username)
            elif user.data_limit and user.used_traffic >= user.data_limit:
                user.status = UserStatus.LIMITED
                changed["limited"].append(user.username)
        elif user.status in (UserStatus.LIMITED, UserStatus.EXPIRED):
            quota_ok = not user.data_limit or user.used_traffic < user.data_limit
            time_ok = not user.expire_at or user.expire_at > now
            if quota_ok and time_ok:
                user.status = UserStatus.ACTIVE
                changed["reactivated"].append(user.username)

        if user.status != original:
            db.add(user)

    db.commit()
    return {k: v for k, v in changed.items() if v}


def online_user_ids(db: Session) -> set[int]:
    threshold = utcnow() - ONLINE_WINDOW
    rows = db.execute(
        select(Connection.user_id).where(
            Connection.is_active.is_(True), Connection.last_seen >= threshold
        )
    ).all()
    ids = {r[0] for r in rows}
    ids |= {
        u.id
        for u in db.query(User).filter(User.online_at >= threshold).all()
    }
    return ids
