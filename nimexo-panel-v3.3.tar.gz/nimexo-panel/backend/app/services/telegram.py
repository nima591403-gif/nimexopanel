"""Telegram notifications.

Users hand their numeric Telegram id to the self-service portal; the panel
uses it to warn them before an account expires or runs out of traffic, and to
deliver an admin broadcast. Nothing here is load-bearing: a missing token or a
failed request is logged and skipped, never raised into a request handler.
"""
from __future__ import annotations

import logging
from datetime import timedelta

import httpx
from sqlalchemy.orm import Session

from app.models import User, utcnow
from app.models.enums import UserStatus
from app.services import settings_store

logger = logging.getLogger(__name__)

API = "https://api.telegram.org/bot{token}/sendMessage"
TIMEOUT = 12.0


def enabled(db: Session | None = None) -> bool:
    return bool(settings_store.load(db).get("telegram_bot_token"))


def send(db: Session | None, chat_id: int | str, text: str) -> tuple[bool, str]:
    token = settings_store.load(db).get("telegram_bot_token")
    if not token:
        return False, "ربات تلگرام تنظیم نشده است"
    try:
        response = httpx.post(
            API.format(token=token),
            json={
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            },
            timeout=TIMEOUT,
        )
    except httpx.HTTPError as exc:
        logger.warning("telegram send failed: %s", exc)
        return False, str(exc)[:200]
    if response.status_code != 200:
        detail = ""
        try:
            detail = response.json().get("description", "")
        except Exception:  # noqa: BLE001
            detail = response.text[:200]
        return False, detail or f"HTTP {response.status_code}"
    return True, ""


def verify_token(db: Session | None = None) -> tuple[bool, str]:
    token = settings_store.load(db).get("telegram_bot_token")
    if not token:
        return False, "توکن ثبت نشده"
    try:
        r = httpx.get(f"https://api.telegram.org/bot{token}/getMe", timeout=TIMEOUT)
        data = r.json()
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:200]
    if not data.get("ok"):
        return False, data.get("description", "توکن نامعتبر است")
    return True, "@" + (data["result"].get("username") or "?")


# --------------------------------------------------------------------------
# message bodies
# --------------------------------------------------------------------------
def _fmt_gb(value: int) -> str:
    return f"{value / (1024 ** 3):.2f} GB"


def expiry_message(user: User, days_left: int, page_url: str) -> str:
    when = "امروز" if days_left <= 0 else f"{days_left} روز دیگر"
    return (
        f"⏳ <b>{user.username}</b>\n"
        f"اشتراک شما {when} تمام می‌شود.\n"
        f"برای تمدید با پشتیبانی تماس بگیرید.\n\n{page_url}"
    )


def quota_message(user: User, percent: int, page_url: str) -> str:
    remaining = max(0, (user.data_limit or 0) - user.used_traffic)
    return (
        f"📶 <b>{user.username}</b>\n"
        f"{percent}٪ از حجم اشتراک شما مصرف شده — "
        f"{_fmt_gb(remaining)} باقی مانده است.\n\n{page_url}"
    )


# --------------------------------------------------------------------------
# jobs
# --------------------------------------------------------------------------
def notify_expiring(db: Session) -> dict:
    """Warn users close to their expiry date or traffic limit. Runs hourly."""
    cfg = settings_store.load(db)
    if not cfg.get("telegram_bot_token"):
        return {"skipped": "no token"}

    days_before = int(cfg.get("notify_days_before") or 3)
    percent = int(cfg.get("notify_traffic_percent") or 85)
    page_base = settings_store.page_base_url(db)
    now = utcnow()
    sent = {"expiry": 0, "quota": 0, "failed": 0}

    users = (
        db.query(User)
        .filter(User.telegram_id.isnot(None), User.status.in_(
            (UserStatus.ACTIVE, UserStatus.ON_HOLD)
        ))
        .all()
    )
    for user in users:
        page = f"{page_base}/u/{user.sub_id}"

        if user.expire_at:
            days_left = (user.expire_at - now).days
            if 0 <= days_left <= days_before:
                # once per remaining-day, so a 3-day window sends 3 reminders
                marker = f"expire:{days_left}"
                if _mark_once(db, user, marker):
                    ok, _ = send(db, user.telegram_id,
                                 expiry_message(user, days_left, page))
                    sent["expiry" if ok else "failed"] += 1

        if user.data_limit:
            used = 100 * user.used_traffic / user.data_limit
            if used >= percent:
                bucket = 100 if used >= 100 else percent
                if _mark_once(db, user, f"quota:{bucket}"):
                    ok, _ = send(db, user.telegram_id,
                                 quota_message(user, int(used), page))
                    sent["quota" if ok else "failed"] += 1

    db.commit()
    return sent


def _mark_once(db: Session, user: User, marker: str) -> bool:
    """True the first time this marker is seen for this user in this cycle."""
    state = dict(user.notify_state or {})
    if state.get(marker):
        return False
    state[marker] = utcnow().isoformat(timespec="seconds")
    # forget markers older than 45 days so a renewed account warns again
    cutoff = (utcnow() - timedelta(days=45)).isoformat(timespec="seconds")
    state = {k: v for k, v in state.items() if v >= cutoff}
    user.notify_state = state
    db.add(user)
    return True


def reset_notifications(db: Session, user: User) -> None:
    """Called when an account is renewed or its traffic is reset."""
    user.notify_state = {}
    db.add(user)


def broadcast(db: Session, text: str, only_active: bool = False) -> dict:
    query = db.query(User).filter(User.telegram_id.isnot(None))
    if only_active:
        query = query.filter(User.status.in_((UserStatus.ACTIVE, UserStatus.ON_HOLD)))
    ok_count = 0
    errors: list[str] = []
    for user in query.all():
        ok, err = send(db, user.telegram_id, text)
        if ok:
            ok_count += 1
        elif len(errors) < 5:
            errors.append(f"{user.username}: {err}")
    return {"sent": ok_count, "errors": errors}
