"""The self-service portal: a public page keyed by username.

A customer types the username they already use to connect and gets back
everything they need — usage, days left, device limit, the subscription link,
per-protocol configs and QR codes — plus a box to register their Telegram id
so the panel can warn them before the account runs out.

No password is asked for on purpose (that is the whole point of the page), so
the lookup is rate limited per IP and never reveals whether a username exists
beyond a generic message.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import User
from app.services import settings_store, telegram

router = APIRouter(prefix="/api/portal", tags=["portal"])

# ip -> recent attempt timestamps
_ATTEMPTS: dict[str, deque] = defaultdict(lambda: deque(maxlen=40))
WINDOW_SECONDS = 60
MAX_PER_WINDOW = 12


class LookupRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)


class TelegramRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    telegram_id: str = Field(default="", max_length=32)


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "?"


def _rate_limit(request: Request) -> None:
    ip = _client_ip(request)
    now = time.monotonic()
    bucket = _ATTEMPTS[ip]
    while bucket and now - bucket[0] > WINDOW_SECONDS:
        bucket.popleft()
    if len(bucket) >= MAX_PER_WINDOW:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            "تعداد درخواست‌ها زیاد است، یک دقیقه صبر کنید",
        )
    bucket.append(now)


def _enabled(db: Session) -> dict:
    cfg = settings_store.load(db)
    if not cfg.get("portal_enabled", True):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "این صفحه غیرفعال است")
    return cfg


def _find(db: Session, username: str, migrate: bool = True) -> tuple[User, bool]:
    """The account for this username, migrating it from the old panel if needed.

    Returns (user, migrated_now). This is what makes one link enough for every
    customer: whoever is already here just sees their account, and whoever is
    still on the old panel is moved over — with their usage, remaining days and
    device count — the first time they open the page.
    """
    name = username.strip()
    user = (
        db.query(User)
        .filter(func.lower(User.username) == name.lower())
        .one_or_none()
    )
    if user is not None:
        return user, False

    cfg = settings_store.load(db)
    if migrate and cfg.get("migrate_enabled", True):
        from app.services import migration as migration_service

        claimed = migration_service.claim(
            db, name, group_id=int(cfg.get("migrate_group_id") or 0) or None
        )
        if claimed is not None:
            return claimed, True

    raise HTTPException(
        status.HTTP_404_NOT_FOUND,
        "کاربری با این نام پیدا نشد. املای نام کاربری را دقیق وارد کنید "
        "(همان نامی که در پنل قبلی داشتید).",
    )


@router.get("/config")
def portal_config(db: Session = Depends(get_db)):
    """What the public page needs before anyone types anything."""
    cfg = settings_store.load(db)
    return {
        "brand": cfg["brand_name"],
        "enabled": bool(cfg.get("portal_enabled", True)),
        "note": cfg.get("portal_note", ""),
        "telegram": bool(cfg.get("telegram_bot_token")),
        "support": cfg.get("telegram_support", ""),
        "migrate": bool(cfg.get("migrate_enabled", True)),
    }


@router.post("/lookup")
def lookup(payload: LookupRequest, request: Request, db: Session = Depends(get_db)):
    _enabled(db)
    _rate_limit(request)
    user, migrated = _find(db, payload.username)

    from app.api.routes.subscription import _origin, user_payload

    host, scheme = _origin(request)
    data = user_payload(db, user, host, scheme)
    data["migrated"] = migrated
    data["telegram_id"] = str(user.telegram_id) if user.telegram_id else ""
    data["telegram_enabled"] = telegram.enabled(db)
    # the page links straight to the personal page, which is bookmarkable
    data["page_url"] = (
        f"{settings_store.page_base_url(db, host, scheme)}/u/{user.sub_id}"
    )
    return data


@router.post("/telegram")
def save_telegram(payload: TelegramRequest, request: Request,
                  db: Session = Depends(get_db)):
    """Register (or clear) the Telegram id used for reminders."""
    _enabled(db)
    _rate_limit(request)
    user, _ = _find(db, payload.username, migrate=False)

    raw = payload.telegram_id.strip().lstrip("@")
    if not raw:
        user.telegram_id = None
        db.add(user)
        db.commit()
        return {"ok": True, "telegram_id": "", "message": "یادآوری تلگرام خاموش شد"}

    if not raw.isdigit():
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "آی‌دی عددی تلگرام لازم است. آن را از ربات @userinfobot بگیرید.",
        )

    user.telegram_id = int(raw)
    db.add(user)
    db.commit()

    ok, error = telegram.send(
        db,
        user.telegram_id,
        f"✅ <b>{user.username}</b>\nاز این پس یادآوری اتمام حجم و زمان اشتراک "
        "را همین‌جا دریافت می‌کنید.",
    )
    if not ok:
        return {
            "ok": True,
            "telegram_id": raw,
            "message": "آی‌دی ذخیره شد، ولی پیام آزمایشی ارسال نشد: "
                       + (error or "ابتدا ربات را استارت کنید"),
        }
    return {"ok": True, "telegram_id": raw, "message": "ثبت شد — پیام آزمایشی فرستاده شد"}
