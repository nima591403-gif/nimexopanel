"""A second, tiny HTTP listener that serves only the subscription endpoints.

Keeping the panel and the subscription on separate ports means only the
subscription port has to be exposed publicly (or forwarded through a relay),
while the admin panel can stay on a port you never publish.
"""
import logging
import threading
import time

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse

from app.api.routes import portal, subscription
from app.config import settings

logger = logging.getLogger(__name__)
_thread: threading.Thread | None = None
_server: uvicorn.Server | None = None


def build_app() -> FastAPI:
    app = FastAPI(title="Subscription", docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(
        CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
    )
    app.include_router(subscription.router)
    app.include_router(portal.router)

    # The user-facing pages are served from here as well, so a customer only
    # ever needs the subscription port open — clicking the subscription link
    # in a browser lands on a real page instead of a redirect into the
    # admin port, which is usually not published at all.
    from pathlib import Path

    from fastapi.responses import FileResponse
    from fastapi.staticfiles import StaticFiles

    from app.main import FRONTEND_DIR

    if Path(FRONTEND_DIR).is_dir():
        assets = Path(FRONTEND_DIR) / "assets"
        if assets.is_dir():
            app.mount("/assets", StaticFiles(directory=assets), name="assets")

        @app.get("/", include_in_schema=False)
        def root():
            return RedirectResponse("/portal", 302)

        @app.get("/{full_path:path}", include_in_schema=False)
        def spa(full_path: str):
            candidate = Path(FRONTEND_DIR) / full_path
            if full_path and candidate.is_file():
                return FileResponse(candidate)
            return FileResponse(
                Path(FRONTEND_DIR) / "index.html",
                headers={"cache-control": "no-store, must-revalidate"},
            )
    else:
        @app.get("/", include_in_schema=False)
        def root_plain():
            return {"ok": True}

    return app


def start() -> None:
    """Run the subscription listener when it is configured on its own port."""
    global _thread, _server
    port = settings.SUB_PORT
    if not port or port == settings.PORT or _thread is not None:
        return

    # Serve TLS directly when a certificate has been issued for this host, so
    # the subscription link can be an https:// URL on the configured domain.
    import os

    from app.services import settings_store

    cfg = settings_store.load()
    cert, key = cfg.get("panel_cert", ""), cfg.get("panel_key", "")
    tls = {}
    if cert and key and os.path.exists(cert) and os.path.exists(key):
        tls = {"ssl_certfile": cert, "ssl_keyfile": key}

    config = uvicorn.Config(
        build_app(),
        host=settings.HOST,
        port=port,
        log_level="warning",
        proxy_headers=True,
        forwarded_allow_ips="*",
        **tls,
    )
    _server = uvicorn.Server(config)
    _thread = threading.Thread(target=_server.run, daemon=True, name="subscription")
    _thread.start()
    logger.warning(
        "subscription listener started on port %s (%s)",
        port, "https" if tls else "http",
    )


def is_tls() -> bool:
    """Whether the running listener actually speaks TLS."""
    return bool(_server is not None and _server.config.ssl_certfile)


def stop() -> None:
    global _thread, _server
    if _server is not None:
        _server.should_exit = True
    if _thread is not None:
        _thread.join(timeout=5)
    _thread = None
    _server = None


def restart() -> None:
    """Pick up a new certificate (or port) without restarting the whole panel.

    Applying a certificate flips the subscription link to https; if the
    listener kept serving plain HTTP until the next reboot, every VPN app
    would fail to fetch a link that looks perfectly correct in the panel.
    """
    stop()
    # the socket needs a moment to be released before rebinding
    time.sleep(0.5)
    start()
