"""Background jobs: node health, traffic collection and quota enforcement."""
import logging
from datetime import datetime, timedelta, timezone

from apscheduler.schedulers.background import BackgroundScheduler

from app.config import settings
from app.db import session_scope
from app.models import Node, utcnow
from app.models.enums import NodeStatus
from app.services import resellers as reseller_service
from app.services import sync as sync_service
from app.services import traffic as traffic_service
from app.services.node_manager import NodeError, agent_for
from app.services.ssh import SSHError

logger = logging.getLogger(__name__)
scheduler = BackgroundScheduler(timezone="UTC")


def job_node_health() -> None:
    with session_scope() as db:
        for node in db.query(Node).filter(Node.is_enabled.is_(True)).all():
            try:
                info = agent_for(node).sysinfo()
            except (SSHError, NodeError) as exc:
                node.status = NodeStatus.OFFLINE
                node.status_message = str(exc)[:500]
                db.add(node)
                continue
            node.cpu_percent = info.get("cpu_percent", 0.0)
            node.mem_percent = (info.get("memory") or {}).get("percent", 0.0)
            node.disk_percent = (info.get("disk") or {}).get("percent", 0.0)
            node.uptime_seconds = info.get("uptime", 0)
            node.net_tx_speed = (info.get("net_speed") or {}).get("tx", 0.0)
            node.net_rx_speed = (info.get("net_speed") or {}).get("rx", 0.0)
            cores = info.get("cores", {}) or {}
            merged = dict(node.installed_cores or {})
            merged.update(cores)
            node.installed_cores = merged
            node.xray_version = cores.get("xray", node.xray_version)
            node.agent_version = info.get("agent_version", node.agent_version)
            node.status = NodeStatus.ONLINE
            node.status_message = ""
            node.last_seen = utcnow()
            db.add(node)


def job_collect_traffic() -> None:
    with session_scope() as db:
        traffic_service.collect_all(db)


def job_enforce_limits() -> None:
    with session_scope() as db:
        changed = traffic_service.enforce_limits(db)
        reseller_changes = reseller_service.enforce_quotas(db)
        if reseller_changes:
            logger.info("reseller quota enforcement: %s", reseller_changes)
            changed = {**changed, **reseller_changes}
        if changed:
            logger.info("limit enforcement: %s", changed)
            # push the new state so blocked users actually lose access
            sync_service.sync_all(db)


def job_notify() -> None:
    """Warn users on Telegram before their plan runs out."""
    from app.services import telegram as telegram_service

    with session_scope() as db:
        result = telegram_service.notify_expiring(db)
        if result.get("expiry") or result.get("quota"):
            logger.info("telegram reminders: %s", result)


def job_initial_sync() -> None:
    """Push the database state to every node once, shortly after boot.

    Keeps the nodes correct after an upgrade that changed how configs are
    generated, without waiting for someone to press "sync" in the UI.
    """
    with session_scope() as db:
        reports = sync_service.sync_all(db)
        for name, report in reports.items():
            failures = {k: v for k, v in report.items() if not v.get("ok", True)}
            if failures:
                logger.warning("initial sync issues on %s: %s", name, failures)


def start() -> None:
    if scheduler.running:
        return
    scheduler.add_job(
        job_initial_sync, "date",
        run_date=datetime.now(timezone.utc) + timedelta(seconds=20),
        id="initial_sync", misfire_grace_time=120,
    )
    scheduler.add_job(job_node_health, "interval",
                      seconds=settings.NODE_HEALTH_INTERVAL, id="node_health",
                      max_instances=1, coalesce=True)
    scheduler.add_job(job_collect_traffic, "interval",
                      seconds=settings.TRAFFIC_SYNC_INTERVAL, id="traffic",
                      max_instances=1, coalesce=True)
    scheduler.add_job(job_enforce_limits, "interval",
                      seconds=settings.EXPIRY_CHECK_INTERVAL, id="limits",
                      max_instances=1, coalesce=True)
    scheduler.add_job(job_notify, "interval", minutes=30, id="notify",
                      max_instances=1, coalesce=True)
    scheduler.start()
    logger.info("scheduler started")


def stop() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
