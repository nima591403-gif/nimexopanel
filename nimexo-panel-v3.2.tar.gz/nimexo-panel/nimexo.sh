#!/usr/bin/env bash
# NimexoPanel control menu — installed as /usr/local/bin/nimexo
set -uo pipefail

APP_DIR=/opt/nimexo
REPO_DIR="$APP_DIR/src"
VENV="$APP_DIR/venv"
ENV_FILE="$APP_DIR/.env"
DB_FILE="$APP_DIR/panel.db"
SERVICE=nimexo-panel

c_title() { printf "\033[1;35m%s\033[0m\n" "$*"; }
c_ok()    { printf "\033[1;32m%s\033[0m\n" "$*"; }
c_warn()  { printf "\033[1;33m%s\033[0m\n" "$*"; }
c_err()   { printf "\033[1;31m%s\033[0m\n" "$*"; }
pause()   { echo; read -rp "برای بازگشت Enter بزن…" _; }

[[ $EUID -eq 0 ]] || { c_err "با root اجرا کن: sudo nimexo"; exit 1; }
[[ -f "$ENV_FILE" ]] || { c_err "پنل نصب نیست ($ENV_FILE پیدا نشد)."; exit 1; }

env_get() { grep -E "^$1=" "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2-; }

env_set() {
  local key="$1" value="$2"
  if grep -qE "^$key=" "$ENV_FILE"; then
    sed -i -E "s|^$key=.*|$key=$value|" "$ENV_FILE"
  else
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
  fi
}

# run a snippet inside the panel's own virtualenv and app package
py() { (cd "$REPO_DIR/backend" && set -a && . "$ENV_FILE" && set +a && "$VENV/bin/python" -c "$1"); }

public_ip() { curl -s -4 --max-time 5 ifconfig.me 2>/dev/null || echo "SERVER_IP"; }

status_line() {
  if systemctl is-active --quiet "$SERVICE"; then
    local since
    since=$(systemctl show -p ActiveEnterTimestamp --value "$SERVICE" 2>/dev/null)
    c_ok "● در حال اجرا   (از $since)"
  else
    c_err "● متوقف است"
  fi
}

# --------------------------------------------------------------------------
show_status() {
  c_title "── وضعیت پنل"
  status_line
  echo
  systemctl status "$SERVICE" --no-pager -n 12 2>/dev/null | sed -n '1,20p'
  pause
}

restart_panel() {
  c_title "── ری‌استارت پنل"
  systemctl restart "$SERVICE"
  sleep 3
  status_line
  if ! systemctl is-active --quiet "$SERVICE"; then
    c_warn "۲۰ خط آخر لاگ:"
    journalctl -u "$SERVICE" -n 20 --no-pager
  fi
  pause
}

toggle_panel() {
  if systemctl is-active --quiet "$SERVICE"; then
    systemctl stop "$SERVICE"; c_warn "پنل متوقف شد."
  else
    systemctl start "$SERVICE"; sleep 2; status_line
  fi
  pause
}

live_logs() {
  c_title "── لاگ زنده (برای خروج Ctrl+C)"
  journalctl -u "$SERVICE" -f -n 50
}

show_addresses() {
  local port sub_port domain ip
  port=$(env_get PORT); sub_port=$(env_get SUB_PORT); domain=$(env_get PANEL_DOMAIN)
  ip=$(public_ip)
  c_title "── آدرس‌ها و پورت‌ها"
  echo "  پورت پنل        : $port"
  echo "  پورت لینک اشتراک: $sub_port"
  echo "  دامنه           : ${domain:-—}"
  echo
  echo "  پنل مدیریت      : http://${domain:-$ip}:$port"
  echo "  صفحه کاربران    : http://${domain:-$ip}:$sub_port/portal"
  echo
  c_title "── آیا پورت‌ها گوش می‌دهند؟"
  for p in "$port" "$sub_port"; do
    if ss -lntp 2>/dev/null | grep -q ":$p "; then
      c_ok "  ✓ $p روی سرور باز است"
    else
      c_err "  ✗ $p گوش نمی‌دهد"
    fi
  done
  echo
  c_warn "  اگر پورت روی سرور باز است ولی از گوشی جواب نمی‌دهد، فایروال ارائه‌دهنده"
  c_warn "  یا تانل را چک کن (گزینه ۷ پورت‌ها را روی ufw باز می‌کند)."
  pause
}

open_firewall() {
  local port sub_port
  port=$(env_get PORT); sub_port=$(env_get SUB_PORT)
  c_title "── باز کردن پورت‌ها"
  if ! command -v ufw >/dev/null 2>&1; then
    c_warn "ufw نصب نیست — احتمالاً فایروالی روی سرور فعال نیست."
    pause; return
  fi
  ufw allow "$port"/tcp >/dev/null && c_ok "  ✓ $port/tcp"
  ufw allow "$sub_port"/tcp >/dev/null && c_ok "  ✓ $sub_port/tcp"
  echo
  ufw status | sed -n '1,20p'
  pause
}

reset_admin() {
  c_title "── گذرواژه ادمین"
  read -rp "نام کاربری [admin]: " user; user=${user:-admin}
  read -rp "گذرواژه جدید (خالی = تولید خودکار): " pass
  [[ -n "$pass" ]] || pass=$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-14)
  py "
from app.db import session_scope
from app.models import Admin
from app.models.enums import AdminRole
from app.utils.crypto import hash_password
with session_scope() as db:
    admin = db.query(Admin).filter(Admin.username == '$user').one_or_none()
    if admin is None:
        admin = Admin(username='$user', role=AdminRole.SUDO)
        db.add(admin)
    admin.password_hash = hash_password('$pass')
    admin.is_active = True
    print('ok')
" >/dev/null && {
    c_ok "  نام کاربری: $user"
    c_ok "  گذرواژه   : $pass"
  } || c_err "  تغییر گذرواژه ناموفق بود."
  pause
}

change_ports() {
  local port sub_port
  port=$(env_get PORT); sub_port=$(env_get SUB_PORT)
  c_title "── تغییر پورت‌ها"
  read -rp "پورت پنل [$port]: " new_port; new_port=${new_port:-$port}
  read -rp "پورت لینک اشتراک [$sub_port]: " new_sub; new_sub=${new_sub:-$sub_port}
  env_set PORT "$new_port"
  env_set SUB_PORT "$new_sub"
  c_ok "  ذخیره شد. در حال ری‌استارت…"
  systemctl restart "$SERVICE"; sleep 3; status_line
  pause
}

# --------------------------------------------------------------------------
# The question that actually comes up: an app says the subscription imported
# but adds nothing. That means the link returned zero configs, and the cause
# is almost always that the account has no inbound assigned to it.
check_subscription() {
  c_title "── تست لینک اشتراک یک کاربر"
  read -rp "نام کاربری: " who
  [[ -n "$who" ]] || { pause; return; }
  py "
import base64, urllib.request
from app.db import session_scope
from app.models import User, Inbound, Node, NodeInbound
from app.services import settings_store, sync as sync_service
from app.config import settings

with session_scope() as db:
    user = db.query(User).filter(User.username == '$who').one_or_none()
    if user is None:
        print('NOTFOUND'); raise SystemExit
    url = f\"{settings_store.sub_base_url(db)}/{user.sub_id}\"
    inbounds = sync_service.effective_inbounds(db, user)
    nodes = sync_service.effective_nodes(db, user)
    pairs = 0
    keys = {(ni.inbound_id, ni.node_id) for ni in db.query(NodeInbound).filter(
        NodeInbound.is_enabled.is_(True)).all()}
    for n in nodes:
        for i in inbounds:
            if (i.id, n.id) in keys:
                pairs += 1
    print('URL', url)
    print('STATUS', user.status.value)
    print('INBOUNDS', len(inbounds))
    print('NODES', len(nodes))
    print('PAIRS', pairs)
    print('TOTAL_INBOUNDS', db.query(Inbound).count())
    print('DEFAULTS', db.query(Inbound).filter(Inbound.is_default.is_(True)).count())
    local = f'http://127.0.0.1:{settings.SUB_PORT or settings.PORT}/{settings_store.load(db)[\"sub_path\"]}/{user.sub_id}'
    try:
        body = urllib.request.urlopen(local, timeout=10).read().decode()
        text = base64.b64decode(body).decode('utf-8', 'replace') if body.strip() else ''
        print('FETCH', len([l for l in text.splitlines() if l.strip()]))
    except Exception as exc:
        print('FETCHERR', exc)
" > /tmp/nimexo-subcheck.txt 2>/tmp/nimexo-subcheck.err

  if grep -q NOTFOUND /tmp/nimexo-subcheck.txt 2>/dev/null; then
    c_err "  کاربری با این نام نیست."
    pause; return
  fi
  if [[ ! -s /tmp/nimexo-subcheck.txt ]]; then
    c_err "  خطا:"; sed -n '1,15p' /tmp/nimexo-subcheck.err
    pause; return
  fi

  local url status inb nodes pairs total defaults fetched
  url=$(awk '/^URL/{print $2}' /tmp/nimexo-subcheck.txt)
  status=$(awk '/^STATUS/{print $2}' /tmp/nimexo-subcheck.txt)
  inb=$(awk '/^INBOUNDS/{print $2}' /tmp/nimexo-subcheck.txt)
  nodes=$(awk '/^NODES/{print $2}' /tmp/nimexo-subcheck.txt)
  pairs=$(awk '/^PAIRS/{print $2}' /tmp/nimexo-subcheck.txt)
  total=$(awk '/^TOTAL_INBOUNDS/{print $2}' /tmp/nimexo-subcheck.txt)
  defaults=$(awk '/^DEFAULTS/{print $2}' /tmp/nimexo-subcheck.txt)
  fetched=$(awk '/^FETCH /{print $2}' /tmp/nimexo-subcheck.txt)

  echo
  echo "  لینک           : $url"
  echo "  وضعیت کاربر    : $status"
  echo "  اینباندهای مجاز: $inb  (کل اینباندها: $total، پیش‌فرض: $defaults)"
  echo "  نودهای مجاز    : $nodes"
  echo "  کانفیگ نهایی   : $pairs"
  echo
  if [[ -n "${fetched:-}" && "$fetched" -gt 0 ]]; then
    c_ok "  ✓ لینک $fetched کانفیگ برمی‌گرداند — از داخل سرور سالم است."
    c_warn "  اگر برنامه می‌گوید import موفق بود ولی چیزی اضافه نشد، یعنی"
    c_warn "  برنامه نتوانسته لینک را از اینترنت بگیرد: پورت را از بیرون تست کن."
  else
    c_err "  ✗ لینک خالی برمی‌گردد — برنامه «موفق» می‌گوید ولی چیزی اضافه نمی‌کند."
    echo
    if [[ "$total" == "0" ]]; then
      c_warn "  علت: هیچ اینباندی در پنل ساخته نشده."
    elif [[ "$pairs" == "0" ]]; then
      c_warn "  علت: به این کاربر هیچ اینباندی روی هیچ نودی داده نشده."
      c_warn "  راه حل: در صفحه پروتکل‌ها اینباند را روی نود اعمال کن و گزینه"
      c_warn "  «به همه کاربران اضافه شود» را روشن کن، یا کاربر را در یک پلن بگذار."
    elif [[ "$status" != "active" && "$status" != "on_hold" ]]; then
      c_warn "  علت: وضعیت کاربر $status است (منقضی/محدود/غیرفعال)."
    fi
  fi
  pause
}

backup_db() {
  local dest="$APP_DIR/backup-$(date +%Y%m%d-%H%M%S).db"
  c_title "── بکاپ دیتابیس"
  if command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 "$DB_FILE" ".backup '$dest'" && c_ok "  ذخیره شد: $dest"
  else
    cp "$DB_FILE" "$dest" && c_ok "  ذخیره شد: $dest"
  fi
  ls -1t "$APP_DIR"/backup-*.db 2>/dev/null | tail -n +11 | xargs -r rm -f
  pause
}

update_panel() {
  c_title "── بروزرسانی"
  echo "  فایل نسخه جدید را در یک پوشه باز کن و آنجا bash install.sh را بزن."
  echo "  همان کار همه چیز را جایگزین و سرویس را ری‌استارت می‌کند."
  echo
  read -rp "مسیر پوشه نسخه جدید (خالی = انصراف): " path
  [[ -n "$path" && -f "$path/install.sh" ]] || { c_warn "  انصراف."; pause; return; }
  (cd "$path" && bash install.sh)
  pause
}

agent_version() {
  c_title "── نسخه‌ها"
  echo -n "  ایجنت در این نسخه : "
  grep -E '^AGENT_VERSION' "$REPO_DIR/agent/nimexo_agent.py" 2>/dev/null | cut -d'"' -f2
  echo -n "  Xray پین‌شده      : "
  grep -E '^XRAY_VERSION' "$REPO_DIR/agent/nimexo_agent.py" 2>/dev/null | cut -d'"' -f2
  echo
  c_warn "  بعد از هر بروزرسانی، در صفحه نودها دکمه همگام‌سازی را بزن"
  c_warn "  تا ایجنت جدید روی نودها برود."
  pause
}

menu() {
  while true; do
    clear
    c_title "╔══════════════════════════════════════╗"
    c_title "║           NimexoPanel                ║"
    c_title "╚══════════════════════════════════════╝"
    printf "  "; status_line
    echo
    echo "   1) وضعیت پنل"
    echo "   2) ری‌استارت پنل"
    echo "   3) توقف / شروع"
    echo "   4) لاگ زنده"
    echo "   5) آدرس‌ها و پورت‌ها"
    echo "   6) تست لینک اشتراک یک کاربر"
    echo "   7) باز کردن پورت‌ها در فایروال"
    echo "   8) گذرواژه ادمین"
    echo "   9) تغییر پورت پنل / اشتراک"
    echo "  10) بکاپ دیتابیس"
    echo "  11) نسخه‌ها"
    echo "  12) بروزرسانی"
    echo "   0) خروج"
    echo
    read -rp "  انتخاب: " choice
    case "$choice" in
      1) show_status ;;
      2) restart_panel ;;
      3) toggle_panel ;;
      4) live_logs ;;
      5) show_addresses ;;
      6) check_subscription ;;
      7) open_firewall ;;
      8) reset_admin ;;
      9) change_ports ;;
      10) backup_db ;;
      11) agent_version ;;
      12) update_panel ;;
      0) exit 0 ;;
      *) ;;
    esac
  done
}

case "${1:-}" in
  restart) systemctl restart "$SERVICE"; sleep 2; status_line ;;
  start)   systemctl start "$SERVICE"; sleep 2; status_line ;;
  stop)    systemctl stop "$SERVICE"; c_warn "متوقف شد." ;;
  status)  status_line ;;
  log|logs) journalctl -u "$SERVICE" -f -n 50 ;;
  *)       menu ;;
esac
