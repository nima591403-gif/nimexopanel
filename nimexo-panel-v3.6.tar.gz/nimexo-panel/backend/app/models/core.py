"""SQLAlchemy models for the panel."""
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    Column,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Table,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base
from app.models.enums import (
    AdminRole,
    CoreType,
    DataLimitStrategy,
    GroupKind,
    Network,
    NodeStatus,
    Protocol,
    Security,
    SSHAuthMethod,
    UserStatus,
)


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


# --------------------------------------------------------------------------
# association tables
# --------------------------------------------------------------------------
group_inbounds = Table(
    "group_inbounds",
    Base.metadata,
    Column("group_id", ForeignKey("groups.id", ondelete="CASCADE"), primary_key=True),
    Column("inbound_id", ForeignKey("inbounds.id", ondelete="CASCADE"), primary_key=True),
)

group_nodes = Table(
    "group_nodes",
    Base.metadata,
    Column("group_id", ForeignKey("groups.id", ondelete="CASCADE"), primary_key=True),
    Column("node_id", ForeignKey("nodes.id", ondelete="CASCADE"), primary_key=True),
)

user_inbounds = Table(
    "user_inbounds",
    Base.metadata,
    Column("user_id", ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("inbound_id", ForeignKey("inbounds.id", ondelete="CASCADE"), primary_key=True),
)

user_nodes = Table(
    "user_nodes",
    Base.metadata,
    Column("user_id", ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("node_id", ForeignKey("nodes.id", ondelete="CASCADE"), primary_key=True),
)


# --------------------------------------------------------------------------
# admins
# --------------------------------------------------------------------------
class Admin(Base):
    __tablename__ = "admins"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[AdminRole] = mapped_column(Enum(AdminRole), default=AdminRole.ADMIN)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")

    # reseller limits (0 == unlimited)
    traffic_quota: Mapped[int] = mapped_column(BigInteger, default=0)
    traffic_used: Mapped[int] = mapped_column(BigInteger, default=0)
    user_quota: Mapped[int] = mapped_column(Integer, default=0)
    expire_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # what a reseller is allowed to hand out (empty list == everything)
    allowed_group_ids: Mapped[list] = mapped_column(JSON, default=list)
    allowed_inbound_ids: Mapped[list] = mapped_column(JSON, default=list)
    allowed_node_ids: Mapped[list] = mapped_column(JSON, default=list)
    # when the quota runs out, should the reseller's users be cut off?
    suspend_on_exhausted: Mapped[bool] = mapped_column(Boolean, default=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_login_ip: Mapped[str] = mapped_column(String(64), default="")

    users: Mapped[list["User"]] = relationship(back_populates="owner")


# --------------------------------------------------------------------------
# nodes
# --------------------------------------------------------------------------
class Node(Base):
    """A remote server that terminates VPN traffic.

    The panel talks to nodes exclusively over SSH so no extra inbound port
    has to be opened on the node itself.
    """

    __tablename__ = "nodes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(64), unique=True)
    address: Mapped[str] = mapped_column(String(255))            # IP or hostname
    public_address: Mapped[str] = mapped_column(String(255), default="")
    country: Mapped[str] = mapped_column(String(8), default="")  # ISO code for the flag
    ssh_port: Mapped[int] = mapped_column(Integer, default=22)
    ssh_user: Mapped[str] = mapped_column(String(64), default="root")
    auth_method: Mapped[SSHAuthMethod] = mapped_column(
        Enum(SSHAuthMethod), default=SSHAuthMethod.PASSWORD
    )
    secret_enc: Mapped[str] = mapped_column(Text, default="")     # encrypted password/key
    key_passphrase_enc: Mapped[str] = mapped_column(Text, default="")
    host_key: Mapped[str] = mapped_column(String(255), default="")  # pinned fingerprint

    status: Mapped[NodeStatus] = mapped_column(Enum(NodeStatus), default=NodeStatus.UNKNOWN)
    status_message: Mapped[str] = mapped_column(Text, default="")
    last_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    installed_cores: Mapped[dict] = mapped_column(JSON, default=dict)  # {core: version}
    xray_version: Mapped[str] = mapped_column(String(32), default="")
    agent_version: Mapped[str] = mapped_column(String(32), default="")

    # live metrics captured by the health job
    cpu_percent: Mapped[float] = mapped_column(Float, default=0.0)
    mem_percent: Mapped[float] = mapped_column(Float, default=0.0)
    disk_percent: Mapped[float] = mapped_column(Float, default=0.0)
    uptime_seconds: Mapped[int] = mapped_column(BigInteger, default=0)
    net_tx_speed: Mapped[float] = mapped_column(Float, default=0.0)
    net_rx_speed: Mapped[float] = mapped_column(Float, default=0.0)

    up_bytes: Mapped[int] = mapped_column(BigInteger, default=0)
    down_bytes: Mapped[int] = mapped_column(BigInteger, default=0)

    usage_coefficient: Mapped[float] = mapped_column(Float, default=1.0)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str] = mapped_column(Text, default="")

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    node_inbounds: Mapped[list["NodeInbound"]] = relationship(
        back_populates="node", cascade="all, delete-orphan"
    )

    @property
    def endpoint(self) -> str:
        return self.public_address or self.address


class NodeInbound(Base):
    """Deployment state of one inbound on one node."""

    __tablename__ = "node_inbounds"
    __table_args__ = (UniqueConstraint("node_id", "inbound_id", name="uq_node_inbound"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    node_id: Mapped[int] = mapped_column(ForeignKey("nodes.id", ondelete="CASCADE"))
    inbound_id: Mapped[int] = mapped_column(ForeignKey("inbounds.id", ondelete="CASCADE"))
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    synced_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sync_error: Mapped[str] = mapped_column(Text, default="")
    # per-node override, e.g. a different public port behind a tunnel
    port_override: Mapped[int | None] = mapped_column(Integer, nullable=True)
    address_override: Mapped[str] = mapped_column(String(255), default="")

    node: Mapped[Node] = relationship(back_populates="node_inbounds")
    inbound: Mapped["Inbound"] = relationship(back_populates="node_inbounds")


# --------------------------------------------------------------------------
# inbounds
# --------------------------------------------------------------------------
class Inbound(Base):
    """A protocol endpoint template that can be deployed to many nodes."""

    __tablename__ = "inbounds"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tag: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    remark: Mapped[str] = mapped_column(String(128), default="")
    core: Mapped[CoreType] = mapped_column(Enum(CoreType))
    protocol: Mapped[Protocol] = mapped_column(Enum(Protocol))
    listen: Mapped[str] = mapped_column(String(64), default="")
    port: Mapped[int] = mapped_column(Integer)

    network: Mapped[Network] = mapped_column(Enum(Network), default=Network.TCP)
    security: Mapped[Security] = mapped_column(Enum(Security), default=Security.NONE)

    # transport / tls details
    sni: Mapped[str] = mapped_column(String(255), default="")
    host: Mapped[str] = mapped_column(String(255), default="")
    path: Mapped[str] = mapped_column(String(255), default="")
    service_name: Mapped[str] = mapped_column(String(128), default="")
    header_type: Mapped[str] = mapped_column(String(32), default="")
    alpn: Mapped[str] = mapped_column(String(64), default="")
    fingerprint: Mapped[str] = mapped_column(String(32), default="chrome")
    flow: Mapped[str] = mapped_column(String(32), default="")
    allow_insecure: Mapped[bool] = mapped_column(Boolean, default=False)

    # reality
    reality_public_key: Mapped[str] = mapped_column(String(128), default="")
    reality_private_key: Mapped[str] = mapped_column(String(128), default="")
    reality_short_ids: Mapped[list] = mapped_column(JSON, default=list)
    reality_dest: Mapped[str] = mapped_column(String(255), default="")
    reality_server_names: Mapped[list] = mapped_column(JSON, default=list)

    # tls certificate (file paths on the node)
    cert_path: Mapped[str] = mapped_column(String(255), default="")
    key_path: Mapped[str] = mapped_column(String(255), default="")

    # protocol specific extras (ss method, wg subnet, ovpn cipher, ...)
    settings: Mapped[dict] = mapped_column(JSON, default=dict)
    stream_settings: Mapped[dict] = mapped_column(JSON, default=dict)
    sniffing: Mapped[bool] = mapped_column(Boolean, default=False)

    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    # if true the inbound is added to every user automatically
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    node_inbounds: Mapped[list[NodeInbound]] = relationship(
        back_populates="inbound", cascade="all, delete-orphan"
    )
    groups: Mapped[list["Group"]] = relationship(
        secondary=group_inbounds, back_populates="inbounds"
    )
    users: Mapped[list["User"]] = relationship(
        secondary=user_inbounds, back_populates="inbounds"
    )


# --------------------------------------------------------------------------
# groups (plans)
# --------------------------------------------------------------------------
class Group(Base):
    """A sellable plan: quota + duration + device limit + allowed endpoints."""

    __tablename__ = "groups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(64), unique=True)
    title: Mapped[str] = mapped_column(String(128), default="")
    kind: Mapped[GroupKind] = mapped_column(Enum(GroupKind), default=GroupKind.CUSTOM)
    description: Mapped[str] = mapped_column(Text, default="")

    data_limit: Mapped[int] = mapped_column(BigInteger, default=0)     # bytes, 0 = ∞
    duration_days: Mapped[int] = mapped_column(Integer, default=0)     # 0 = never
    device_limit: Mapped[int] = mapped_column(Integer, default=0)      # 0 = ∞
    data_limit_strategy: Mapped[DataLimitStrategy] = mapped_column(
        Enum(DataLimitStrategy), default=DataLimitStrategy.NO_RESET
    )
    # start counting only on first connection
    on_hold: Mapped[bool] = mapped_column(Boolean, default=False)

    price: Mapped[int] = mapped_column(BigInteger, default=0)          # Toman
    max_users: Mapped[int] = mapped_column(Integer, default=0)         # 0 = ∞
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_public: Mapped[bool] = mapped_column(Boolean, default=True)     # visible to bot/shop
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    inbounds: Mapped[list[Inbound]] = relationship(
        secondary=group_inbounds, back_populates="groups"
    )
    nodes: Mapped[list[Node]] = relationship(secondary=group_nodes)
    users: Mapped[list["User"]] = relationship(back_populates="group")


# --------------------------------------------------------------------------
# users
# --------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    # shared credential used by ovpn / ocserv / l2tp / ss
    password: Mapped[str] = mapped_column(String(128), default="")
    uuid: Mapped[str] = mapped_column(String(64), index=True)     # vless/vmess id
    sub_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    sub_revoked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    email: Mapped[str] = mapped_column(String(128), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    group_id: Mapped[int | None] = mapped_column(
        ForeignKey("groups.id", ondelete="SET NULL"), nullable=True
    )
    owner_id: Mapped[int | None] = mapped_column(
        ForeignKey("admins.id", ondelete="SET NULL"), nullable=True
    )

    status: Mapped[UserStatus] = mapped_column(Enum(UserStatus), default=UserStatus.ACTIVE)
    data_limit: Mapped[int] = mapped_column(BigInteger, default=0)   # bytes, 0 = ∞
    used_traffic: Mapped[int] = mapped_column(BigInteger, default=0)
    lifetime_used_traffic: Mapped[int] = mapped_column(BigInteger, default=0)
    data_limit_strategy: Mapped[DataLimitStrategy] = mapped_column(
        Enum(DataLimitStrategy), default=DataLimitStrategy.NO_RESET
    )
    device_limit: Mapped[int] = mapped_column(Integer, default=0)

    expire_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # for on-hold accounts: how long the plan lasts once activated
    on_hold_duration_days: Mapped[int] = mapped_column(Integer, default=0)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
    online_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    first_connected_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_reset_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sub_last_user_agent: Mapped[str] = mapped_column(String(255), default="")
    sub_updated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # which telegram reminders have already gone out for the current cycle
    notify_state: Mapped[dict] = mapped_column(JSON, default=dict)

    # set when the panel itself disabled the account (reseller out of credit),
    # so a manually disabled user is never silently re-enabled
    suspended_by_system: Mapped[bool] = mapped_column(Boolean, default=False)

    # migration bookkeeping
    legacy_source: Mapped[str] = mapped_column(String(32), default="")
    legacy_id: Mapped[str] = mapped_column(String(64), default="", index=True)

    group: Mapped[Group | None] = relationship(back_populates="users")
    owner: Mapped[Admin | None] = relationship(back_populates="users")
    inbounds: Mapped[list[Inbound]] = relationship(
        secondary=user_inbounds, back_populates="users"
    )
    nodes: Mapped[list[Node]] = relationship(secondary=user_nodes)
    usages: Mapped[list["UserNodeUsage"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )

    @property
    def is_active(self) -> bool:
        return self.status in (UserStatus.ACTIVE, UserStatus.ON_HOLD)


# --------------------------------------------------------------------------
# traffic & sessions
# --------------------------------------------------------------------------
class UserNodeUsage(Base):
    """Cumulative counters per user per node (survives xray restarts)."""

    __tablename__ = "user_node_usage"
    __table_args__ = (UniqueConstraint("user_id", "node_id", name="uq_user_node"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    node_id: Mapped[int] = mapped_column(ForeignKey("nodes.id", ondelete="CASCADE"))
    up: Mapped[int] = mapped_column(BigInteger, default=0)
    down: Mapped[int] = mapped_column(BigInteger, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    user: Mapped[User] = relationship(back_populates="usages")


class UserCredential(Base):
    """Per-user, per-inbound generated material.

    Used by protocols that need more than a UUID/password, e.g. WireGuard
    (private key + assigned tunnel IP) or per-user OpenVPN certificates.
    """

    __tablename__ = "user_credentials"
    __table_args__ = (
        UniqueConstraint("user_id", "inbound_id", name="uq_user_inbound_cred"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    inbound_id: Mapped[int] = mapped_column(ForeignKey("inbounds.id", ondelete="CASCADE"))
    data: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class TrafficRecord(Base):
    """Hourly buckets used to draw the charts."""

    __tablename__ = "traffic_records"
    __table_args__ = (
        Index("ix_traffic_bucket", "bucket"),
        Index("ix_traffic_user_bucket", "user_id", "bucket"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bucket: Mapped[datetime] = mapped_column(DateTime)   # truncated to the hour
    user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=True
    )
    node_id: Mapped[int | None] = mapped_column(
        ForeignKey("nodes.id", ondelete="CASCADE"), nullable=True
    )
    inbound_id: Mapped[int | None] = mapped_column(
        ForeignKey("inbounds.id", ondelete="SET NULL"), nullable=True
    )
    up: Mapped[int] = mapped_column(BigInteger, default=0)
    down: Mapped[int] = mapped_column(BigInteger, default=0)


class CounterState(Base):
    """Last raw reading of a non-resettable counter (WireGuard peer, OpenVPN CN).

    Xray counters are read with `-reset` so they arrive as deltas, but wg/ovpn
    report cumulative values that also restart on reconnect — we keep the last
    reading here to derive a delta safely.
    """

    __tablename__ = "counter_states"
    __table_args__ = (
        UniqueConstraint("node_id", "kind", "key", name="uq_counter_state"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    node_id: Mapped[int] = mapped_column(ForeignKey("nodes.id", ondelete="CASCADE"))
    kind: Mapped[str] = mapped_column(String(32))     # wireguard | openvpn
    key: Mapped[str] = mapped_column(String(128))     # peer pubkey / common name
    up: Mapped[int] = mapped_column(BigInteger, default=0)
    down: Mapped[int] = mapped_column(BigInteger, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class Connection(Base):
    """Live/last-seen sessions reported by the node agents."""

    __tablename__ = "connections"
    __table_args__ = (Index("ix_conn_user", "user_id", "last_seen"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    node_id: Mapped[int | None] = mapped_column(
        ForeignKey("nodes.id", ondelete="SET NULL"), nullable=True
    )
    protocol: Mapped[Protocol | None] = mapped_column(Enum(Protocol), nullable=True)
    ip: Mapped[str] = mapped_column(String(64), default="")
    device: Mapped[str] = mapped_column(String(128), default="")
    up: Mapped[int] = mapped_column(BigInteger, default=0)
    down: Mapped[int] = mapped_column(BigInteger, default=0)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


# --------------------------------------------------------------------------
# system
# --------------------------------------------------------------------------
class Setting(Base):
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (Index("ix_audit_created", "created_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    level: Mapped[str] = mapped_column(String(16), default="info")
    actor: Mapped[str] = mapped_column(String(64), default="system")
    action: Mapped[str] = mapped_column(String(64), default="")
    target: Mapped[str] = mapped_column(String(128), default="")
    message: Mapped[str] = mapped_column(Text, default="")
    ip: Mapped[str] = mapped_column(String(64), default="")
    meta: Mapped[dict] = mapped_column(JSON, default=dict)


class ResellerTransaction(Base):
    """Every change to a reseller's traffic credit, kept as an audit trail."""

    __tablename__ = "reseller_transactions"
    __table_args__ = (Index("ix_reseller_tx", "admin_id", "created_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admin_id: Mapped[int] = mapped_column(ForeignKey("admins.id", ondelete="CASCADE"))
    # bytes; positive = credit added, negative = credit taken back
    amount: Mapped[int] = mapped_column(BigInteger, default=0)
    balance_after: Mapped[int] = mapped_column(BigInteger, default=0)
    price: Mapped[int] = mapped_column(BigInteger, default=0)   # Toman paid
    kind: Mapped[str] = mapped_column(String(16), default="credit")  # credit|debit
    note: Mapped[str] = mapped_column(Text, default="")
    created_by: Mapped[str] = mapped_column(String(64), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class LegacyAccount(Base):
    """Snapshot of an account imported from the old vpn-ui panel.

    Kept so a user can self-migrate later by typing their old credentials.
    """

    __tablename__ = "legacy_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(32), default="vpn-ui")
    username: Mapped[str] = mapped_column(String(128), index=True)
    email: Mapped[str] = mapped_column(String(128), default="")
    password: Mapped[str] = mapped_column(String(128), default="")
    uuid: Mapped[str] = mapped_column(String(64), default="")
    sub_id: Mapped[str] = mapped_column(String(64), default="", index=True)
    data_limit: Mapped[int] = mapped_column(BigInteger, default=0)
    used_traffic: Mapped[int] = mapped_column(BigInteger, default=0)
    lifetime_used: Mapped[int] = mapped_column(BigInteger, default=0)
    device_limit: Mapped[int] = mapped_column(Integer, default=0)
    telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")
    expire_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    raw: Mapped[dict] = mapped_column(JSON, default=dict)
    # WireGuard peer key pairs the old panel handed this account, keyed by the
    # new inbound tag. Reusing them is what keeps a .conf the customer already
    # installed working after the move instead of silently going dead.
    wg_peers: Mapped[dict] = mapped_column(JSON, default=dict)
    imported_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    claimed_user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    claimed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
