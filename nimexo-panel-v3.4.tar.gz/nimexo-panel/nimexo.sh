#!/usr/bin/env bash
# NimexoPanel control menu — installed as /usr/local/bin/nimexo
#
# Deliberately English: an SSH terminal has no Arabic shaping or RTL support,
# so Persian comes out as disconnected, reversed letters. The web panel stays
# Persian; this menu has to be readable over a bare TTY.
set -uo pipefail

APP_DIR=/opt/nimexo
REPO_DIR="$APP_DIR/src"
VENV="$APP_DIR/venv"
ENV_FILE="$APP_DIR/.env"
DB_FILE="$APP_DIR/panel.db"
SERVICE=nimexo-panel

c_title() { printf "\033[1;35m%s\033[0m\n" "$*"; }
c_ok()    { printf "\033[1;32m%s\033[0m\n" "$*"; }
c_warn()  { printf "\033[1;33m%s\033[0m\n" "$*"; }
c_err()   { printf "\033[1;31m%s\033[0m\n" "$*"; }
pause()   { echo; read -rp "Press Enter to go back..." _; }

[[ $EUID -eq 0 ]] || { c_err "Run as root:  sudo nimexo"; exit 1; }
[[ -f "$ENV_FILE" ]] || { c_err "Panel not installed ($ENV_FILE not found)."; exit 1; }

env_get() { grep -E "^$1=" "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2-; }

env_set() {
  local key="$1" value="$2"
  if grep -qE "^$key=" "$ENV_FILE"; then
    sed -i -E "s|^$key=.*|$key=$value|" "$ENV_FILE"
  else
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
  fi
}

# run a snippet inside the panel's own virtualenv and app package
py() { (cd "$REPO_DIR/backend" && set -a && . "$ENV_FILE" && set +a && "$VENV/bin/python" -c "$1"); }

public_ip() { curl -s -4 --max-time 5 ifconfig.me 2>/dev/null || echo "SERVER_IP"; }

status_line() {
  if systemctl is-active --quiet "$SERVICE"; then
    local since
    since=$(systemctl show -p ActiveEnterTimestamp --value "$SERVICE" 2>/dev/null)
    c_ok "RUNNING   (since $since)"
  else
    c_err "STOPPED"
  fi
}

# --------------------------------------------------------------------------
show_status() {
  c_title "-- Panel status"
  status_line
  echo
  systemctl status "$SERVICE" --no-pager -n 12 2>/dev/null | sed -n '1,20p'
  pause
}

restart_panel() {
  c_title "-- Restarting the panel"
  systemctl restart "$SERVICE"
  sleep 3
  status_line
  if ! systemctl is-active --quiet "$SERVICE"; then
    c_warn "Last 20 log lines:"
    journalctl -u "$SERVICE" -n 20 --no-pager
  fi
  pause
}

toggle_panel() {
  if systemctl is-active --quiet "$SERVICE"; then
    systemctl stop "$SERVICE"; c_warn "Panel stopped."
  else
    systemctl start "$SERVICE"; sleep 2; status_line
  fi
  pause
}

live_logs() {
  c_title "-- Live log  (Ctrl+C to exit)"
  journalctl -u "$SERVICE" -f -n 50
}

show_addresses() {
  local port sub_port domain ip
  port=$(env_get PORT); sub_port=$(env_get SUB_PORT); domain=$(env_get PANEL_DOMAIN)
  ip=$(public_ip)
  c_title "-- Addresses and ports"
  echo "  Panel port         : $port"
  echo "  Subscription port  : $sub_port"
  echo "  Domain             : ${domain:-(not set)}"
  echo
  echo "  Admin panel        : http://${domain:-$ip}:$port"
  echo "  User portal        : http://${domain:-$ip}:$sub_port/portal"
  echo
  c_title "-- Are the ports listening?"
  for p in "$port" "$sub_port"; do
    if ss -lntp 2>/dev/null | grep -q ":$p "; then
      c_ok "  OK    $p is listening on this server"
    else
      c_err "  FAIL  $p is NOT listening"
    fi
  done
  echo
  c_warn "  If a port listens here but your phone cannot reach it, the problem is"
  c_warn "  the provider firewall or your tunnel. Option 7 opens them in ufw."
  pause
}

open_firewall() {
  local port sub_port
  port=$(env_get PORT); sub_port=$(env_get SUB_PORT)
  c_title "-- Opening ports in the firewall"
  if ! command -v ufw >/dev/null 2>&1; then
    c_warn "ufw is not installed - there is probably no local firewall."
    pause; return
  fi
  ufw allow "$port"/tcp >/dev/null && c_ok "  allowed $port/tcp"
  ufw allow "$sub_port"/tcp >/dev/null && c_ok "  allowed $sub_port/tcp"
  echo
  ufw status | sed -n '1,20p'
  pause
}

reset_admin() {
  c_title "-- Admin password"
  read -rp "Username [admin]: " user; user=${user:-admin}
  read -rp "New password (empty = generate one): " pass
  [[ -n "$pass" ]] || pass=$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-14)
  py "
from app.db import session_scope
from app.models import Admin
from app.models.enums import AdminRole
from app.utils.crypto import hash_password
with session_scope() as db:
    admin = db.query(Admin).filter(Admin.username == '$user').one_or_none()
    if admin is None:
        admin = Admin(username='$user', role=AdminRole.SUDO)
        db.add(admin)
    admin.password_hash = hash_password('$pass')
    admin.is_active = True
    print('ok')
" >/dev/null 2>&1 && {
    c_ok "  username : $user"
    c_ok "  password : $pass"
  } || c_err "  Could not change the password."
  pause
}

change_ports() {
  local port sub_port
  port=$(env_get PORT); sub_port=$(env_get SUB_PORT)
  c_title "-- Change ports"
  read -rp "Panel port [$port]: " new_port; new_port=${new_port:-$port}
  read -rp "Subscription port [$sub_port]: " new_sub; new_sub=${new_sub:-$sub_port}
  env_set PORT "$new_port"
  env_set SUB_PORT "$new_sub"
  c_ok "  Saved. Restarting..."
  systemctl restart "$SERVICE"; sleep 3; status_line
  pause
}

# --------------------------------------------------------------------------
# The question that actually comes up: an app says the subscription imported
# but adds nothing. That means the link returned zero configs, and the cause
# is almost always that the account has no inbound assigned to it.
check_subscription() {
  c_title "-- Test one user's subscription link"
  read -rp "Username: " who
  [[ -n "$who" ]] || { pause; return; }
  py "
import base64, urllib.request
from app.db import session_scope
from app.models import User, Inbound, NodeInbound
from app.services import settings_store, sync as sync_service
from app.config import settings

with session_scope() as db:
    user = db.query(User).filter(User.username == '$who').one_or_none()
    if user is None:
        print('NOTFOUND'); raise SystemExit
    print('URL', f'{settings_store.sub_base_url(db)}/{user.sub_id}')
    inbounds = sync_service.effective_inbounds(db, user)
    nodes = sync_service.effective_nodes(db, user)
    keys = {(ni.inbound_id, ni.node_id) for ni in db.query(NodeInbound).filter(
        NodeInbound.is_enabled.is_(True)).all()}
    pairs = sum(1 for n in nodes for i in inbounds if (i.id, n.id) in keys)
    print('STATUS', user.status.value)
    print('INBOUNDS', len(inbounds))
    print('NODES', len(nodes))
    print('PAIRS', pairs)
    print('TOTAL_INBOUNDS', db.query(Inbound).count())
    print('DEFAULTS', db.query(Inbound).filter(Inbound.is_default.is_(True)).count())
    path = settings_store.load(db)['sub_path']
    port = settings.SUB_PORT or settings.PORT

    # What does the listener really speak? A link that says https while the
    # socket serves plain HTTP looks perfect in the panel and fails in every
    # VPN app, so probe both and report the mismatch.
    import ssl
    ctx = ssl._create_unverified_context()
    speaks = ''
    for scheme, kw in (('https', {'context': ctx}), ('http', {})):
        try:
            urllib.request.urlopen(
                f'{scheme}://127.0.0.1:{port}/{path}/{user.sub_id}', timeout=8, **kw)
            speaks = scheme
            break
        except Exception:
            continue
    print('SPEAKS', speaks or 'none')
    print('LINKSCHEME', 'https' if settings_store.sub_base_url(db).startswith('https') else 'http')

    import os
    cfg = settings_store.load(db)
    cert, key = cfg.get('panel_cert', ''), cfg.get('panel_key', '')
    print('CERT', cert or '-')
    print('CERTOK', 'yes' if cert and os.path.exists(cert) else 'no')
    print('KEY', key or '-')
    print('KEYOK', 'yes' if key and os.path.exists(key) else 'no')
    print('SUBHTTPS', cfg.get('sub_https'))

    local = f'{speaks or "http"}://127.0.0.1:{port}/{path}/{user.sub_id}'
    try:
        kw = {'context': ctx} if speaks == 'https' else {}
        body = urllib.request.urlopen(local, timeout=10, **kw).read().decode()
        text = base64.b64decode(body).decode('utf-8', 'replace') if body.strip() else ''
        print('FETCH', len([l for l in text.splitlines() if l.strip()]))
    except Exception as exc:
        print('FETCHERR', exc)
" > /tmp/nimexo-subcheck.txt 2>/tmp/nimexo-subcheck.err

  if grep -q NOTFOUND /tmp/nimexo-subcheck.txt 2>/dev/null; then
    c_err "  No user with that name."
    pause; return
  fi
  if [[ ! -s /tmp/nimexo-subcheck.txt ]]; then
    c_err "  Error:"; sed -n '1,15p' /tmp/nimexo-subcheck.err
    pause; return
  fi

  local url status inb nodes pairs total defaults fetched
  url=$(awk '/^URL/{print $2}' /tmp/nimexo-subcheck.txt)
  status=$(awk '/^STATUS/{print $2}' /tmp/nimexo-subcheck.txt)
  inb=$(awk '/^INBOUNDS/{print $2}' /tmp/nimexo-subcheck.txt)
  nodes=$(awk '/^NODES/{print $2}' /tmp/nimexo-subcheck.txt)
  pairs=$(awk '/^PAIRS/{print $2}' /tmp/nimexo-subcheck.txt)
  total=$(awk '/^TOTAL_INBOUNDS/{print $2}' /tmp/nimexo-subcheck.txt)
  defaults=$(awk '/^DEFAULTS/{print $2}' /tmp/nimexo-subcheck.txt)
  fetched=$(awk '/^FETCH /{print $2}' /tmp/nimexo-subcheck.txt)
  local speaks linkscheme cert certok key keyok subhttps
  speaks=$(awk '/^SPEAKS/{print $2}' /tmp/nimexo-subcheck.txt)
  linkscheme=$(awk '/^LINKSCHEME/{print $2}' /tmp/nimexo-subcheck.txt)
  cert=$(awk '/^CERT /{print $2}' /tmp/nimexo-subcheck.txt)
  certok=$(awk '/^CERTOK/{print $2}' /tmp/nimexo-subcheck.txt)
  key=$(awk '/^KEY /{print $2}' /tmp/nimexo-subcheck.txt)
  keyok=$(awk '/^KEYOK/{print $2}' /tmp/nimexo-subcheck.txt)
  subhttps=$(awk '/^SUBHTTPS/{print $2}' /tmp/nimexo-subcheck.txt)

  echo
  echo "  link              : $url"
  echo "  user status       : $status"
  echo "  inbounds for user : $inb   (panel has $total, $defaults marked default)"
  echo "  nodes for user    : $nodes"
  echo "  configs produced  : $pairs"
  echo "  link says         : $linkscheme"
  echo "  listener speaks   : $speaks"
  echo
  if [[ -n "$speaks" && "$speaks" != "none" && "$speaks" != "$linkscheme" ]]; then
    c_err "  MISMATCH - the link says $linkscheme but the listener speaks $speaks."
    c_err "  Every VPN app fails on this."
    echo
    echo "  certificate file  : $cert   (exists: $certok)"
    echo "  private key file  : $key   (exists: $keyok)"
    echo "  https flag        : $subhttps"
    echo
    if [[ "$certok" != "yes" || "$keyok" != "yes" ]]; then
      c_warn "  Cause: the certificate the panel was told to use is not on disk."
      c_warn "  Either re-issue it in Certificates on 'the panel itself',"
      c_warn "  or switch the link back to http with the option below."
    else
      c_warn "  Cause: the files exist but the listener did not load them."
      c_warn "  Restart the panel (option 2) and run this check again."
    fi
    echo
    read -rp "  Switch the subscription link to http now? [y/N]: " fix
    if [[ "${fix,,}" == "y" ]]; then
      py "
from app.db import session_scope
from app.services import settings_store
with session_scope() as db:
    settings_store.save(db, {'sub_https': False, 'panel_cert': '', 'panel_key': ''})
    print(settings_store.sub_base_url(db))
" && c_ok "  Done - the link is plain http now and matches the listener."
      echo
    fi
  fi
  if [[ -n "${fetched:-}" && "${fetched:-0}" -gt 0 ]]; then
    c_ok "  OK - the link returns $fetched configs from inside the server."
    c_warn "  If an app still says \"import successful\" but adds nothing, the app"
    c_warn "  could not download the link. Test the port from outside the server."
  else
    c_err "  EMPTY - the link returns nothing."
    c_err "  This is exactly why an app reports success and adds no configs."
    echo
    if [[ "$total" == "0" ]]; then
      c_warn "  Cause: no inbound exists in the panel yet."
      c_warn "  Fix  : Migration page -> import the vpn-ui inbounds, or create one."
    elif [[ "$pairs" == "0" ]]; then
      c_warn "  Cause: this user has no inbound on any node."
      c_warn "  Fix  : Protocols page -> assign the inbound to a node and turn on"
      c_warn "         'add to every user', or put the user in a plan."
    elif [[ "$status" != "active" && "$status" != "on_hold" ]]; then
      c_warn "  Cause: the user status is '$status' (expired / limited / disabled)."
    fi
  fi
  pause
}

backup_db() {
  local dest="$APP_DIR/backup-$(date +%Y%m%d-%H%M%S).db"
  c_title "-- Database backup"
  if command -v sqlite3 >/dev/null 2>&1; then
    sqlite3 "$DB_FILE" ".backup '$dest'" && c_ok "  saved: $dest"
  else
    cp "$DB_FILE" "$dest" && c_ok "  saved: $dest"
  fi
  ls -1t "$APP_DIR"/backup-*.db 2>/dev/null | tail -n +11 | xargs -r rm -f
  pause
}

update_panel() {
  c_title "-- Update"
  echo "  Unpack the new release somewhere and run 'bash install.sh' there."
  echo "  That replaces the code and restarts the service."
  echo
  read -rp "Path to the new release folder (empty = cancel): " path
  [[ -n "$path" && -f "$path/install.sh" ]] || { c_warn "  Cancelled."; pause; return; }
  (cd "$path" && bash install.sh)
  pause
}

versions() {
  c_title "-- Versions"
  echo -n "  agent shipped here : "
  grep -E '^AGENT_VERSION' "$REPO_DIR/agent/nimexo_agent.py" 2>/dev/null | cut -d'"' -f2
  echo -n "  xray pinned to     : "
  grep -E '^XRAY_VERSION' "$REPO_DIR/agent/nimexo_agent.py" 2>/dev/null | cut -d'"' -f2
  echo
  c_warn "  After every update press 'sync' on the Nodes page so the new agent"
  c_warn "  is uploaded to each node."
  pause
}

menu() {
  while true; do
    clear
    c_title "==================================="
    c_title "           NimexoPanel"
    c_title "==================================="
    printf "  status: "; status_line
    echo
    echo "   1) Panel status"
    echo "   2) Restart panel"
    echo "   3) Stop / start"
    echo "   4) Live log"
    echo "   5) Addresses and ports"
    echo "   6) Test a user's subscription link"
    echo "   7) Open ports in firewall"
    echo "   8) Admin password"
    echo "   9) Change panel / subscription port"
    echo "  10) Backup database"
    echo "  11) Versions"
    echo "  12) Update"
    echo "   0) Exit"
    echo
    read -rp "  choice: " choice
    case "$choice" in
      1) show_status ;;
      2) restart_panel ;;
      3) toggle_panel ;;
      4) live_logs ;;
      5) show_addresses ;;
      6) check_subscription ;;
      7) open_firewall ;;
      8) reset_admin ;;
      9) change_ports ;;
      10) backup_db ;;
      11) versions ;;
      12) update_panel ;;
      0) exit 0 ;;
      *) ;;
    esac
  done
}

case "${1:-}" in
  restart) systemctl restart "$SERVICE"; sleep 2; status_line ;;
  start)   systemctl start "$SERVICE"; sleep 2; status_line ;;
  stop)    systemctl stop "$SERVICE"; c_warn "stopped." ;;
  status)  status_line ;;
  log|logs) journalctl -u "$SERVICE" -f -n 50 ;;
  check)   check_subscription ;;
  *)       menu ;;
esac
