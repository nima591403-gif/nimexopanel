"""Runtime settings that live in the database instead of the .env file.

The domain and the subscription port change often enough (a new relay, a new
Cloudflare record) that editing .env and restarting the service for every change
is the wrong shape. These are read from the `settings` table with the values in
.env as the fallback, so an untouched install keeps behaving exactly as before.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.config import settings as env
from app.db import session_scope
from app.models import Setting

KEY = "panel"

DEFAULTS = {
    "brand_name": "",
    "panel_domain": "",
    "panel_public_url": "",
    "sub_domain": "",
    "sub_path": "",
    "sub_port": 0,
    "sub_https": None,        # None -> decide from the port
    "sub_profile_title": "",
    # TLS material for the panel's own listeners (issued on this host)
    "panel_cert": "",
    "panel_key": "",
    # Fallback address written into every client config when a node has no
    # public address of its own — set this once and links stop showing IPs.
    "client_domain": "",
    # self-service portal + telegram reminders
    "portal_enabled": True,
    "portal_note": "",
    "telegram_bot_token": "",
    "telegram_support": "",
    "notify_days_before": 3,
    "notify_traffic_percent": 85,
    # self-service migration from the old panel
    "migrate_enabled": True,
    "migrate_group_id": 0,
}

_cache: dict | None = None


def _row(db: Session) -> Setting:
    row = db.query(Setting).get(KEY)
    if row is None:
        row = Setting(key=KEY, value={})
        db.add(row)
        db.flush()
    return row


def load(db: Session | None = None) -> dict:
    """Stored overrides merged over the .env defaults."""
    global _cache
    if db is None:
        if _cache is not None:
            return _cache
        with session_scope() as scoped:
            data = dict(DEFAULTS)
            data.update(_row(scoped).value or {})
    else:
        data = dict(DEFAULTS)
        data.update(_row(db).value or {})

    resolved = {
        "brand_name": data["brand_name"] or env.BRAND_NAME,
        "panel_domain": data["panel_domain"] or env.PANEL_DOMAIN,
        "panel_public_url": data["panel_public_url"] or env.PANEL_PUBLIC_URL,
        "sub_domain": data["sub_domain"] or env.SUB_DOMAIN or env.PANEL_DOMAIN,
        "sub_path": (data["sub_path"] or env.SUB_PATH).strip("/") or "sub",
        "sub_port": int(data["sub_port"] or env.SUB_PORT or env.PORT),
        "sub_https": data["sub_https"],
        "sub_profile_title": data["sub_profile_title"] or env.SUB_PROFILE_TITLE,
        "panel_cert": data["panel_cert"],
        "panel_key": data["panel_key"],
        "client_domain": data["client_domain"],
        "portal_enabled": bool(data["portal_enabled"]),
        "portal_note": data["portal_note"],
        "telegram_bot_token": data["telegram_bot_token"] or env.TELEGRAM_BOT_TOKEN,
        "telegram_support": data["telegram_support"],
        "notify_days_before": int(data["notify_days_before"] or 3),
        "notify_traffic_percent": int(data["notify_traffic_percent"] or 85),
        "migrate_enabled": bool(data["migrate_enabled"]),
        "migrate_group_id": int(data["migrate_group_id"] or 0),
    }
    _cache = resolved
    return resolved


def listener_scheme(port: int) -> str | None:
    """"https"/"http" if *we* serve that port, None if something else does."""
    try:
        from app import sub_server
        from app.config import settings as _env

        own = _env.SUB_PORT or _env.PORT
        if port != own:
            return None
        if _env.SUB_PORT and _env.SUB_PORT != _env.PORT:
            return "https" if sub_server.is_tls() else "http"
        # panel and subscription share one listener, which is plain HTTP
        return "http"
    except Exception:  # noqa: BLE001
        return None


# settings the subscription listener only reads when it binds its socket
LISTENER_KEYS = ("panel_cert", "panel_key")


def save(db: Session, values: dict) -> dict:
    global _cache
    row = _row(db)
    stored = dict(row.value or {})
    changed_listener = False
    for key in DEFAULTS:
        if key in values:
            if key in LISTENER_KEYS and stored.get(key) != values[key]:
                changed_listener = True
            stored[key] = values[key]
    row.value = stored
    db.add(row)
    db.commit()
    _cache = None
    result = load(db)

    if changed_listener:
        # rebind straight away, so an https link is served over https now
        try:
            from app import sub_server

            sub_server.restart()
        except Exception:  # noqa: BLE001 — never fail a settings save over this
            import logging

            logging.getLogger(__name__).warning(
                "could not restart the subscription listener", exc_info=True
            )
    return result


def sub_base_url(db: Session | None = None, request_host: str = "",
                 request_scheme: str = "") -> str:
    """Base of every subscription link, e.g. https://panel.example.com:2097/sub

    ``request_host`` is the Host header of the call being served. When no
    domain has been configured yet it is a far better answer than 127.0.0.1 —
    a subscription link (or its QR) pointing at localhost is simply dead on
    the user's phone.
    """
    cfg = load(db)
    host_only, _, host_port = (request_host or "").partition(":")
    using_request = not cfg["sub_domain"] and bool(host_only)
    domain = cfg["sub_domain"] or host_only or "127.0.0.1"
    port = cfg["sub_port"]
    if using_request:
        # mirror exactly what the visitor reached us on: guessing the port or
        # the scheme produces a link their VPN app cannot fetch at all
        port = int(host_port) if host_port.isdigit() else (
            443 if request_scheme == "https" else 80
        )
    https = cfg["sub_https"]
    if https is None:
        if using_request and request_scheme:
            https = request_scheme == "https"
        else:
            # a certificate installed for this host means the listener is TLS
            https = bool(cfg.get("panel_cert")) or port in (
                443, 2053, 2083, 2087, 2096, 8443
            )

    # When the link points at our own listener, what that socket actually
    # speaks is the only truth that matters. A stored flag (or a certificate
    # whose file has since vanished) claiming https over a plain-HTTP socket
    # produces a link that looks right everywhere and fails in every VPN app.
    # A different port means something else terminates TLS in front of us, and
    # there the stored flag is right to win.
    listening = listener_scheme(port)
    if listening is not None:
        https = listening == "https"

    scheme = "https" if https else "http"
    netloc = domain if port in (80, 443) else f"{domain}:{port}"
    return f"{scheme}://{netloc}/{cfg['sub_path']}"


def page_base_url(db: Session | None = None, request_host: str = "",
                  request_scheme: str = "") -> str:
    """Where the end-user pages (/u/<id>, /portal) live.

    The subscription listener serves them too, so the subscription host is a
    perfectly good answer — and a much better default than the admin port,
    which is usually the one that is *not* published.
    """
    cfg = load(db)
    if cfg["panel_public_url"]:
        return cfg["panel_public_url"].rstrip("/")
    base = sub_base_url(db, request_host, request_scheme)
    return base.rsplit("/", 1)[0]


def client_host(db: Session | None = None) -> str:
    """Default hostname for client configs when a node sets none."""
    cfg = load(db)
    return (cfg["client_domain"] or cfg["sub_domain"] or "").strip()
