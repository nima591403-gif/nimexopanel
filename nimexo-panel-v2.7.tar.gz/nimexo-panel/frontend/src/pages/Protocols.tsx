import { useEffect, useState } from "react";

import { Card, Chip, Empty, Field, Modal, MultiSelect, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import { number } from "../lib/format";
import type { Inbound, Node } from "../lib/types";

interface CertRow {
  domain: string;
  cert: string;
  key: string;
  self_signed?: boolean;
}
interface NodeCerts {
  node_id: number;
  node: string;
  certs: CertRow[];
}

const PROTOCOLS = [
  { value: "vless", label: "VLESS", core: "xray" },
  { value: "vmess", label: "VMess", core: "xray" },
  { value: "trojan", label: "Trojan", core: "xray" },
  { value: "shadowsocks", label: "Shadowsocks", core: "xray" },
  { value: "wireguard", label: "WireGuard", core: "wireguard" },
  { value: "openvpn", label: "OpenVPN", core: "openvpn" },
  { value: "ocserv", label: "OpenConnect / Cisco AnyConnect", core: "ocserv" },
  { value: "l2tp", label: "L2TP/IPsec", core: "l2tp" },
  { value: "pptp", label: "PPTP", core: "pptp" },
];

const XRAY_PROTOCOLS = ["vless", "vmess", "trojan", "shadowsocks"];

/** Transports the current Xray core still supports (h2 and quic were removed). */
const NETWORKS = [
  { value: "tcp", label: "tcp (raw)" },
  { value: "ws", label: "ws — وب‌سوکت" },
  { value: "xhttp", label: "xhttp — جانشین h2/quic" },
  { value: "httpupgrade", label: "httpupgrade" },
  { value: "grpc", label: "grpc" },
  { value: "kcp", label: "kcp (mKCP، UDP)" },
];

const SECURITIES = [
  { value: "none", label: "none — بدون رمزنگاری لایه انتقال" },
  { value: "tls", label: "tls — نیاز به گواهی" },
  { value: "reality", label: "reality — بدون دامنه و گواهی" },
];

const FINGERPRINTS = ["chrome", "firefox", "safari", "ios", "android", "edge", "360", "qq", "random", "randomized"];
const TCP_HEADERS = [
  { value: "", label: "none" },
  { value: "http", label: "http (تظاهر به وب)" },
];
const KCP_HEADERS = ["none", "srtp", "utp", "wechat-video", "dtls", "wireguard", "dns"];
const XHTTP_MODES = ["auto", "packet-up", "stream-up", "stream-one"];
const SS_METHODS = [
  "2022-blake3-aes-256-gcm",
  "2022-blake3-aes-128-gcm",
  "2022-blake3-chacha20-poly1305",
  "chacha20-ietf-poly1305",
  "aes-256-gcm",
  "aes-128-gcm",
  "xchacha20-ietf-poly1305",
];
const ALPN_CHOICES = ["", "h2,http/1.1", "h2", "http/1.1", "h3"];

const TABS = [
  { key: "all", label: "نمای کلی" },
  { key: "xray", label: "V2ray / Xray" },
  { key: "openvpn", label: "OpenVPN" },
  { key: "wireguard", label: "WireGuard" },
  { key: "ocserv", label: "Cisco AnyConnect" },
  { key: "l2tp", label: "L2TP/IPsec" },
  { key: "pptp", label: "PPTP" },
];

const SETTINGS_HINTS: Record<string, string> = {
  wireguard: 'مثال: {"subnet":"10.66.0.0/24","mtu":1280,"dns":"1.1.1.1, 8.8.8.8"}',
  openvpn:
    'مثال: {"proto":"udp","subnet":"10.20.0.0","mtu":1280,"cipher":"AES-128-GCM","keepalive_timeout":300,"embed_credentials":true}',
  ocserv: 'مثال: {"subnet":"10.30.0.0","mtu":1280,"udp":true,"max_same":2}',
  l2tp: 'مثال: {"psk":"کلید-مشترک","local_ip":"10.40.0.1","range":"10.40.0.10-10.40.0.250","mtu":1280}',
  pptp: 'مثال: {"local_ip":"10.50.0.1","range":"10.50.0.10-10.50.0.250","mtu":1280}',
};

type Settings = Record<string, unknown>;

interface FormState {
  id?: number;
  tag: string;
  remark: string;
  protocol: string;
  core: string;
  listen: string;
  port: number;
  network: string;
  security: string;
  sni: string;
  host: string;
  path: string;
  service_name: string;
  header_type: string;
  flow: string;
  fingerprint: string;
  reality_public_key: string;
  reality_private_key: string;
  reality_short_ids: string;
  reality_dest: string;
  reality_server_names: string;
  cert_path: string;
  key_path: string;
  alpn: string;
  allow_insecure: boolean;
  settings: Settings;
  extra: string;
  is_enabled: boolean;
  is_default: boolean;
  sniffing: boolean;
  node_ids: number[];
}

const EMPTY: FormState = {
  tag: "",
  remark: "",
  protocol: "vless",
  core: "xray",
  listen: "",
  port: 2053,
  network: "tcp",
  security: "reality",
  sni: "dl.google.com",
  host: "",
  path: "",
  service_name: "",
  header_type: "",
  flow: "xtls-rprx-vision",
  fingerprint: "chrome",
  reality_public_key: "",
  reality_private_key: "",
  reality_short_ids: "",
  reality_dest: "",
  reality_server_names: "",
  cert_path: "",
  key_path: "",
  alpn: "",
  allow_insecure: false,
  settings: {},
  extra: "{}",
  is_enabled: true,
  is_default: false,
  sniffing: true,
  node_ids: [],
};

/** Keys the dedicated controls own; everything else stays in the JSON box. */
const MANAGED_KEYS = [
  "multi_mode",
  "grpc_authority",
  "mode",
  "method",
  "network",
  "server_password",
  "seed",
  "mkcp_key",
  "mkcp_original",
  "mtu",
  "tti",
  "uplink",
  "downlink",
  "congestion",
  "vmess_security",
  "sniff_dest_override",
  "sniff_route_only",
  "sniff_metadata_only",
  "tls_min_version",
  "tls_max_version",
  "reject_unknown_sni",
  "reality_spider_x",
  "reality_show",
  "reality_xver",
];

function splitSettings(all: Settings): { managed: Settings; extra: Settings } {
  const managed: Settings = {};
  const extra: Settings = {};
  Object.entries(all || {}).forEach(([k, v]) => {
    (MANAGED_KEYS.includes(k) ? managed : extra)[k] = v;
  });
  return { managed, extra };
}

export default function Protocols() {
  const toast = useToast();
  const [tab, setTab] = useState("all");
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState | null>(null);
  const [section, setSection] = useState("main");
  const [saving, setSaving] = useState(false);
  const [certs, setCerts] = useState<NodeCerts[]>([]);

  const load = () => {
    setLoading(true);
    api
      .get<Inbound[]>("/api/inbounds")
      .then(setInbounds)
      .finally(() => setLoading(false));
  };

  const loadCerts = () =>
    api
      .get<NodeCerts[]>("/api/certificates")
      .then(setCerts)
      .catch(() => setCerts([]));

  useEffect(() => {
    load();
    api.get<Node[]>("/api/nodes").then(setNodes).catch(() => {});
    loadCerts();
  }, []);

  const availableCerts = certs.flatMap((row) =>
    row.certs.map((c) => ({ ...c, node: row.node, node_id: row.node_id })),
  );

  const set = (patch: Partial<FormState>) => setForm((f) => (f ? { ...f, ...patch } : f));
  const setS = (patch: Settings) =>
    setForm((f) => (f ? { ...f, settings: { ...f.settings, ...patch } } : f));
  const sv = (key: string, fallback = "") =>
    form?.settings[key] === undefined || form?.settings[key] === null
      ? fallback
      : String(form.settings[key]);
  const sb = (key: string) => Boolean(form?.settings[key]);

  const openNew = () => {
    setForm({ ...EMPTY, settings: {} });
    setSection("main");
  };

  const openEdit = (i: Inbound) => {
    const { managed, extra } = splitSettings(i.settings as Settings);
    setForm({
      id: i.id,
      tag: i.tag,
      remark: i.remark,
      protocol: i.protocol,
      core: i.core,
      listen: i.listen || "",
      port: i.port,
      network: i.network,
      security: i.security,
      sni: i.sni,
      host: i.host,
      path: i.path,
      service_name: i.service_name,
      header_type: i.header_type || "",
      flow: i.flow,
      fingerprint: i.fingerprint,
      reality_public_key: i.reality_public_key,
      reality_private_key: i.reality_private_key,
      reality_short_ids: (i.reality_short_ids || []).join(","),
      reality_dest: i.reality_dest,
      reality_server_names: (i.reality_server_names || []).join(","),
      cert_path: i.cert_path || "",
      key_path: i.key_path || "",
      alpn: i.alpn || "",
      allow_insecure: Boolean(i.allow_insecure),
      settings: managed,
      extra: JSON.stringify(extra, null, 2),
      is_enabled: i.is_enabled,
      is_default: i.is_default,
      sniffing: i.sniffing,
      node_ids: i.node_inbounds.map((n) => n.node_id),
    });
    setSection("main");
  };

  const makeSelfSigned = async () => {
    if (!form) return;
    const nodeId = form.node_ids[0] ?? nodes[0]?.id;
    if (!nodeId) return toast("اول یک نود انتخاب کن", "error");
    setSaving(true);
    try {
      const res = await api.post<{ cert: string; key: string; domain: string }>(
        "/api/certificates/self-signed",
        { node_id: nodeId, domain: form.sni || "", apply_to_inbound_id: form.id ?? null },
      );
      set({ cert_path: res.cert, key_path: res.key, sni: form.sni || res.domain, allow_insecure: true });
      loadCerts();
      toast(`گواهی خودامضا برای ${res.domain} ساخته شد`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const genReality = async () => {
    if (!form) return;
    const keys = await api.post<{ private_key: string; public_key: string; short_ids: string[] }>(
      "/api/inbounds/reality-keys",
    );
    set({
      reality_private_key: keys.private_key,
      reality_public_key: keys.public_key,
      reality_short_ids: keys.short_ids.join(","),
    });
    toast("کلیدهای Reality ساخته شد");
  };

  /** Same checks the backend runs, shown before the user hits save. */
  const problem = (f: FormState): string => {
    if (!XRAY_PROTOCOLS.includes(f.protocol)) return "";
    if (f.security === "tls" && !f.cert_path)
      return "امنیت TLS انتخاب شده ولی گواهی خالی است — یک گواهی انتخاب یا بساز.";
    if (f.security === "reality" && f.protocol !== "vless")
      return "Reality فقط با VLESS کار می‌کند.";
    if (f.security === "reality" && !["tcp", "grpc", "xhttp"].includes(f.network))
      return "Reality فقط با ترنسپورت tcp، grpc یا xhttp کار می‌کند.";
    if (f.network === "grpc" && f.security === "none")
      return "gRPC بدون TLS/Reality در کلاینت‌ها وصل نمی‌شود.";
    if (f.protocol === "vless" && f.flow && (f.network !== "tcp" || f.security === "none"))
      return "Flow فقط روی tcp + tls/reality معتبر است؛ در غیر این‌صورت نادیده گرفته می‌شود.";
    return "";
  };

  const save = async () => {
    if (!form) return;
    let extra: Settings = {};
    try {
      extra = JSON.parse(form.extra || "{}");
    } catch {
      return toast("تنظیمات اضافه JSON معتبر نیست", "error");
    }
    setSaving(true);
    const payload = {
      tag: form.tag,
      remark: form.remark,
      protocol: form.protocol,
      core: PROTOCOLS.find((p) => p.value === form.protocol)?.core || "xray",
      listen: form.listen,
      port: form.port,
      network: form.network,
      security: form.security,
      sni: form.sni,
      host: form.host,
      path: form.path,
      service_name: form.service_name,
      header_type: form.header_type,
      flow: form.flow,
      fingerprint: form.fingerprint,
      reality_public_key: form.reality_public_key,
      reality_private_key: form.reality_private_key,
      reality_short_ids: form.reality_short_ids
        ? form.reality_short_ids.split(",").map((s) => s.trim()).filter(Boolean)
        : [],
      reality_dest: form.reality_dest,
      reality_server_names: (form.reality_server_names || form.sni)
        ? (form.reality_server_names || form.sni).split(",").map((s) => s.trim()).filter(Boolean)
        : [],
      cert_path: form.cert_path,
      key_path: form.key_path,
      alpn: form.alpn,
      allow_insecure: form.allow_insecure,
      settings: { ...extra, ...form.settings },
      is_enabled: form.is_enabled,
      is_default: form.is_default,
      sniffing: form.sniffing,
      node_ids: form.node_ids,
    };
    try {
      if (form.id) await api.patch(`/api/inbounds/${form.id}`, payload);
      else await api.post("/api/inbounds", payload);
      toast("ذخیره و روی نودها اعمال شد");
      setForm(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const shown = inbounds.filter((i) => tab === "all" || i.core === tab);
  const isXray = form ? XRAY_PROTOCOLS.includes(form.protocol) : false;
  const SECTIONS = isXray
    ? [
        { key: "main", label: "اصلی" },
        { key: "transport", label: "ترنسپورت" },
        { key: "security", label: "امنیت / TLS" },
        { key: "advanced", label: "پیشرفته" },
      ]
    : [
        { key: "main", label: "اصلی" },
        { key: "advanced", label: "پیشرفته" },
      ];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">پروتکل‌ها</h1>
          <p className="mt-1 text-xs text-ink-400">
            همه پروتکل‌های VPN در یک‌جا — وضعیت، تنظیمات شبکه، کاربران و نودها
          </p>
        </div>
        <button className="btn-primary" onClick={openNew}>
          + افزودن اینباند
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={
              tab === t.key
                ? "rounded-full bg-gradient-to-l from-brand-600 to-brand-400 px-4 py-2 text-sm text-white"
                : "rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-ink-300"
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid place-items-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : !shown.length ? (
        <Empty text="اینباندی در این دسته وجود ندارد." />
      ) : (
        <Card>
          <div className="-mx-5 overflow-x-auto px-5">
            <table className="w-full min-w-[760px]">
              <thead className="border-b border-white/5">
                <tr>
                  <th className="th">نام</th>
                  <th className="th">پروتکل</th>
                  <th className="th">ترنسپورت</th>
                  <th className="th">امنیت</th>
                  <th className="th">پورت</th>
                  <th className="th">نودها</th>
                  <th className="th">کاربران</th>
                  <th className="th"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {shown.map((i) => (
                  <tr key={i.id} className="hover:bg-white/[0.03]">
                    <td className="td">
                      <span className="font-medium">{i.remark || i.tag}</span>
                      {i.is_default && <Chip tone="brand">پیش‌فرض همه</Chip>}
                      <span className="block text-[10px] text-ink-500">{i.tag}</span>
                      {i.warning && (
                        <span className="mt-1 block max-w-xs whitespace-normal text-[10px] leading-4 text-amber-300">
                          ⚠ {i.warning}
                        </span>
                      )}
                    </td>
                    <td className="td uppercase">{i.protocol}</td>
                    <td className="td">{i.network}</td>
                    <td className="td">{i.security}</td>
                    <td className="td tabular-nums">{i.port}</td>
                    <td className="td max-w-xs whitespace-normal">
                      <div className="flex flex-wrap gap-1">
                        {i.node_inbounds.map((ni) => {
                          const node = nodes.find((n) => n.id === ni.node_id);
                          return (
                            <span
                              key={ni.node_id}
                              title={ni.sync_error || "همگام شد"}
                              className={
                                ni.sync_error
                                  ? "badge bg-rose-500/15 text-rose-300"
                                  : "badge bg-emerald-500/15 text-emerald-300"
                              }
                            >
                              {ni.sync_error ? "⚠ " : ""}
                              {node?.name || ni.node_id}
                            </span>
                          );
                        })}
                        {!i.node_inbounds.length && (
                          <span className="text-[11px] text-ink-500">اعمال نشده</span>
                        )}
                      </div>
                      {i.node_inbounds
                        .filter((ni) => ni.sync_error)
                        .map((ni) => (
                          <p
                            key={`err-${ni.node_id}`}
                            className="mt-1 text-[10px] leading-4 text-rose-300"
                          >
                            {ni.sync_error}
                          </p>
                        ))}
                    </td>
                    <td className="td tabular-nums">{number(i.users_count)}</td>
                    <td className="td">
                      <div className="flex justify-end gap-1">
                        <button className="btn-ghost px-2 py-1 text-xs" onClick={() => openEdit(i)}>
                          ویرایش
                        </button>
                        <button
                          className="btn-danger px-2 py-1 text-xs"
                          onClick={async () => {
                            if (!confirm(`اینباند ${i.tag} حذف شود؟`)) return;
                            await api.del(`/api/inbounds/${i.id}`);
                            toast("حذف شد");
                            load();
                          }}
                        >
                          حذف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={form?.id ? `ویرایش ${form.tag}` : "اینباند جدید"}
        wide
        footer={
          <>
            <button className="btn-ghost" onClick={() => setForm(null)}>
              انصراف
            </button>
            <button className="btn-primary" onClick={save} disabled={saving}>
              {saving ? <Spinner /> : "ذخیره و اعمال"}
            </button>
          </>
        }
      >
        {form && (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2 border-b border-white/5 pb-3">
              {SECTIONS.map((s) => (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => setSection(s.key)}
                  className={
                    section === s.key
                      ? "rounded-lg bg-brand-500/20 px-3 py-1.5 text-xs text-brand-200"
                      : "rounded-lg border border-white/10 px-3 py-1.5 text-xs text-ink-400"
                  }
                >
                  {s.label}
                </button>
              ))}
            </div>

            {problem(form) && (
              <p className="rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] leading-5 text-amber-300">
                ⚠ {problem(form)}
              </p>
            )}

            {/* ---------------------------------------------------------- main */}
            {section === "main" && (
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="تگ (یکتا)">
                  <input
                    className="input font-mono"
                    dir="ltr"
                    value={form.tag}
                    disabled={!!form.id}
                    onChange={(e) => set({ tag: e.target.value })}
                  />
                </Field>
                <Field label="نام نمایشی">
                  <input
                    className="input"
                    value={form.remark}
                    onChange={(e) => set({ remark: e.target.value })}
                  />
                </Field>
                <Field label="پروتکل">
                  <select
                    className="input"
                    value={form.protocol}
                    onChange={(e) => set({ protocol: e.target.value })}
                  >
                    {PROTOCOLS.map((p) => (
                      <option key={p.value} value={p.value}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="پورت">
                  <input
                    type="number"
                    className="input"
                    value={form.port}
                    onChange={(e) => set({ port: Number(e.target.value) })}
                  />
                </Field>

                {isXray && (
                  <>
                    <Field label="ترنسپورت">
                      <select
                        className="input"
                        value={form.network}
                        onChange={(e) => set({ network: e.target.value })}
                      >
                        {NETWORKS.map((n) => (
                          <option key={n.value} value={n.value}>
                            {n.label}
                          </option>
                        ))}
                      </select>
                    </Field>
                    <Field label="امنیت">
                      <select
                        className="input"
                        value={form.security}
                        onChange={(e) => set({ security: e.target.value })}
                      >
                        {SECURITIES.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.label}
                          </option>
                        ))}
                      </select>
                    </Field>
                  </>
                )}

                {form.protocol === "shadowsocks" && (
                  <>
                    <Field
                      label="روش رمزنگاری"
                      hint="روش‌های 2022 برای هر کاربر کلید جدا می‌سازند؛ روش‌های قدیمی یک کلید مشترک دارند"
                    >
                      <select
                        className="input"
                        value={sv("method", "2022-blake3-aes-256-gcm")}
                        onChange={(e) => setS({ method: e.target.value })}
                      >
                        {SS_METHODS.map((m) => (
                          <option key={m} value={m}>
                            {m}
                          </option>
                        ))}
                      </select>
                    </Field>
                    <Field label="شبکه">
                      <select
                        className="input"
                        value={sv("network", "tcp,udp")}
                        onChange={(e) => setS({ network: e.target.value })}
                      >
                        <option value="tcp,udp">tcp,udp</option>
                        <option value="tcp">tcp</option>
                        <option value="udp">udp</option>
                      </select>
                    </Field>
                  </>
                )}

                {form.protocol === "pptp" && (
                  <p className="sm:col-span-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] text-amber-300">
                    PPTP به پروتکل GRE نیاز دارد که در مسیر ایران معمولاً فیلتر است؛
                    فقط اگر مطمئنی مسیرت GRE را عبور می‌دهد از آن استفاده کن.
                  </p>
                )}

                <Field label="نودهایی که این اینباند روی آن‌ها بالا بیاید" className="sm:col-span-2">
                  <MultiSelect
                    options={nodes}
                    selected={form.node_ids}
                    onChange={(ids) => set({ node_ids: ids })}
                    render={(n) => `${n.country ? n.country + " " : ""}${n.name}`}
                    empty="ابتدا یک نود اضافه کنید"
                  />
                </Field>

                <div className="flex flex-wrap items-center gap-5 sm:col-span-2">
                  <Toggle
                    checked={form.is_enabled}
                    onChange={(v) => set({ is_enabled: v })}
                    label="فعال"
                  />
                  <Toggle
                    checked={form.is_default}
                    onChange={(v) => set({ is_default: v })}
                    label="به همه کاربران اضافه شود"
                  />
                </div>
              </div>
            )}

            {/* ----------------------------------------------------- transport */}
            {section === "transport" && isXray && (
              <div className="grid gap-4 sm:grid-cols-2">
                {["ws", "httpupgrade", "xhttp"].includes(form.network) && (
                  <>
                    <Field label="Path" hint="مثلاً /nimexo — در کلاینت هم همین وارد می‌شود">
                      <div className="flex gap-2">
                        <input
                          className="input font-mono"
                          dir="ltr"
                          value={form.path}
                          onChange={(e) => set({ path: e.target.value })}
                        />
                        <button
                          type="button"
                          className="btn-ghost shrink-0 text-xs"
                          onClick={() => set({ path: "/" + Math.random().toString(36).slice(2, 10) })}
                        >
                          تولید
                        </button>
                      </div>
                    </Field>
                    <Field label="Host" hint="هدر Host — برای CDN لازم است">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={form.host}
                        onChange={(e) => set({ host: e.target.value })}
                      />
                    </Field>
                  </>
                )}

                {form.network === "xhttp" && (
                  <Field label="Mode" hint="auto برای بیشتر کلاینت‌ها مناسب است">
                    <select
                      className="input"
                      value={sv("mode", "auto")}
                      onChange={(e) => setS({ mode: e.target.value })}
                    >
                      {XHTTP_MODES.map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  </Field>
                )}

                {form.network === "grpc" && (
                  <>
                    <Field label="Service Name" hint="در کلاینت همین مقدار وارد می‌شود">
                      <div className="flex gap-2">
                        <input
                          className="input font-mono"
                          dir="ltr"
                          value={form.service_name}
                          onChange={(e) => set({ service_name: e.target.value })}
                        />
                        <button
                          type="button"
                          className="btn-ghost shrink-0 text-xs"
                          onClick={() => set({ service_name: Math.random().toString(36).slice(2, 10) })}
                        >
                          تولید
                        </button>
                      </div>
                    </Field>
                    <Field label="Authority (اختیاری)">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={sv("grpc_authority")}
                        onChange={(e) => setS({ grpc_authority: e.target.value })}
                      />
                    </Field>
                    <div className="flex items-end">
                      <Toggle
                        checked={sb("multi_mode")}
                        onChange={(v) => setS({ multi_mode: v })}
                        label="Multi Mode"
                      />
                    </div>
                  </>
                )}

                {form.network === "tcp" && (
                  <>
                    <Field label="Header type" hint="http یعنی ترافیک شبیه وب معمولی دیده شود">
                      <select
                        className="input"
                        value={form.header_type}
                        onChange={(e) => set({ header_type: e.target.value })}
                      >
                        {TCP_HEADERS.map((h) => (
                          <option key={h.value} value={h.value}>
                            {h.label}
                          </option>
                        ))}
                      </select>
                    </Field>
                    {form.header_type === "http" && (
                      <>
                        <Field label="Request path">
                          <input
                            className="input font-mono"
                            dir="ltr"
                            value={form.path}
                            placeholder="/"
                            onChange={(e) => set({ path: e.target.value })}
                          />
                        </Field>
                        <Field label="Host header">
                          <input
                            className="input font-mono"
                            dir="ltr"
                            value={form.host}
                            placeholder="www.bing.com"
                            onChange={(e) => set({ host: e.target.value })}
                          />
                        </Field>
                      </>
                    )}
                  </>
                )}

                {form.network === "kcp" && (
                  <>
                    <Field label="Header (تغییر شکل بسته)">
                      <select
                        className="input"
                        value={form.header_type || "none"}
                        onChange={(e) =>
                          set({ header_type: e.target.value === "none" ? "" : e.target.value })
                        }
                      >
                        {KCP_HEADERS.map((h) => (
                          <option key={h} value={h}>
                            {h}
                          </option>
                        ))}
                      </select>
                    </Field>
                    <Field label="کلید (mKCP AES-128-GCM)" hint="جای seed قدیمی؛ در کلاینت هم وارد می‌شود">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={sv("mkcp_key")}
                        onChange={(e) => setS({ mkcp_key: e.target.value })}
                      />
                    </Field>
                    <Field label="MTU">
                      <input
                        type="number"
                        className="input"
                        value={sv("mtu", "1350")}
                        onChange={(e) => setS({ mtu: Number(e.target.value) })}
                      />
                    </Field>
                    <Field label="TTI">
                      <input
                        type="number"
                        className="input"
                        value={sv("tti", "50")}
                        onChange={(e) => setS({ tti: Number(e.target.value) })}
                      />
                    </Field>
                    <Field label="Uplink capacity (MB/s)">
                      <input
                        type="number"
                        className="input"
                        value={sv("uplink", "5")}
                        onChange={(e) => setS({ uplink: Number(e.target.value) })}
                      />
                    </Field>
                    <Field label="Downlink capacity (MB/s)">
                      <input
                        type="number"
                        className="input"
                        value={sv("downlink", "20")}
                        onChange={(e) => setS({ downlink: Number(e.target.value) })}
                      />
                    </Field>
                    <div className="flex items-end">
                      <Toggle
                        checked={sb("congestion")}
                        onChange={(v) => setS({ congestion: v })}
                        label="کنترل ازدحام"
                      />
                    </div>
                  </>
                )}

                <Field
                  label="Listen IP (اختیاری)"
                  hint="خالی = روی همه اینترفیس‌ها. اگر پشت تونل محلی هستی 127.0.0.1 بگذار"
                  className="sm:col-span-2"
                >
                  <input
                    className="input font-mono"
                    dir="ltr"
                    value={form.listen}
                    onChange={(e) => set({ listen: e.target.value })}
                  />
                </Field>
              </div>
            )}

            {/* ------------------------------------------------------ security */}
            {section === "security" && isXray && (
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="SNI / سرورنیم">
                  <input
                    className="input font-mono"
                    dir="ltr"
                    value={form.sni}
                    onChange={(e) => set({ sni: e.target.value })}
                  />
                </Field>
                <Field label="Fingerprint (uTLS)">
                  <select
                    className="input"
                    value={form.fingerprint}
                    onChange={(e) => set({ fingerprint: e.target.value })}
                  >
                    {FINGERPRINTS.map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                  </select>
                </Field>

                {form.security === "tls" && (
                  <>
                    <Field
                      label="گواهی TLS"
                      hint={form.cert_path || "یکی از گواهی‌های روی نود را انتخاب کن، یا همین‌جا یکی بساز"}
                      className="sm:col-span-2"
                    >
                      <div className="flex flex-wrap gap-2">
                        <select
                          className="input flex-1"
                          value={form.cert_path}
                          onChange={(e) => {
                            const chosen = availableCerts.find((c) => c.cert === e.target.value);
                            set({
                              cert_path: chosen?.cert || "",
                              key_path: chosen?.key || "",
                              allow_insecure: chosen?.self_signed ?? form.allow_insecure,
                            });
                          }}
                        >
                          <option value="">— بدون گواهی —</option>
                          {availableCerts.map((c) => (
                            <option key={`${c.node_id}-${c.cert}`} value={c.cert}>
                              {c.domain} · {c.node}
                              {c.self_signed ? " (خودامضا)" : ""}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          className="btn-ghost shrink-0 text-xs"
                          onClick={makeSelfSigned}
                          disabled={saving}
                        >
                          ساخت گواهی خودامضا
                        </button>
                        <a
                          className="btn-ghost shrink-0 text-xs"
                          href="/certificates"
                          target="_blank"
                          rel="noreferrer"
                        >
                          گواهی دامنه
                        </a>
                      </div>
                    </Field>
                    <Field label="ALPN">
                      <select
                        className="input"
                        value={form.alpn}
                        onChange={(e) => set({ alpn: e.target.value })}
                      >
                        {ALPN_CHOICES.map((a) => (
                          <option key={a} value={a}>
                            {a || "— پیش‌فرض —"}
                          </option>
                        ))}
                      </select>
                    </Field>
                    <Field label="حداقل نسخه TLS">
                      <select
                        className="input"
                        value={sv("tls_min_version", "1.2")}
                        onChange={(e) => setS({ tls_min_version: e.target.value })}
                      >
                        <option value="1.2">1.2</option>
                        <option value="1.3">1.3</option>
                      </select>
                    </Field>
                    <div className="flex items-end">
                      <Toggle
                        checked={form.allow_insecure}
                        onChange={(v) => set({ allow_insecure: v })}
                        label="نادیده گرفتن اعتبار گواهی در کلاینت"
                      />
                    </div>
                    <div className="flex items-end">
                      <Toggle
                        checked={sb("reject_unknown_sni")}
                        onChange={(v) => setS({ reject_unknown_sni: v })}
                        label="رد کردن SNI ناشناس"
                      />
                    </div>
                    {form.allow_insecure && (
                      <p className="sm:col-span-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] leading-5 text-amber-300">
                        با گواهی خودامضا این گزینه لازم است و در لینک کاربر
                        <span className="font-mono"> allowInsecure=1 </span>
                        اضافه می‌شود. برای دامنه واقعی از «گواهی دامنه» استفاده کن تا لازم نباشد.
                      </p>
                    )}
                  </>
                )}

                {form.security === "reality" && (
                  <>
                    <Field label="Reality dest" hint="مثلاً dl.google.com:443">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={form.reality_dest}
                        onChange={(e) => set({ reality_dest: e.target.value })}
                      />
                    </Field>
                    <Field label="Server names" hint="با کاما — خالی = همان SNI">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={form.reality_server_names}
                        onChange={(e) => set({ reality_server_names: e.target.value })}
                      />
                    </Field>
                    <Field label="Short IDs" hint="با کاما جدا کن">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={form.reality_short_ids}
                        onChange={(e) => set({ reality_short_ids: e.target.value })}
                      />
                    </Field>
                    <Field label="SpiderX">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={sv("reality_spider_x", "/")}
                        onChange={(e) => setS({ reality_spider_x: e.target.value })}
                      />
                    </Field>
                    <Field label="کلید عمومی">
                      <input
                        className="input font-mono text-[11px]"
                        dir="ltr"
                        value={form.reality_public_key}
                        onChange={(e) => set({ reality_public_key: e.target.value })}
                      />
                    </Field>
                    <Field label="کلید خصوصی">
                      <div className="flex gap-2">
                        <input
                          className="input font-mono text-[11px]"
                          dir="ltr"
                          value={form.reality_private_key}
                          onChange={(e) => set({ reality_private_key: e.target.value })}
                        />
                        <button type="button" className="btn-ghost shrink-0 text-xs" onClick={genReality}>
                          تولید
                        </button>
                      </div>
                    </Field>
                  </>
                )}

                {form.protocol === "vless" && (
                  <Field
                    label="Flow"
                    hint="فقط با tcp + reality/tls معنی دارد؛ در بقیه حالت‌ها خالی بگذار"
                  >
                    <select
                      className="input"
                      value={form.flow}
                      onChange={(e) => set({ flow: e.target.value })}
                    >
                      <option value="">— بدون flow —</option>
                      <option value="xtls-rprx-vision">xtls-rprx-vision</option>
                      <option value="xtls-rprx-vision-udp443">xtls-rprx-vision-udp443</option>
                    </select>
                  </Field>
                )}
              </div>
            )}

            {/* ------------------------------------------------------ advanced */}
            {section === "advanced" && (
              <div className="grid gap-4 sm:grid-cols-2">
                {isXray && (
                  <>
                    <div className="flex items-end">
                      <Toggle
                        checked={form.sniffing}
                        onChange={(v) => set({ sniffing: v })}
                        label="Sniffing (تشخیص دامنه مقصد)"
                      />
                    </div>
                    <div className="flex items-end">
                      <Toggle
                        checked={sb("sniff_route_only")}
                        onChange={(v) => setS({ sniff_route_only: v })}
                        label="فقط برای مسیریابی"
                      />
                    </div>
                    <Field label="Dest override" hint="خالی = http,tls,quic">
                      <input
                        className="input font-mono"
                        dir="ltr"
                        value={sv("sniff_dest_override")}
                        placeholder="http,tls,quic"
                        onChange={(e) => setS({ sniff_dest_override: e.target.value })}
                      />
                    </Field>
                    {form.protocol === "vmess" && (
                      <Field label="رمزنگاری VMess">
                        <select
                          className="input"
                          value={sv("vmess_security", "auto")}
                          onChange={(e) => setS({ vmess_security: e.target.value })}
                        >
                          {["auto", "aes-128-gcm", "chacha20-poly1305", "none", "zero"].map((v) => (
                            <option key={v} value={v}>
                              {v}
                            </option>
                          ))}
                        </select>
                      </Field>
                    )}
                  </>
                )}
                <Field
                  label="تنظیمات اضافه (JSON)"
                  hint={
                    SETTINGS_HINTS[form.protocol] ||
                    "هرچه اینجا بگذاری مستقیم به تنظیمات این اینباند اضافه می‌شود"
                  }
                  className="sm:col-span-2"
                >
                  <textarea
                    className="input h-32 font-mono text-[11px]"
                    dir="ltr"
                    value={form.extra}
                    onChange={(e) => set({ extra: e.target.value })}
                  />
                </Field>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
