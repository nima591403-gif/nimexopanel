"""Client-facing config generation (share links, WireGuard/OpenVPN files)."""
from __future__ import annotations

import base64
import json
from urllib.parse import quote, urlencode

from sqlalchemy.orm import Session

from app.models import Inbound, Node, NodeInbound, User
from app.models.enums import Network, Protocol, Security
from app.services.cores import wireguard as wg
from app.services.cores.xray import (
    SS2022_METHODS,
    _v,
    effective_flow,
    user_ss_password,
)


def _b64(text: str) -> str:
    return base64.urlsafe_b64encode(text.encode()).decode().rstrip("=")


def endpoint_for(node: Node, node_inbound: NodeInbound | None, inbound: Inbound) -> tuple[str, int]:
    """Where a client should connect.

    Priority: a per-node override on this inbound, then the node's public
    address (set this to a domain and every link/config uses the domain
    instead of the bare IP), then the SSH address as a last resort.
    """
    host = node.endpoint
    port = inbound.port
    if node_inbound:
        host = node_inbound.address_override or host
        port = node_inbound.port_override or port
    return host, port


def remark_for(user: User, node: Node, inbound: Inbound) -> str:
    label = inbound.remark or inbound.tag
    flag = f"{node.country} " if node.country else ""
    return f"{flag}{node.name} · {label}"


def _network_param(inbound: Inbound) -> str:
    """The transport name clients expect in a share link."""
    if inbound.network == Network.H2:
        return "http"
    return _v(inbound.network)


def _stream_params(inbound: Inbound) -> dict:
    settings = inbound.settings or {}
    params: dict[str, str] = {"type": _network_param(inbound)}

    if inbound.network == Network.WS:
        params["path"] = inbound.path or "/"
        if inbound.host:
            params["host"] = inbound.host
    elif inbound.network == Network.GRPC:
        params["serviceName"] = inbound.service_name or ""
        params["mode"] = "multi" if settings.get("multi_mode") else "gun"
        if settings.get("grpc_authority"):
            params["authority"] = settings["grpc_authority"]
    elif inbound.network == Network.HTTPUPGRADE:
        params["path"] = inbound.path or "/"
        if inbound.host:
            params["host"] = inbound.host
    elif inbound.network == Network.XHTTP:
        params["path"] = inbound.path or "/"
        if inbound.host:
            params["host"] = inbound.host
        params["mode"] = settings.get("mode", "auto")
    elif inbound.network == Network.H2:
        params["path"] = inbound.path or "/"
        if inbound.host:
            params["host"] = inbound.host
    elif inbound.network == Network.KCP:
        params["headerType"] = inbound.header_type or "none"
        key = settings.get("mkcp_key") or settings.get("seed")
        if key:
            params["seed"] = key
    elif inbound.network == Network.QUIC:
        params["headerType"] = inbound.header_type or "none"
        params["quicSecurity"] = settings.get("quic_security", "none")
        if settings.get("quic_key"):
            params["key"] = settings["quic_key"]
    elif inbound.network == Network.TCP:
        if inbound.header_type == "http":
            params["headerType"] = "http"
            params["path"] = inbound.path or "/"
            if inbound.host:
                params["host"] = inbound.host

    if inbound.security == Security.REALITY:
        params.update(
            {
                "security": "reality",
                "pbk": inbound.reality_public_key,
                "fp": inbound.fingerprint or "chrome",
                "sni": inbound.sni or (inbound.reality_server_names or [""])[0],
                "sid": (inbound.reality_short_ids or [""])[0],
                "spx": settings.get("reality_spider_x", "/"),
            }
        )
    elif inbound.security == Security.TLS:
        params["security"] = "tls"
        if inbound.sni:
            params["sni"] = inbound.sni
        if inbound.fingerprint:
            params["fp"] = inbound.fingerprint
        if inbound.alpn:
            params["alpn"] = inbound.alpn
        if inbound.allow_insecure:
            params["allowInsecure"] = "1"
    else:
        params["security"] = "none"

    return {k: v for k, v in params.items() if v not in ("", None)}


def build_share_link(user: User, inbound: Inbound, node: Node,
                     node_inbound: NodeInbound | None = None) -> str | None:
    host, port = endpoint_for(node, node_inbound, inbound)
    remark = remark_for(user, node, inbound)

    if inbound.protocol == Protocol.VLESS:
        params = _stream_params(inbound)
        # Required by the VLESS URI scheme; some clients refuse a link without it.
        params["encryption"] = "none"
        flow = effective_flow(inbound)
        if flow:
            params["flow"] = flow
        return f"vless://{user.uuid}@{host}:{port}?{urlencode(params)}#{quote(remark)}"

    if inbound.protocol == Protocol.VMESS:
        settings = inbound.settings or {}
        net = _network_param(inbound)
        payload = {
            "v": "2",
            "ps": remark,
            "add": host,
            "port": str(port),
            "id": user.uuid,
            "aid": "0",
            "scy": settings.get("vmess_security", "auto"),
            "net": net,
            "type": inbound.header_type or "none",
            "host": inbound.host or "",
            "path": inbound.path or "",
            "tls": "tls" if inbound.security == Security.TLS else "",
            "sni": inbound.sni or "",
            "alpn": inbound.alpn or "",
            "fp": inbound.fingerprint or "",
        }
        if inbound.network == Network.GRPC:
            payload["path"] = inbound.service_name or ""
            payload["type"] = "multi" if settings.get("multi_mode") else "gun"
        elif inbound.network == Network.QUIC:
            payload["host"] = settings.get("quic_security", "none")
            payload["path"] = settings.get("quic_key", "")
        elif inbound.network == Network.KCP:
            payload["path"] = settings.get("seed", "")
        if inbound.security == Security.TLS and inbound.allow_insecure:
            payload["allowInsecure"] = True
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        return "vmess://" + base64.b64encode(raw.encode()).decode()

    if inbound.protocol == Protocol.TROJAN:
        params = _stream_params(inbound)
        password = user.password or user.uuid
        return (
            f"trojan://{quote(password)}@{host}:{port}?{urlencode(params)}"
            f"#{quote(remark)}"
        )

    if inbound.protocol == Protocol.SHADOWSOCKS:
        settings = inbound.settings or {}
        method = settings.get("method", "chacha20-ietf-poly1305")
        if method in SS2022_METHODS:
            server_pw = settings.get("server_password", "")
            password = f"{server_pw}:{user_ss_password(user, inbound)}"
        else:
            # legacy ciphers are single-account: everyone shares the server key
            password = settings.get("server_password") or user.password or user.uuid
        userinfo = base64.b64encode(f"{method}:{password}".encode()).decode().rstrip("=")
        return f"ss://{userinfo}@{host}:{port}#{quote(remark)}"

    return None


def build_wireguard_config(db: Session, user: User, inbound: Inbound, node: Node,
                           node_inbound: NodeInbound | None = None) -> str:
    cred = wg.ensure_user_credential(db, inbound, user)
    _, server_pub = wg.ensure_server_keys(inbound)
    host, port = endpoint_for(node, node_inbound, inbound)
    settings = inbound.settings or {}
    net = settings.get("subnet", wg.DEFAULT_SUBNET)
    prefix = net.split("/")[-1] if "/" in net else "24"
    lines = [
        "[Interface]",
        f"PrivateKey = {cred['private_key']}",
        f"Address = {cred['ip']}/{prefix}",
        f"DNS = {settings.get('dns', wg.DEFAULT_DNS)}",
        f"MTU = {settings.get('mtu', wg.DEFAULT_MTU)}",
        "",
        "[Peer]",
        f"PublicKey = {server_pub}",
        f"Endpoint = {host}:{port}",
        f"AllowedIPs = {settings.get('allowed_ips', '0.0.0.0/0, ::/0')}",
        "PersistentKeepalive = 25",
    ]
    return "\n".join(lines) + "\n"


def build_subscription_links(db: Session, user: User, nodes: list[Node],
                             inbounds: list[Inbound]) -> list[str]:
    """One share link per (enabled inbound × node it is deployed on)."""
    links: list[str] = []
    by_key = {
        (ni.inbound_id, ni.node_id): ni
        for ni in db.query(NodeInbound).all()
    }
    for node in sorted(nodes, key=lambda n: (n.sort_order, n.id)):
        if not node.is_enabled:
            continue
        for inbound in sorted(inbounds, key=lambda i: (i.sort_order, i.id)):
            ni = by_key.get((inbound.id, node.id))
            if ni is None or not ni.is_enabled or not inbound.is_enabled:
                continue
            link = build_share_link(user, inbound, node, ni)
            if link:
                links.append(link)
    return links
