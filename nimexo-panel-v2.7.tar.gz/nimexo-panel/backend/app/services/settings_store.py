"""Runtime settings that live in the database instead of the .env file.

The domain and the subscription port change often enough (a new relay, a new
Cloudflare record) that editing .env and restarting the service for every change
is the wrong shape. These are read from the `settings` table with the values in
.env as the fallback, so an untouched install keeps behaving exactly as before.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.config import settings as env
from app.db import session_scope
from app.models import Setting

KEY = "panel"

DEFAULTS = {
    "brand_name": "",
    "panel_domain": "",
    "panel_public_url": "",
    "sub_domain": "",
    "sub_path": "",
    "sub_port": 0,
    "sub_https": None,        # None -> decide from the port
    "sub_profile_title": "",
    # TLS material for the panel's own listeners (issued on this host)
    "panel_cert": "",
    "panel_key": "",
}

_cache: dict | None = None


def _row(db: Session) -> Setting:
    row = db.query(Setting).get(KEY)
    if row is None:
        row = Setting(key=KEY, value={})
        db.add(row)
        db.flush()
    return row


def load(db: Session | None = None) -> dict:
    """Stored overrides merged over the .env defaults."""
    global _cache
    if db is None:
        if _cache is not None:
            return _cache
        with session_scope() as scoped:
            data = dict(DEFAULTS)
            data.update(_row(scoped).value or {})
    else:
        data = dict(DEFAULTS)
        data.update(_row(db).value or {})

    resolved = {
        "brand_name": data["brand_name"] or env.BRAND_NAME,
        "panel_domain": data["panel_domain"] or env.PANEL_DOMAIN,
        "panel_public_url": data["panel_public_url"] or env.PANEL_PUBLIC_URL,
        "sub_domain": data["sub_domain"] or env.SUB_DOMAIN or env.PANEL_DOMAIN,
        "sub_path": (data["sub_path"] or env.SUB_PATH).strip("/") or "sub",
        "sub_port": int(data["sub_port"] or env.SUB_PORT or env.PORT),
        "sub_https": data["sub_https"],
        "sub_profile_title": data["sub_profile_title"] or env.SUB_PROFILE_TITLE,
        "panel_cert": data["panel_cert"],
        "panel_key": data["panel_key"],
    }
    _cache = resolved
    return resolved


def save(db: Session, values: dict) -> dict:
    global _cache
    row = _row(db)
    stored = dict(row.value or {})
    for key in DEFAULTS:
        if key in values:
            stored[key] = values[key]
    row.value = stored
    db.add(row)
    db.commit()
    _cache = None
    return load(db)


def sub_base_url(db: Session | None = None) -> str:
    """Base of every subscription link, e.g. https://panel.example.com:2097/sub"""
    cfg = load(db)
    domain = cfg["sub_domain"] or "127.0.0.1"
    port = cfg["sub_port"]
    https = cfg["sub_https"]
    if https is None:
        # a certificate installed for this host means the listener is TLS
        https = bool(cfg.get("panel_cert")) or port in (
            443, 2053, 2083, 2087, 2096, 8443
        )
    scheme = "https" if https else "http"
    netloc = domain if port in (80, 443) else f"{domain}:{port}"
    return f"{scheme}://{netloc}/{cfg['sub_path']}"


def page_base_url(db: Session | None = None) -> str:
    """Where the end-user status page lives."""
    cfg = load(db)
    if cfg["panel_public_url"]:
        return cfg["panel_public_url"].rstrip("/")
    base = sub_base_url(db)
    return base.rsplit("/", 1)[0]
