"""Certificates for the panel host itself.

Nodes get their certificates through the SSH agent, but the domain that the
subscription link is built from points at the *panel*, not at a node — so it
needs certbot to run here. Same command surface as the agent so the API can
treat `node_id = 0` as "this server".
"""
from __future__ import annotations

import glob
import os
import re
import shutil
import subprocess
import tempfile

BASE_DIR = "/opt/nimexo"
LE_DIR = "/etc/letsencrypt/live"
SELF_DIR = f"{BASE_DIR}/certs"


def _run(cmd: str, timeout: int = 900) -> tuple[int, str, str]:
    proc = subprocess.run(
        cmd, shell=True, capture_output=True, text=True, timeout=timeout
    )
    return proc.returncode, proc.stdout, proc.stderr


def _safe(domain: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", domain)


def _expiry(cert: str) -> str:
    code, out, _ = _run(f"openssl x509 -enddate -noout -in {cert}", timeout=30)
    return out.strip().split("=", 1)[-1] if code == 0 else ""


def has_certbot() -> bool:
    return shutil.which("certbot") is not None


def cert_list() -> dict:
    certs = []
    for directory in sorted(glob.glob(f"{LE_DIR}/*")):
        cert = f"{directory}/fullchain.pem"
        if not os.path.exists(cert):
            continue
        certs.append(
            {
                "domain": os.path.basename(directory),
                "cert": cert,
                "key": f"{directory}/privkey.pem",
                "expires": _expiry(cert),
                "self_signed": False,
            }
        )
    for directory in sorted(glob.glob(f"{SELF_DIR}/*")):
        cert = f"{directory}/fullchain.pem"
        if not os.path.exists(cert):
            continue
        certs.append(
            {
                "domain": os.path.basename(directory),
                "cert": cert,
                "key": f"{directory}/privkey.pem",
                "expires": _expiry(cert),
                "self_signed": True,
            }
        )
    return {"certs": certs, "certbot": has_certbot()}


def _install_certbot(method: str) -> str:
    if not has_certbot():
        _run("DEBIAN_FRONTEND=noninteractive apt-get update -y", timeout=600)
        _run(
            "DEBIAN_FRONTEND=noninteractive apt-get install -y certbot",
            timeout=900,
        )
    if method == "cloudflare" and not os.path.exists(
        "/usr/lib/python3/dist-packages/certbot_dns_cloudflare"
    ):
        code, _, _ = _run(
            "DEBIAN_FRONTEND=noninteractive apt-get install -y "
            "python3-certbot-dns-cloudflare",
            timeout=900,
        )
        if code != 0:
            _run("pip3 install --break-system-packages certbot-dns-cloudflare",
                 timeout=900)
    return "" if has_certbot() else "نصب certbot روی سرور پنل ناموفق بود"


def cert_issue(payload: dict) -> dict:
    domain = (payload.get("domain") or "").strip()
    if not domain:
        return {"ok": False, "error": "domain is required"}
    method = payload.get("method") or "http"
    email = payload.get("email") or f"admin@{domain}"

    problem = _install_certbot(method)
    if problem:
        return {"ok": False, "error": problem}

    base = (
        f"certbot certonly --non-interactive --agree-tos --email {email} "
        f"-d {domain} --key-type ecdsa"
    )
    if payload.get("staging"):
        base += " --staging"
    if payload.get("force"):
        base += " --force-renewal"

    if method == "cloudflare":
        token = (payload.get("cf_token") or "").strip()
        if not token:
            return {"ok": False, "error": "cloudflare token is required"}
        fd, ini = tempfile.mkstemp(prefix="cf-", suffix=".ini")
        with os.fdopen(fd, "w") as fh:
            fh.write(f"dns_cloudflare_api_token = {token}\n")
        os.chmod(ini, 0o600)
        cmd = (
            f"{base} --dns-cloudflare --dns-cloudflare-credentials {ini} "
            f"--dns-cloudflare-propagation-seconds 30"
        )
        code, out, err = _run(cmd, timeout=900)
        os.unlink(ini)
    else:
        code, out, err = _run(f"{base} --standalone --preferred-challenges http",
                              timeout=900)

    directory = f"{LE_DIR}/{domain}"
    cert = f"{directory}/fullchain.pem"
    if code != 0 or not os.path.exists(cert):
        return {"ok": False, "error": (err or out).strip()[-800:] or "certbot failed"}
    return {
        "ok": True,
        "domain": domain,
        "cert": cert,
        "key": f"{directory}/privkey.pem",
        "expires": _expiry(cert),
        "where": "panel",
    }


def cert_selfsigned(payload: dict) -> dict:
    domain = (payload.get("domain") or "").strip() or "panel.local"
    directory = f"{SELF_DIR}/{_safe(domain)}"
    os.makedirs(directory, exist_ok=True)
    os.chmod(directory, 0o700)
    cert, key = f"{directory}/fullchain.pem", f"{directory}/privkey.pem"
    if not os.path.exists(cert) or payload.get("force"):
        days = int(payload.get("days") or 3650)
        code, out, err = _run(
            f"openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days {days} "
            f"-keyout {key} -out {cert} -subj '/CN={domain}' "
            f"-addext 'subjectAltName=DNS:{domain}'",
            timeout=120,
        )
        if code != 0:
            return {"ok": False, "error": (err or out).strip()[-500:]}
        os.chmod(key, 0o600)
    return {
        "ok": True,
        "domain": domain,
        "cert": cert,
        "key": key,
        "self_signed": True,
        "expires": _expiry(cert),
        "where": "panel",
    }
