"""Build an Xray-core configuration out of the panel's inbounds and users.

The option set mirrors what 3x-ui (Sanaei) exposes when you create an inbound,
so a config that works there works here. Everything protocol specific that does
not deserve its own column lives in ``inbound.settings``; ``inbound.stream_settings``
is merged over the generated ``streamSettings`` last, as a raw escape hatch.
"""
from __future__ import annotations

from typing import Any, Iterable, Sequence

from app.models import Inbound, User
from app.models.enums import Network, Protocol, Security

API_PORT = 10085
API_TAG = "api"

# Keeps users from reaching the node's own LAN / loopback services.
PRIVATE_RANGES = [
    "0.0.0.0/8",
    "10.0.0.0/8",
    "100.64.0.0/10",
    "127.0.0.0/8",
    "169.254.0.0/16",
    "172.16.0.0/12",
    "192.168.0.0/16",
    "::1/128",
    "fc00::/7",
    "fe80::/10",
]

# Ciphers that Xray only accepts with a single account per inbound.
LEGACY_SS_METHODS = {
    "aes-128-gcm",
    "aes-192-gcm",
    "aes-256-gcm",
    "chacha20-ietf-poly1305",
    "xchacha20-ietf-poly1305",
    "none",
    "plain",
}

SS2022_METHODS = {
    "2022-blake3-aes-128-gcm",
    "2022-blake3-aes-256-gcm",
    "2022-blake3-chacha20-poly1305",
}

VALID_FLOWS = {"", "xtls-rprx-vision", "xtls-rprx-vision-udp443"}

# Transports where VLESS `flow` (XTLS Vision) is meaningful. Setting it anywhere
# else makes Xray refuse the whole configuration.
FLOW_NETWORKS = {Network.TCP}

# Transports upstream Xray removed; XHTTP replaces both.
REMOVED_NETWORKS = {Network.H2, Network.QUIC}


def _v(value) -> str:
    """Accept either an enum member or a plain string."""
    return getattr(value, "value", value)


def _s(inbound: Inbound) -> dict:
    return inbound.settings or {}


def _int(value, fallback: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def _list(value, fallback: list | None = None) -> list:
    if isinstance(value, list):
        return [v for v in value if v not in ("", None)]
    if isinstance(value, str):
        return [v.strip() for v in value.split(",") if v.strip()]
    return list(fallback or [])


def effective_flow(inbound: Inbound) -> str:
    """`flow` is only legal on VLESS + raw/tcp + TLS or Reality."""
    flow = (inbound.flow or "").strip()
    if not flow:
        return ""
    if inbound.protocol != Protocol.VLESS:
        return ""
    if inbound.network not in FLOW_NETWORKS:
        return ""
    if inbound.security not in (Security.TLS, Security.REALITY):
        return ""
    return flow if flow in VALID_FLOWS else ""


# --------------------------------------------------------------------------
# validation — a single bad inbound must never take the whole node down
# --------------------------------------------------------------------------
def validate_inbound(inbound: Inbound) -> str:
    """Return a human-readable reason this inbound cannot be deployed, or ""."""
    name = inbound.remark or inbound.tag
    if not 1 <= (inbound.port or 0) <= 65535:
        return f"«{name}»: پورت نامعتبر"
    if inbound.network in REMOVED_NETWORKS:
        return (
            f"«{name}»: ترنسپورت {_v(inbound.network)} از نسخه‌های جدید Xray حذف "
            "شده — به‌جای آن xhttp را انتخاب کن"
        )
    if inbound.security == Security.TLS and not (
        inbound.cert_path or _s(inbound).get("cert_content")
    ):
        return (
            f"«{name}»: امنیت TLS است ولی گواهی انتخاب نشده — "
            "از صفحه گواهی‌ها یکی بساز یا انتخاب کن"
        )
    if inbound.security == Security.REALITY:
        if not inbound.reality_private_key:
            return f"«{name}»: کلید خصوصی Reality خالی است"
        if inbound.protocol != Protocol.VLESS:
            return f"«{name}»: Reality فقط با VLESS کار می‌کند"
        if inbound.network not in (Network.TCP, Network.GRPC, Network.XHTTP):
            return (
                f"«{name}»: Reality با ترنسپورت {_v(inbound.network)} "
                "پشتیبانی نمی‌شود"
            )
    if inbound.protocol == Protocol.SHADOWSOCKS:
        method = _s(inbound).get("method", "chacha20-ietf-poly1305")
        if method in SS2022_METHODS and not _s(inbound).get("server_password"):
            return f"«{name}»: رمز سرور Shadowsocks-2022 خالی است"
    if inbound.network == Network.GRPC and inbound.security == Security.NONE:
        return (
            f"«{name}»: gRPC بدون TLS/Reality در کلاینت‌ها وصل نمی‌شود — "
            "امنیت را tls یا reality کن"
        )
    return ""


# --------------------------------------------------------------------------
# stream settings
# --------------------------------------------------------------------------
def _tcp_settings(inbound: Inbound) -> dict:
    st = _s(inbound)
    if (inbound.header_type or "none") != "http":
        return {"header": {"type": "none"}}
    request = {
        "version": "1.1",
        "method": st.get("http_method", "GET"),
        "path": _list(st.get("request_paths"), [inbound.path or "/"]) or ["/"],
        "headers": {
            "Host": _list(inbound.host, ["www.cloudflare.com"]),
            "User-Agent": _list(
                st.get("user_agent"),
                [
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
                ],
            ),
            "Accept-Encoding": ["gzip, deflate"],
            "Connection": ["keep-alive"],
            "Pragma": "no-cache",
        },
    }
    response = {
        "version": "1.1",
        "status": "200",
        "reason": "OK",
        "headers": {
            "Content-Type": ["application/octet-stream", "video/mpeg"],
            "Transfer-Encoding": ["chunked"],
            "Connection": ["keep-alive"],
            "Pragma": "no-cache",
        },
    }
    return {"header": {"type": "http", "request": request, "response": response}}


def _ws_settings(inbound: Inbound) -> dict:
    st = _s(inbound)
    ws: dict[str, Any] = {"path": inbound.path or "/"}
    headers = dict(st.get("ws_headers") or {})
    if inbound.host:
        # independent "host"; putting it in headers is deprecated upstream
        ws["host"] = inbound.host
    if headers:
        ws["headers"] = headers
    if _int(st.get("heartbeat_period"), 0):
        ws["heartbeatPeriod"] = _int(st.get("heartbeat_period"), 0)
    return ws


def _grpc_settings(inbound: Inbound) -> dict:
    st = _s(inbound)
    grpc: dict[str, Any] = {
        "serviceName": inbound.service_name or "",
        "multiMode": bool(st.get("multi_mode", False)),
    }
    if _int(st.get("grpc_idle_timeout"), 0):
        grpc["idle_timeout"] = _int(st.get("grpc_idle_timeout"), 0)
    if _int(st.get("grpc_health_check_timeout"), 0):
        grpc["health_check_timeout"] = _int(st.get("grpc_health_check_timeout"), 0)
    if st.get("grpc_permit_without_stream"):
        grpc["permit_without_stream"] = True
    if _int(st.get("grpc_initial_windows_size"), 0):
        grpc["initial_windows_size"] = _int(st.get("grpc_initial_windows_size"), 0)
    if st.get("grpc_authority"):
        grpc["authority"] = st["grpc_authority"]
    return grpc


def _kcp_settings(inbound: Inbound) -> dict:
    """mKCP as current Xray expects it.

    `header` and `seed` were removed upstream; obfuscation is now `finalmask`
    (packet disguise) plus `mkcp-aes128gcm` (shared key) or `mkcp-original`.
    The old fields are accepted here and translated, so an inbound created
    before the change keeps working.
    """
    st = _s(inbound)
    kcp: dict[str, Any] = {
        "mtu": _int(st.get("mtu"), 1350),
        "tti": _int(st.get("tti"), 50),
        "uplinkCapacity": _int(st.get("uplink"), 5),
        "downlinkCapacity": _int(st.get("downlink"), 20),
        "congestion": bool(st.get("congestion", False)),
        "readBufferSize": _int(st.get("read_buffer"), 2),
        "writeBufferSize": _int(st.get("write_buffer"), 2),
    }
    header = (inbound.header_type or "none").strip()
    if header and header != "none":
        kcp["finalmask"] = f"udp header-{header}"
    key = st.get("mkcp_key") or st.get("seed") or ""
    if key:
        kcp["mkcp-aes128gcm"] = key
    elif st.get("mkcp_original"):
        kcp["mkcp-original"] = True
    return kcp


def _xhttp_settings(inbound: Inbound) -> dict:
    st = _s(inbound)
    xh: dict[str, Any] = {
        "path": inbound.path or "/",
        "mode": st.get("mode", "auto"),
    }
    if inbound.host:
        xh["host"] = inbound.host
    extra = st.get("xhttp_extra")
    if isinstance(extra, dict) and extra:
        xh["extra"] = extra
    return xh


def _tls_settings(inbound: Inbound) -> dict:
    st = _s(inbound)
    tls: dict[str, Any] = {
        "serverName": inbound.sni or "",
        "minVersion": st.get("tls_min_version", "1.2"),
        "maxVersion": st.get("tls_max_version", "1.3"),
    }
    if st.get("cipher_suites"):
        tls["cipherSuites"] = st["cipher_suites"]
    if st.get("reject_unknown_sni"):
        tls["rejectUnknownSni"] = True
    if st.get("disable_system_root"):
        tls["disableSystemRoot"] = True
    if inbound.alpn:
        tls["alpn"] = _list(inbound.alpn)
    if inbound.cert_path:
        tls["certificates"] = [
            {
                "certificateFile": inbound.cert_path,
                "keyFile": inbound.key_path,
                "ocspStapling": _int(st.get("ocsp_stapling"), 3600),
            }
        ]
    elif st.get("cert_content"):
        tls["certificates"] = [
            {
                "certificate": _list(st.get("cert_content")),
                "key": _list(st.get("key_content")),
            }
        ]
    else:
        tls["certificates"] = []
    return tls


def _reality_settings(inbound: Inbound) -> dict:
    st = _s(inbound)
    dest = inbound.reality_dest or f"{inbound.sni or 'www.google.com'}:443"
    names = inbound.reality_server_names or ([inbound.sni] if inbound.sni else [])
    reality: dict[str, Any] = {
        "show": bool(st.get("reality_show", False)),
        "dest": dest,
        "xver": _int(st.get("reality_xver"), 0),
        "serverNames": [n for n in names if n],
        "privateKey": inbound.reality_private_key,
        "shortIds": inbound.reality_short_ids or [""],
    }
    if st.get("reality_spider_x"):
        reality["spiderX"] = st["reality_spider_x"]
    if _int(st.get("reality_max_time_diff"), 0):
        reality["maxTimeDiff"] = _int(st.get("reality_max_time_diff"), 0)
    return reality


def build_stream_settings(inbound: Inbound) -> dict:
    network = inbound.network
    # Xray names the HTTP/2 transport "http"; "h2" is only the client-side name.
    stream: dict[str, Any] = {"network": _v(network)}

    if network == Network.WS:
        stream["wsSettings"] = _ws_settings(inbound)
    elif network == Network.GRPC:
        stream["grpcSettings"] = _grpc_settings(inbound)
    elif network == Network.HTTPUPGRADE:
        hu: dict[str, Any] = {"path": inbound.path or "/"}
        if inbound.host:
            hu["host"] = inbound.host
        stream["httpupgradeSettings"] = hu
    elif network == Network.XHTTP:
        stream["xhttpSettings"] = _xhttp_settings(inbound)
    elif network == Network.KCP:
        stream["kcpSettings"] = _kcp_settings(inbound)
    elif network == Network.TCP:
        stream["tcpSettings"] = _tcp_settings(inbound)

    if inbound.security == Security.TLS:
        stream["security"] = "tls"
        stream["tlsSettings"] = _tls_settings(inbound)
    elif inbound.security == Security.REALITY:
        stream["security"] = "reality"
        stream["realitySettings"] = _reality_settings(inbound)
    else:
        stream["security"] = "none"

    st = _s(inbound)
    sockopt: dict[str, Any] = {}
    if st.get("tcp_fast_open"):
        sockopt["tcpFastOpen"] = True
    if st.get("tproxy"):
        sockopt["tproxy"] = st["tproxy"]
    if _int(st.get("tcp_keep_alive_idle"), 0):
        sockopt["tcpKeepAliveIdle"] = _int(st.get("tcp_keep_alive_idle"), 0)
    if _int(st.get("tcp_mptcp"), 0) or st.get("mptcp"):
        sockopt["tcpMptcp"] = True
    if sockopt:
        stream["sockopt"] = sockopt

    # raw override, applied last so an operator can always win
    if isinstance(inbound.stream_settings, dict) and inbound.stream_settings:
        stream = _deep_merge(stream, inbound.stream_settings)
    return stream


def _deep_merge(base: dict, extra: dict) -> dict:
    out = dict(base)
    for key, value in extra.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


# --------------------------------------------------------------------------
# clients
# --------------------------------------------------------------------------
def client_email(inbound: Inbound, user: User) -> str:
    """Unique per (user, inbound).

    Xray registers one stats counter per email; the same email in two inbounds
    collides and makes the whole configuration fail to load, which is why the
    inbound tag is appended here.
    """
    return f"{user.username}#{inbound.tag}"


def client_entry(inbound: Inbound, user: User) -> dict | None:
    email = client_email(inbound, user)
    st = _s(inbound)
    if inbound.protocol == Protocol.VLESS:
        entry: dict[str, Any] = {"id": user.uuid, "email": email, "level": 0}
        flow = effective_flow(inbound)
        if flow:
            entry["flow"] = flow
        return entry
    if inbound.protocol == Protocol.VMESS:
        return {
            "id": user.uuid,
            "email": email,
            "level": 0,
            "alterId": 0,
            "security": st.get("vmess_security", "auto"),
        }
    if inbound.protocol == Protocol.TROJAN:
        return {"password": user.password or user.uuid, "email": email, "level": 0}
    if inbound.protocol == Protocol.SHADOWSOCKS:
        method = st.get("method", "chacha20-ietf-poly1305")
        if method in SS2022_METHODS:
            return {
                "password": user_ss_password(user, inbound),
                "email": email,
                "level": 0,
            }
        # legacy ciphers do not support per-client passwords at all
        return None
    return None


def user_ss_password(user: User, inbound: Inbound) -> str:
    """Shadowsocks-2022 needs a base64 key of an exact length."""
    from app.utils.crypto import ss2022_password

    key_len = 16 if "128" in _s(inbound).get("method", "") else 32
    return ss2022_password(f"{user.username}:{user.uuid}", key_len)


def build_inbound(inbound: Inbound, users: Sequence[User],
                  port_override: int | None = None) -> dict:
    st = _s(inbound)
    settings: dict[str, Any] = {}
    clients = [c for c in (client_entry(inbound, u) for u in users) if c]

    if inbound.protocol == Protocol.VLESS:
        settings = {"clients": clients, "decryption": "none"}
        if st.get("fallbacks"):
            settings["fallbacks"] = st["fallbacks"]
    elif inbound.protocol == Protocol.VMESS:
        settings = {"clients": clients}
        if _int(st.get("disable_insecure_encryption"), 0):
            settings["disableInsecureEncryption"] = True
    elif inbound.protocol == Protocol.TROJAN:
        settings = {"clients": clients}
        if st.get("fallbacks"):
            settings["fallbacks"] = st["fallbacks"]
    elif inbound.protocol == Protocol.SHADOWSOCKS:
        method = st.get("method", "chacha20-ietf-poly1305")
        settings = {"network": st.get("network", "tcp,udp")}
        if method in SS2022_METHODS:
            # multi-user mode: one server key plus one key per client
            settings["method"] = method
            settings["password"] = st.get("server_password", "")
            settings["clients"] = clients
        else:
            # legacy ciphers are single-account only
            settings["method"] = method
            settings["password"] = st.get("server_password") or (
                users[0].password or users[0].uuid if users else "nimexo"
            )
            if st.get("iv_check"):
                settings["ivCheck"] = True

    node_inbound: dict[str, Any] = {
        "tag": inbound.tag,
        "listen": inbound.listen or None,
        "port": port_override or inbound.port,
        "protocol": _v(inbound.protocol),
        "settings": settings,
        "streamSettings": build_stream_settings(inbound),
    }
    if inbound.sniffing:
        node_inbound["sniffing"] = {
            "enabled": True,
            "destOverride": _list(
                st.get("sniff_dest_override"), ["http", "tls", "quic"]
            ),
            "metadataOnly": bool(st.get("sniff_metadata_only", False)),
            "routeOnly": bool(st.get("sniff_route_only", False)),
        }
    if node_inbound["listen"] is None:
        node_inbound.pop("listen")
    return node_inbound


# --------------------------------------------------------------------------
# whole config
# --------------------------------------------------------------------------
def build_config(
    pairs: Iterable[tuple[Inbound, Sequence[User], int | None]],
    log_level: str = "warning",
    extra_outbounds: list | None = None,
    routing_rules: list | None = None,
) -> dict:
    inbounds = [
        {
            "tag": API_TAG,
            "listen": "127.0.0.1",
            "port": API_PORT,
            "protocol": "dokodemo-door",
            "settings": {"address": "127.0.0.1"},
        }
    ]
    for inbound, users, port_override in pairs:
        inbounds.append(build_inbound(inbound, users, port_override))

    outbounds = [
        {"protocol": "freedom", "tag": "direct", "settings": {}},
        {"protocol": "blackhole", "tag": "blocked", "settings": {}},
    ]
    if extra_outbounds:
        outbounds.extend(extra_outbounds)

    rules = [
        {"type": "field", "inboundTag": [API_TAG], "outboundTag": API_TAG},
        {"type": "field", "protocol": ["bittorrent"], "outboundTag": "blocked"},
        # Written out as plain CIDRs on purpose: "geoip:private" needs
        # geoip.dat next to the binary, and a missing asset makes Xray reject
        # the whole config instead of just this rule.
        {"type": "field", "ip": PRIVATE_RANGES, "outboundTag": "blocked"},
    ]
    if routing_rules:
        rules.extend(routing_rules)

    return {
        "log": {"loglevel": log_level, "access": "none"},
        "api": {"tag": API_TAG, "services": ["HandlerService", "StatsService"]},
        "stats": {},
        "policy": {
            "levels": {
                "0": {
                    "statsUserUplink": True,
                    "statsUserDownlink": True,
                    "handshake": 4,
                    "connIdle": 300,
                }
            },
            "system": {
                "statsInboundUplink": True,
                "statsInboundDownlink": True,
                "statsOutboundUplink": True,
                "statsOutboundDownlink": True,
            },
        },
        "inbounds": inbounds,
        "outbounds": outbounds,
        "routing": {"domainStrategy": "AsIs", "rules": rules},
    }
