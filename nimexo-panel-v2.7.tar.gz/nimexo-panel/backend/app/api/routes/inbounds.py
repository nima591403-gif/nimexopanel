import base64
import secrets

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status
from sqlalchemy.orm import Session, selectinload

from app.api.deps import current_admin, require_manager
from app.db import get_db, session_scope
from app.models import Admin, Inbound, Node, NodeInbound
from app.models.enums import PROTOCOL_CORE, AdminRole, CoreType, Protocol, Security
from app.schemas.common import Message
from app.schemas.entities import InboundCreate, InboundOut, InboundUpdate
from app.services import sync as sync_service
from app.services.cores import wireguard as wg_core
from app.services.cores import xray as xray_core
from app.utils.crypto import ss2022_password

router = APIRouter(prefix="/api/inbounds", tags=["inbounds"])


def _b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _x25519_pair() -> tuple[str, str]:
    private = X25519PrivateKey.generate()
    priv = private.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    return _b64url(priv), _b64url(pub)


def _public_from_private(private_b64: str) -> str:
    padded = private_b64 + "=" * (-len(private_b64) % 4)
    raw = base64.urlsafe_b64decode(padded.encode())
    key = X25519PrivateKey.from_private_bytes(raw)
    return _b64url(
        key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
        )
    )


def ensure_reality(inbound: Inbound) -> None:
    """Never let a Reality inbound be saved half-configured.

    An empty private key makes Xray reject the whole config, and an empty
    public key produces a share link without `pbk` that every client refuses.
    """
    if inbound.security != Security.REALITY:
        return
    if not inbound.reality_private_key:
        inbound.reality_private_key, inbound.reality_public_key = _x25519_pair()
    elif not inbound.reality_public_key:
        try:
            inbound.reality_public_key = _public_from_private(inbound.reality_private_key)
        except Exception:  # noqa: BLE001 — malformed key pasted by hand
            inbound.reality_private_key, inbound.reality_public_key = _x25519_pair()
    if not inbound.reality_short_ids:
        inbound.reality_short_ids = [secrets.token_hex(4), secrets.token_hex(8)]
    if not inbound.reality_server_names and inbound.sni:
        inbound.reality_server_names = [inbound.sni]
    if not inbound.reality_dest:
        inbound.reality_dest = f"{inbound.sni or 'www.google.com'}:443"


def ensure_shadowsocks(inbound: Inbound) -> None:
    """Every Shadowsocks inbound needs a server key of the right shape."""
    if inbound.protocol != Protocol.SHADOWSOCKS:
        return
    settings = dict(inbound.settings or {})
    method = settings.get("method", "chacha20-ietf-poly1305")
    settings["method"] = method
    if not settings.get("server_password"):
        if method in xray_core.SS2022_METHODS:
            key_len = 16 if "128" in method else 32
            settings["server_password"] = ss2022_password(secrets.token_hex(32), key_len)
        else:
            # legacy ciphers are single-account: one shared key for the inbound
            settings["server_password"] = secrets.token_urlsafe(16)
    settings.setdefault("network", "tcp,udp")
    inbound.settings = settings


def _serialize(db: Session, inbound: Inbound) -> dict:
    data = {
        c: getattr(inbound, c)
        for c in (
            "id", "tag", "remark", "core", "protocol", "listen", "port", "network",
            "security", "sni", "host", "path", "service_name", "header_type", "alpn",
            "fingerprint", "flow", "allow_insecure", "reality_public_key",
            "reality_private_key", "reality_short_ids", "reality_dest",
            "reality_server_names", "cert_path", "key_path", "settings",
            "stream_settings", "sniffing", "is_enabled", "is_default", "sort_order",
            "created_at",
        )
    }
    data["node_inbounds"] = [
        {
            "node_id": ni.node_id,
            "is_enabled": ni.is_enabled,
            "synced_at": ni.synced_at,
            "sync_error": ni.sync_error,
            "port_override": ni.port_override,
            "address_override": ni.address_override,
        }
        for ni in inbound.node_inbounds
    ]
    data["users_count"] = len(inbound.users)
    data["warning"] = (
        xray_core.validate_inbound(inbound) if inbound.core == CoreType.XRAY else ""
    )
    return data


@router.get("", response_model=list[InboundOut])
def list_inbounds(db: Session = Depends(get_db), admin: Admin = Depends(current_admin)):
    query = db.query(Inbound).options(
        selectinload(Inbound.node_inbounds), selectinload(Inbound.users)
    )
    allowed = admin.allowed_inbound_ids or []
    if admin.role == AdminRole.RESELLER and allowed:
        query = query.filter(Inbound.id.in_(allowed))
    rows = query.order_by(Inbound.sort_order, Inbound.id).all()
    return [_serialize(db, i) for i in rows]


@router.post("/reality-keys", response_model=dict)
def reality_keys(_: Admin = Depends(require_manager)):
    """Generate an X25519 pair in Xray's base64url format."""
    private_key, public_key = _x25519_pair()
    return {
        "private_key": private_key,
        "public_key": public_key,
        "short_ids": [secrets.token_hex(4), secrets.token_hex(8)],
    }


@router.post("", response_model=InboundOut, status_code=201)
def create_inbound(payload: InboundCreate, background: BackgroundTasks,
                   db: Session = Depends(get_db), _: Admin = Depends(require_manager)):
    if db.query(Inbound).filter(Inbound.tag == payload.tag).first():
        raise HTTPException(status.HTTP_409_CONFLICT, "an inbound with this tag exists")

    data = payload.model_dump(exclude={"node_ids"})
    expected_core = PROTOCOL_CORE.get(payload.protocol)
    if expected_core and data["core"] != expected_core:
        data["core"] = expected_core

    inbound = Inbound(**data)

    ensure_shadowsocks(inbound)
    if inbound.core == CoreType.WIREGUARD:
        wg_core.ensure_server_keys(inbound)
    ensure_reality(inbound)

    db.add(inbound)
    db.flush()

    for node_id in payload.node_ids:
        db.add(NodeInbound(node_id=node_id, inbound_id=inbound.id))
    db.commit()

    sync_service.log(db, "inbound_created", f"inbound {inbound.tag} created",
                     target=inbound.tag)
    background.add_task(_sync_nodes, payload.node_ids)
    return _serialize(db, inbound)


@router.patch("/{inbound_id}", response_model=InboundOut)
def update_inbound(inbound_id: int, payload: InboundUpdate,
                   background: BackgroundTasks, db: Session = Depends(get_db),
                   _: Admin = Depends(require_manager)):
    inbound = db.query(Inbound).get(inbound_id)
    if inbound is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "inbound not found")

    data = payload.model_dump(exclude_unset=True)
    node_ids = data.pop("node_ids", None)
    for key, value in data.items():
        setattr(inbound, key, value)

    ensure_reality(inbound)
    ensure_shadowsocks(inbound)

    affected = {ni.node_id for ni in inbound.node_inbounds}
    if node_ids is not None:
        existing = {ni.node_id: ni for ni in inbound.node_inbounds}
        for node_id in node_ids:
            if node_id not in existing:
                db.add(NodeInbound(node_id=node_id, inbound_id=inbound.id))
        for node_id, ni in existing.items():
            if node_id not in node_ids:
                db.delete(ni)
        affected |= set(node_ids)

    db.add(inbound)
    db.commit()
    background.add_task(_sync_nodes, list(affected))
    return _serialize(db, inbound)


@router.delete("/{inbound_id}", response_model=Message)
def delete_inbound(inbound_id: int, background: BackgroundTasks,
                   db: Session = Depends(get_db), _: Admin = Depends(require_manager)):
    inbound = db.query(Inbound).get(inbound_id)
    if inbound is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "inbound not found")
    tag = inbound.tag
    affected = [ni.node_id for ni in inbound.node_inbounds]
    db.delete(inbound)
    db.commit()
    sync_service.log(db, "inbound_deleted", f"inbound {tag} removed", target=tag)
    background.add_task(_sync_nodes, affected)
    return Message(message=f"inbound {tag} removed")


@router.post("/{inbound_id}/nodes/{node_id}", response_model=Message)
def deploy_to_node(inbound_id: int, node_id: int, background: BackgroundTasks,
                   port_override: int | None = None, address_override: str = "",
                   db: Session = Depends(get_db),
                   _: Admin = Depends(require_manager)):
    inbound = db.query(Inbound).get(inbound_id)
    node = db.query(Node).get(node_id)
    if inbound is None or node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "inbound or node not found")
    row = (
        db.query(NodeInbound)
        .filter(NodeInbound.inbound_id == inbound_id, NodeInbound.node_id == node_id)
        .one_or_none()
    )
    if row is None:
        row = NodeInbound(inbound_id=inbound_id, node_id=node_id)
    row.port_override = port_override
    row.address_override = address_override
    row.is_enabled = True
    db.add(row)
    db.commit()
    background.add_task(_sync_nodes, [node_id])
    return Message(message=f"{inbound.tag} deployed to {node.name}")


def _sync_nodes(node_ids: list[int]) -> None:
    if not node_ids:
        return
    with session_scope() as db:
        for node in db.query(Node).filter(Node.id.in_(node_ids)).all():
            sync_service.sync_node(db, node)
