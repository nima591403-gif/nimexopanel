#!/usr/bin/env python3
"""NimexoPanel node agent.

A dependency-free helper that the panel uploads to every node
(/opt/nimexo/agent.py) and invokes over SSH:

    python3 /opt/nimexo/agent.py <command> [args]     # JSON payload on stdin
    -> a single JSON object on stdout

It never listens on a port; the panel is always the initiator.

Commands
--------
ping                      agent + core versions
sysinfo                   cpu / mem / disk / uptime / net counters
install <core>            install or update xray | wireguard | openvpn
apply-xray                write config.json (stdin) and reload the core
xray-stats [--reset]      per-user up/down counters from the Xray stats API
apply-wireguard           write interfaces + peers (stdin) and sync them
wg-stats                  per-peer transfer counters
apply-openvpn             write the account list (stdin)
ovpn-stats                per-CN transfer counters and live sessions
restart <core>            restart a managed service
logs <core> [n]           last n journal lines
uninstall <core>          stop and remove a managed core
"""
from __future__ import annotations

import base64
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request

AGENT_VERSION = "1.1.0"
BASE_DIR = "/opt/nimexo"
XRAY_DIR = f"{BASE_DIR}/xray"
WG_DIR = "/etc/wireguard"
OVPN_DIR = f"{BASE_DIR}/openvpn"
STATE_DIR = f"{BASE_DIR}/state"

XRAY_BIN = "/usr/local/bin/nimexo-xray"
XRAY_SERVICE = "nimexo-xray"
XRAY_API = "127.0.0.1:10085"
XRAY_RELEASE = (
    "https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip"
)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def run(cmd, input_data=None, timeout=300, check=False):
    proc = subprocess.run(
        cmd,
        shell=isinstance(cmd, str),
        input=input_data.encode() if isinstance(input_data, str) else input_data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    out = proc.stdout.decode("utf-8", "replace")
    err = proc.stderr.decode("utf-8", "replace")
    if check and proc.returncode != 0:
        raise RuntimeError(f"{cmd} -> {proc.returncode}: {err.strip() or out.strip()}")
    return proc.returncode, out, err


def which(binary):
    return shutil.which(binary) or ""


def ensure_dirs():
    for d in (BASE_DIR, XRAY_DIR, OVPN_DIR, STATE_DIR):
        os.makedirs(d, exist_ok=True)
    os.chmod(BASE_DIR, 0o750)


def write_file(path, content, mode=0o600):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as fh:
        fh.write(content)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def read_stdin_json():
    data = sys.stdin.read()
    return json.loads(data) if data.strip() else {}


def systemd_write(name, unit_text):
    write_file(f"/etc/systemd/system/{name}.service", unit_text, 0o644)
    run("systemctl daemon-reload")


def service_active(name):
    code, out, _ = run(f"systemctl is-active {name}")
    return out.strip() == "active"


def apt_install(packages):
    env = "DEBIAN_FRONTEND=noninteractive"
    run(f"{env} apt-get update -y", timeout=600)
    code, out, err = run(
        f"{env} apt-get install -y --no-install-recommends {' '.join(packages)}",
        timeout=900,
    )
    if code != 0:
        raise RuntimeError(f"apt install failed: {err.strip()[:500]}")


def default_iface():
    code, out, _ = run("ip route show default")
    m = re.search(r"dev\s+(\S+)", out)
    return m.group(1) if m else "eth0"


def enable_forwarding():
    write_file("/etc/sysctl.d/99-nimexo.conf",
               "net.ipv4.ip_forward=1\nnet.ipv6.conf.all.forwarding=1\n", 0o644)
    run("sysctl --system")


def ensure_nat(subnet, iface=None):
    iface = iface or default_iface()
    code, _, _ = run(
        f"iptables -t nat -C POSTROUTING -s {subnet} -o {iface} -j MASQUERADE"
    )
    if code != 0:
        run(f"iptables -t nat -A POSTROUTING -s {subnet} -o {iface} -j MASQUERADE")
    for rule in (
        f"-s {subnet} -j ACCEPT",
        f"-d {subnet} -m state --state RELATED,ESTABLISHED -j ACCEPT",
    ):
        code, _, _ = run(f"iptables -C FORWARD {rule}")
        if code != 0:
            run(f"iptables -I FORWARD 1 {rule}")


# --------------------------------------------------------------------------
# sysinfo
# --------------------------------------------------------------------------
def cpu_percent(interval=0.4):
    def snapshot():
        with open("/proc/stat") as fh:
            parts = [float(x) for x in fh.readline().split()[1:]]
        idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
        return sum(parts), idle

    t1, i1 = snapshot()
    time.sleep(interval)
    t2, i2 = snapshot()
    dt, di = t2 - t1, i2 - i1
    return round(100.0 * (dt - di) / dt, 1) if dt > 0 else 0.0


def mem_info():
    info = {}
    with open("/proc/meminfo") as fh:
        for line in fh:
            k, v = line.split(":", 1)
            info[k] = int(v.strip().split()[0]) * 1024
    total = info.get("MemTotal", 0)
    available = info.get("MemAvailable", 0)
    used = total - available
    return {
        "total": total,
        "used": used,
        "percent": round(100.0 * used / total, 1) if total else 0.0,
    }


def net_counters():
    tx = rx = 0
    with open("/proc/net/dev") as fh:
        for line in fh.readlines()[2:]:
            name, _, rest = line.partition(":")
            name = name.strip()
            if name == "lo" or name.startswith(("veth", "docker", "br-")):
                continue
            fields = rest.split()
            rx += int(fields[0])
            tx += int(fields[8])
    return {"rx": rx, "tx": tx}


def cmd_sysinfo():
    st = os.statvfs("/")
    disk_total = st.f_blocks * st.f_frsize
    disk_free = st.f_bavail * st.f_frsize
    with open("/proc/uptime") as fh:
        uptime = float(fh.readline().split()[0])

    prev_path = f"{STATE_DIR}/net.json"
    now = time.time()
    counters = net_counters()
    speed = {"tx": 0.0, "rx": 0.0}
    try:
        with open(prev_path) as fh:
            prev = json.load(fh)
        dt = now - prev["ts"]
        if 0 < dt < 3600:
            speed = {
                "tx": max(0.0, (counters["tx"] - prev["tx"]) / dt),
                "rx": max(0.0, (counters["rx"] - prev["rx"]) / dt),
            }
    except Exception:
        pass
    try:
        ensure_dirs()
        write_file(prev_path, json.dumps({"ts": now, **counters}), 0o644)
    except Exception:
        pass

    return {
        "agent_version": AGENT_VERSION,
        "cpu_percent": cpu_percent(),
        "memory": mem_info(),
        "disk": {
            "total": disk_total,
            "used": disk_total - disk_free,
            "percent": round(100.0 * (disk_total - disk_free) / disk_total, 1)
            if disk_total
            else 0.0,
        },
        "uptime": int(uptime),
        "net": counters,
        "net_speed": speed,
        "load": os.getloadavg(),
        "cores": installed_cores(),
        "services": {
            XRAY_SERVICE: service_active(XRAY_SERVICE),
            "wg-quick@": bool(which("wg")),
            "openvpn-server@nimexo": service_active("openvpn-server@nimexo"),
        },
    }


def installed_cores():
    cores = {}
    if os.path.exists(XRAY_BIN):
        _, out, _ = run(f"{XRAY_BIN} version")
        m = re.search(r"Xray\s+([\d.]+)", out)
        cores["xray"] = m.group(1) if m else "unknown"
    if which("wg"):
        _, out, _ = run("wg --version")
        m = re.search(r"v([\d.]+)", out)
        cores["wireguard"] = m.group(1) if m else "installed"
    if which("openvpn"):
        _, out, _ = run("openvpn --version")
        m = re.search(r"OpenVPN\s+([\d.]+)", out)
        cores["openvpn"] = m.group(1) if m else "installed"
    if which("ocserv"):
        cores["ocserv"] = "installed"
    if which("xl2tpd"):
        cores["l2tp"] = "installed"
    return cores


# --------------------------------------------------------------------------
# xray
# --------------------------------------------------------------------------
def install_xray():
    ensure_dirs()
    if not which("unzip"):
        apt_install(["unzip", "ca-certificates", "curl"])
    tmp_zip = "/tmp/nimexo-xray.zip"
    urllib.request.urlretrieve(XRAY_RELEASE, tmp_zip)  # noqa: S310
    run(f"rm -rf /tmp/nimexo-xray && mkdir -p /tmp/nimexo-xray")
    run(f"unzip -o {tmp_zip} -d /tmp/nimexo-xray", check=True)
    shutil.copy("/tmp/nimexo-xray/xray", XRAY_BIN)
    os.chmod(XRAY_BIN, 0o755)
    for asset in ("geoip.dat", "geosite.dat"):
        src = f"/tmp/nimexo-xray/{asset}"
        if os.path.exists(src):
            shutil.copy(src, f"{XRAY_DIR}/{asset}")

    if not os.path.exists(f"{XRAY_DIR}/config.json"):
        write_file(f"{XRAY_DIR}/config.json", json.dumps(
            {"log": {"loglevel": "warning"}, "inbounds": [], "outbounds": [
                {"protocol": "freedom", "tag": "direct"}]}, indent=2))

    systemd_write(XRAY_SERVICE, f"""[Unit]
Description=NimexoPanel Xray core
After=network.target nss-lookup.target

[Service]
Type=simple
User=root
Environment=XRAY_LOCATION_ASSET={XRAY_DIR}
ExecStart={XRAY_BIN} run -config {XRAY_DIR}/config.json
Restart=on-failure
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
""")
    run(f"systemctl enable --now {XRAY_SERVICE}")
    enable_forwarding()
    return {"installed": "xray", "version": installed_cores().get("xray", "")}


def cmd_apply_xray():
    payload = read_stdin_json()
    config = payload.get("config") or payload
    ensure_dirs()
    text = json.dumps(config, indent=2, ensure_ascii=False)
    candidate = f"{XRAY_DIR}/config.new.json"
    write_file(candidate, text)
    code, out, err = run(f"{XRAY_BIN} run -test -config {candidate}")
    if code != 0:
        return {"ok": False, "error": (err or out).strip()[:2000]}
    os.replace(candidate, f"{XRAY_DIR}/config.json")
    code, out, err = run(f"systemctl restart {XRAY_SERVICE}")
    time.sleep(1.0)
    active = service_active(XRAY_SERVICE)
    return {
        "ok": active,
        "error": "" if active else (err or out).strip()[:2000],
        "inbounds": len(config.get("inbounds", [])),
    }


def cmd_xray_stats(reset=True):
    if not os.path.exists(XRAY_BIN):
        return {"users": {}, "inbounds": {}}
    flag = "-reset" if reset else ""
    code, out, err = run(
        f'{XRAY_BIN} api statsquery --server={XRAY_API} {flag} -pattern ""'
    )
    if code != 0:
        return {"users": {}, "inbounds": {}, "error": (err or out).strip()[:500]}
    try:
        stats = json.loads(out).get("stat", []) or []
    except json.JSONDecodeError:
        return {"users": {}, "inbounds": {}, "error": "unparsable stats output"}

    users, inbounds = {}, {}
    for item in stats:
        name = item.get("name", "")
        value = int(item.get("value", 0) or 0)
        if not value:
            continue
        parts = name.split(">>>")
        if len(parts) != 4:
            continue
        kind, ident, _, direction = parts
        bucket = users if kind == "user" else inbounds
        entry = bucket.setdefault(ident, {"up": 0, "down": 0})
        if direction in ("uplink", "downlink"):
            entry["up" if direction == "uplink" else "down"] += value
    return {"users": users, "inbounds": inbounds}


# --------------------------------------------------------------------------
# wireguard
# --------------------------------------------------------------------------
def install_wireguard():
    if not which("wg"):
        apt_install(["wireguard", "wireguard-tools", "iptables"])
    enable_forwarding()
    return {"installed": "wireguard", "version": installed_cores().get("wireguard", "")}


def cmd_apply_wireguard():
    """payload = {"interfaces": [{name, private_key, port, address, mtu,
                                  subnet, peers:[{public_key, allowed_ips,
                                  preshared_key}]}]}"""
    payload = read_stdin_json()
    results = []
    wanted = set()
    os.makedirs(WG_DIR, exist_ok=True)
    for iface in payload.get("interfaces", []):
        name = iface["name"]
        wanted.add(name)
        lines = [
            "[Interface]",
            f"PrivateKey = {iface['private_key']}",
            f"Address = {iface['address']}",
            f"ListenPort = {iface['port']}",
        ]
        if iface.get("mtu"):
            lines.append(f"MTU = {iface['mtu']}")
        lines.append("SaveConfig = false")
        for peer in iface.get("peers", []):
            lines += [
                "",
                "[Peer]",
                f"# {peer.get('name', '')}",
                f"PublicKey = {peer['public_key']}",
                f"AllowedIPs = {peer['allowed_ips']}",
            ]
            if peer.get("preshared_key"):
                lines.append(f"PresharedKey = {peer['preshared_key']}")
        write_file(f"{WG_DIR}/{name}.conf", "\n".join(lines) + "\n", 0o600)

        if iface.get("subnet"):
            ensure_nat(iface["subnet"])

        if service_active(f"wg-quick@{name}"):
            # hot-reload peers without dropping existing sessions
            code, out, err = run(
                f"bash -c 'wg syncconf {name} <(wg-quick strip {name})'"
            )
            if code != 0:
                run(f"systemctl restart wg-quick@{name}")
        else:
            run(f"systemctl enable --now wg-quick@{name}")
        results.append({"name": name, "active": service_active(f"wg-quick@{name}")})

    # tear down interfaces the panel no longer knows about
    for fname in os.listdir(WG_DIR):
        if not fname.endswith(".conf"):
            continue
        name = fname[:-5]
        if name.startswith("nx-") and name not in wanted:
            run(f"systemctl disable --now wg-quick@{name}")
            os.remove(f"{WG_DIR}/{fname}")
    return {"ok": True, "interfaces": results}


def cmd_wg_stats():
    if not which("wg"):
        return {"peers": {}}
    code, out, _ = run("wg show all dump")
    peers = {}
    if code != 0:
        return {"peers": {}}
    for line in out.splitlines():
        cols = line.split("\t")
        if len(cols) < 9:
            continue  # interface line
        iface, public_key = cols[0], cols[1]
        endpoint, handshake = cols[3], cols[4]
        rx, tx = int(cols[5] or 0), int(cols[6] or 0)
        peers[public_key] = {
            "interface": iface,
            "endpoint": endpoint if endpoint != "(none)" else "",
            "last_handshake": int(handshake or 0),
            "down": rx,
            "up": tx,
        }
    return {"peers": peers}


# --------------------------------------------------------------------------
# openvpn
# --------------------------------------------------------------------------
AUTH_SCRIPT = r"""#!/bin/bash
# NimexoPanel OpenVPN credential check (via-file)
creds="$1"
user=$(head -n 1 "$creds")
pass=$(tail -n 1 "$creds")
db=/opt/nimexo/openvpn/users
[ -f "$db" ] || exit 1
line=$(grep -m1 -F -- "${user}:" "$db") || exit 1
expected="${line#*:}"
[ -n "$expected" ] && [ "$pass" = "$expected" ] && exit 0
exit 1
"""


def install_openvpn(payload=None):
    payload = payload or {}
    if not which("openvpn"):
        apt_install(["openvpn", "easy-rsa", "openssl", "iptables"])
    ensure_dirs()
    pki = f"{OVPN_DIR}/pki"
    os.makedirs(pki, exist_ok=True)

    if not os.path.exists(f"{pki}/ca.crt"):
        run(f"openssl genrsa -out {pki}/ca.key 2048", check=True)
        run(
            f"openssl req -x509 -new -nodes -key {pki}/ca.key -sha256 -days 3650 "
            f"-subj '/CN=Nimexo-CA' -out {pki}/ca.crt",
            check=True,
        )
        run(f"openssl genrsa -out {pki}/server.key 2048", check=True)
        run(
            f"openssl req -new -key {pki}/server.key -subj '/CN=nimexo-server' "
            f"-out {pki}/server.csr",
            check=True,
        )
        run(
            f"openssl x509 -req -in {pki}/server.csr -CA {pki}/ca.crt "
            f"-CAkey {pki}/ca.key -CAcreateserial -days 3650 -sha256 "
            f"-out {pki}/server.crt",
            check=True,
        )
        run(f"openssl dhparam -out {pki}/dh.pem 2048", timeout=1800, check=True)
        run(f"openvpn --genkey secret {pki}/ta.key", check=True)

    write_file(f"{OVPN_DIR}/auth.sh", AUTH_SCRIPT, 0o750)
    if not os.path.exists(f"{OVPN_DIR}/users"):
        write_file(f"{OVPN_DIR}/users", "", 0o600)

    port = int(payload.get("port") or 1194)
    proto = payload.get("proto") or "udp"
    subnet = payload.get("subnet") or "10.20.0.0"
    mask = payload.get("mask") or "255.255.255.0"
    mtu = int(payload.get("mtu") or 1280)
    cipher = payload.get("cipher") or "AES-128-GCM"
    dns = payload.get("dns") or ["1.1.1.1", "8.8.8.8"]

    conf = f"""# managed by NimexoPanel
port {port}
proto {proto}
dev tun
ca {pki}/ca.crt
cert {pki}/server.crt
key {pki}/server.key
dh {pki}/dh.pem
tls-auth {pki}/ta.key 0
topology subnet
server {subnet} {mask}
ifconfig-pool-persist {OVPN_DIR}/ipp.txt
push "redirect-gateway def1 bypass-dhcp"
{chr(10).join(f'push "dhcp-option DNS {d}"' for d in dns)}
keepalive 10 60
data-ciphers {cipher}:AES-256-GCM:CHACHA20-POLY1305
data-ciphers-fallback {cipher}
auth SHA256
tun-mtu {mtu}
mssfix {max(mtu - 40, 1000)}
persist-key
persist-tun
verify-client-cert none
username-as-common-name
script-security 2
auth-user-pass-verify {OVPN_DIR}/auth.sh via-file
duplicate-cn
status {OVPN_DIR}/status.log 10
status-version 3
log-append /var/log/nimexo-openvpn.log
verb 3
"""
    write_file("/etc/openvpn/server/nimexo.conf", conf, 0o644)
    enable_forwarding()
    ensure_nat(f"{subnet}/{sum(bin(int(x)).count('1') for x in mask.split('.'))}")
    run("systemctl enable --now openvpn-server@nimexo")
    run("systemctl restart openvpn-server@nimexo")
    with open(f"{pki}/ca.crt") as fh:
        ca = fh.read()
    with open(f"{pki}/ta.key") as fh:
        ta = fh.read()
    return {
        "installed": "openvpn",
        "active": service_active("openvpn-server@nimexo"),
        "ca": ca,
        "tls_auth": ta,
        "port": port,
        "proto": proto,
    }


def cmd_apply_openvpn():
    """payload = {"users": [{"username": "...", "password": "..."}],
                  "server": {...optional server params to re-render...}}"""
    payload = read_stdin_json()
    ensure_dirs()
    lines = [
        f"{u['username']}:{u['password']}"
        for u in payload.get("users", [])
        if u.get("username")
    ]
    write_file(f"{OVPN_DIR}/users", "\n".join(lines) + "\n", 0o600)

    disconnected = []
    for username in payload.get("revoke", []):
        code, _, _ = run(
            "bash -c "
            "\"echo 'kill %s' | nc -q1 -U /run/nimexo-ovpn.sock\"" % username
        )
        if code == 0:
            disconnected.append(username)

    result = {"ok": True, "users": len(lines), "revoked": disconnected}
    if payload.get("server"):
        result.update(install_openvpn(payload["server"]))
    return result


def cmd_ovpn_pki():
    """Return the material a client config needs (CA + tls-auth key)."""
    pki = f"{OVPN_DIR}/pki"
    result = {"ca": "", "tls_auth": "", "present": False}
    ca_path, ta_path = f"{pki}/ca.crt", f"{pki}/ta.key"
    if os.path.exists(ca_path):
        with open(ca_path) as fh:
            result["ca"] = fh.read()
        result["present"] = True
    if os.path.exists(ta_path):
        with open(ta_path) as fh:
            result["tls_auth"] = fh.read()
    if not result["present"]:
        result["error"] = f"{ca_path} not found — OpenVPN is not installed yet"
    return result


def cmd_ovpn_stats():
    path = f"{OVPN_DIR}/status.log"
    if not os.path.exists(path):
        return {"clients": {}}
    clients = {}
    with open(path) as fh:
        for line in fh:
            cols = line.strip().split(",")
            if not cols or cols[0] != "CLIENT_LIST":
                continue
            # CLIENT_LIST,CN,RealAddr,VirtAddr,VirtIPv6,BytesRx,BytesTx,...
            try:
                cn = cols[1]
                entry = clients.setdefault(cn, {"up": 0, "down": 0, "sessions": []})
                entry["down"] += int(cols[5] or 0)
                entry["up"] += int(cols[6] or 0)
                entry["sessions"].append(
                    {"ip": cols[2].split(":")[0], "since": cols[7] if len(cols) > 7 else ""}
                )
            except (IndexError, ValueError):
                continue
    return {"clients": clients}


# --------------------------------------------------------------------------
# generic
# --------------------------------------------------------------------------
SERVICE_MAP = {
    "xray": XRAY_SERVICE,
    "openvpn": "openvpn-server@nimexo",
}


def cmd_restart(core, name=None):
    service = SERVICE_MAP.get(core) or (f"wg-quick@{name}" if core == "wireguard" else core)
    code, out, err = run(f"systemctl restart {service}")
    return {"ok": code == 0, "service": service, "error": (err or out).strip()[:500]}


def cmd_logs(core, lines=200, name=None):
    service = SERVICE_MAP.get(core) or (f"wg-quick@{name}" if core == "wireguard" else core)
    _, out, _ = run(f"journalctl -u {service} -n {int(lines)} --no-pager -o short-iso")
    return {"service": service, "logs": out}


def cmd_uninstall(core):
    if core == "xray":
        run(f"systemctl disable --now {XRAY_SERVICE}")
        for p in (XRAY_BIN, f"/etc/systemd/system/{XRAY_SERVICE}.service"):
            if os.path.exists(p):
                os.remove(p)
        run("systemctl daemon-reload")
    elif core == "openvpn":
        run("systemctl disable --now openvpn-server@nimexo")
        if os.path.exists("/etc/openvpn/server/nimexo.conf"):
            os.remove("/etc/openvpn/server/nimexo.conf")
    elif core == "wireguard":
        for fname in os.listdir(WG_DIR) if os.path.isdir(WG_DIR) else []:
            if fname.startswith("nx-") and fname.endswith(".conf"):
                run(f"systemctl disable --now wg-quick@{fname[:-5]}")
                os.remove(f"{WG_DIR}/{fname}")
    return {"ok": True, "core": core}


def main(argv):
    ensure_dirs()
    if len(argv) < 2:
        return {"error": "no command"}
    cmd = argv[1]
    args = argv[2:]

    if cmd == "ping":
        return {"agent_version": AGENT_VERSION, "cores": installed_cores()}
    if cmd == "sysinfo":
        return cmd_sysinfo()
    if cmd == "install":
        core = args[0] if args else ""
        payload = read_stdin_json() if not sys.stdin.isatty() else {}
        if core == "xray":
            return install_xray()
        if core == "wireguard":
            return install_wireguard()
        if core == "openvpn":
            return install_openvpn(payload.get("server") or payload)
        return {"error": f"unknown core {core}"}
    if cmd == "apply-xray":
        return cmd_apply_xray()
    if cmd == "xray-stats":
        return cmd_xray_stats(reset="--no-reset" not in args)
    if cmd == "apply-wireguard":
        return cmd_apply_wireguard()
    if cmd == "wg-stats":
        return cmd_wg_stats()
    if cmd == "apply-openvpn":
        return cmd_apply_openvpn()
    if cmd == "ovpn-stats":
        return cmd_ovpn_stats()
    if cmd == "ovpn-pki":
        return cmd_ovpn_pki()
    if cmd == "restart":
        return cmd_restart(args[0] if args else "", args[1] if len(args) > 1 else None)
    if cmd == "logs":
        return cmd_logs(
            args[0] if args else "",
            int(args[1]) if len(args) > 1 else 200,
            args[2] if len(args) > 2 else None,
        )
    if cmd == "uninstall":
        return cmd_uninstall(args[0] if args else "")
    return {"error": f"unknown command {cmd}"}


if __name__ == "__main__":
    try:
        result = main(sys.argv)
    except Exception as exc:  # noqa: BLE001
        result = {"error": f"{type(exc).__name__}: {exc}"}
        print(json.dumps(result))
        sys.exit(1)
    print(json.dumps(result))
