import os

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import current_admin, require_manager, require_sudo
from app.db import get_db
from app.models import Admin, Inbound, Node
from app.services import local_certs, settings_store
from app.services import sync as sync_service
from app.services.node_manager import NodeError, agent_for
from app.services.ssh import SSHError

router = APIRouter(prefix="/api", tags=["certificates"])

# node_id 0 means "the machine the panel itself runs on"
PANEL_NODE_ID = 0


class CertRequest(BaseModel):
    node_id: int = PANEL_NODE_ID
    domain: str
    email: str = ""
    method: str = "http"          # http | cloudflare
    cf_token: str = ""            # only for the cloudflare method
    staging: bool = False
    force: bool = False
    apply_to_inbound_id: int | None = None
    # point the node's public address at this domain, so every share link and
    # client config stops using the bare IP
    set_node_address: bool = False
    # use the certificate for the panel's own subscription listener
    use_for_subscription: bool = False


class SelfSignedRequest(BaseModel):
    node_id: int = PANEL_NODE_ID
    domain: str = ""
    apply_to_inbound_id: int | None = None
    force: bool = False


class PanelSettings(BaseModel):
    brand_name: str | None = None
    panel_domain: str | None = None
    panel_public_url: str | None = None
    sub_domain: str | None = None
    sub_path: str | None = None
    sub_port: int | None = None
    sub_https: bool | None = None
    sub_profile_title: str | None = None
    panel_cert: str | None = None
    panel_key: str | None = None
    client_domain: str | None = None
    portal_enabled: bool | None = None
    portal_note: str | None = None
    telegram_bot_token: str | None = None
    telegram_support: str | None = None
    notify_days_before: int | None = None
    notify_traffic_percent: int | None = None
    migrate_enabled: bool | None = None
    migrate_group_id: int | None = None


def _node_or_404(db: Session, node_id: int) -> Node:
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    return node


# --------------------------------------------------------------------------
# listing
# --------------------------------------------------------------------------
@router.get("/certificates")
def list_certificates(node_id: int | None = None, db: Session = Depends(get_db),
                      _: Admin = Depends(require_manager)):
    """Certificates present on the panel host and on each node."""
    result = []
    if node_id in (None, PANEL_NODE_ID):
        try:
            data = local_certs.cert_list()
            result.append(
                {
                    "node_id": PANEL_NODE_ID,
                    "node": "خود پنل (این سرور)",
                    "certs": data["certs"],
                    "certbot": data["certbot"],
                    "error": "",
                }
            )
        except Exception as exc:  # noqa: BLE001 — never break the page
            result.append({"node_id": PANEL_NODE_ID, "node": "خود پنل (این سرور)",
                           "certs": [], "error": str(exc)[:300]})

    query = db.query(Node).filter(Node.is_enabled.is_(True))
    if node_id:
        query = query.filter(Node.id == node_id)
    for node in query.all():
        entry = {"node_id": node.id, "node": node.name, "certs": [], "error": ""}
        try:
            data = agent_for(node).cert_list()
            entry["certs"] = data.get("certs", [])
            entry["certbot"] = data.get("certbot", False)
        except (SSHError, NodeError) as exc:
            entry["error"] = str(exc)[:300]
        result.append(entry)
    return result


@router.get("/certificates/suggestions")
def domain_suggestions(db: Session = Depends(get_db),
                       _: Admin = Depends(require_manager)):
    """Every domain the panel already knows about, ready to be picked."""
    cfg = settings_store.load(db)
    items: list[dict] = []
    seen: set[str] = set()

    def add(domain: str, why: str, node_id: int = PANEL_NODE_ID):
        domain = (domain or "").strip().strip("/")
        if not domain or domain in seen or domain.replace(".", "").isdigit():
            return
        seen.add(domain)
        items.append({"domain": domain, "why": why, "node_id": node_id})

    public = (cfg.get("panel_public_url") or "").split("//")[-1].split("/")[0]
    add(cfg.get("sub_domain", ""), "دامنه لینک اشتراک")
    add(cfg.get("panel_domain", ""), "دامنه پنل")
    add(public.split(":")[0], "آدرس عمومی پنل")
    for node in db.query(Node).order_by(Node.sort_order, Node.id).all():
        add(node.public_address, f"آدرس عمومی نود {node.name}", node.id)
    for inbound in db.query(Inbound).all():
        if inbound.sni:
            add(inbound.sni, f"SNI اینباند {inbound.remark or inbound.tag}")
    return items


# --------------------------------------------------------------------------
# issuing
# --------------------------------------------------------------------------
def _apply_result(db: Session, payload, result: dict, node: Node | None) -> dict:
    if payload.apply_to_inbound_id:
        inbound = db.query(Inbound).get(payload.apply_to_inbound_id)
        if inbound is not None:
            inbound.cert_path = result["cert"]
            inbound.key_path = result["key"]
            if result.get("self_signed"):
                # a self-signed chain is not verifiable by the client
                inbound.allow_insecure = True
            if not inbound.sni:
                inbound.sni = result["domain"]
            db.add(inbound)
            db.commit()
            if node is not None:
                sync_service.sync_node(db, node)
            result["applied_to"] = inbound.tag

    if getattr(payload, "set_node_address", False) and node is not None:
        node.public_address = result["domain"]
        db.add(node)
        db.commit()
        result["node_address"] = result["domain"]

    if getattr(payload, "use_for_subscription", False):
        if not os.path.exists(result["cert"]):
            result["subscription"] = (
                "گواهی روی سرور پنل نیست؛ برای لینک اشتراک باید روی «خود پنل» صادر شود"
            )
        else:
            settings_store.save(
                db,
                {
                    "panel_cert": result["cert"],
                    "panel_key": result["key"],
                    "sub_domain": result["domain"],
                    "sub_https": True,
                },
            )
            result["subscription"] = (
                "لینک اشتراک روی HTTPS تنظیم شد — سرویس پنل را ری‌استارت کنید"
            )
    return result


@router.post("/certificates/issue")
def issue_certificate(payload: CertRequest, db: Session = Depends(get_db),
                      admin: Admin = Depends(require_manager)):
    if payload.method == "cloudflare" and not payload.cf_token:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "برای روش Cloudflare توکن API لازم است"
        )

    node = None
    if payload.node_id == PANEL_NODE_ID:
        result = local_certs.cert_issue(payload.model_dump())
        where = "پنل"
    else:
        node = _node_or_404(db, payload.node_id)
        where = node.name
        try:
            result = agent_for(node).cert_issue(payload.model_dump())
        except (SSHError, NodeError) as exc:
            raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc

    if not result.get("ok"):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, result.get("error", "صدور گواهی ناموفق بود")
        )

    result = _apply_result(db, payload, result, node)
    sync_service.log(db, "cert_issued", f"{payload.domain} on {where}",
                     admin.username, target=payload.domain)
    return result


@router.post("/certificates/self-signed")
def self_signed_certificate(payload: SelfSignedRequest, db: Session = Depends(get_db),
                            admin: Admin = Depends(require_manager)):
    """A certificate for TLS inbounds when there is no domain to validate."""
    domain = payload.domain.strip()
    if not domain and payload.apply_to_inbound_id:
        inbound = db.query(Inbound).get(payload.apply_to_inbound_id)
        domain = (inbound.sni if inbound else "") or ""

    node = None
    if payload.node_id == PANEL_NODE_ID:
        domain = domain or settings_store.load(db).get("sub_domain") or "panel.local"
        result = local_certs.cert_selfsigned({"domain": domain, "force": payload.force})
        where = "پنل"
    else:
        node = _node_or_404(db, payload.node_id)
        domain = domain or node.endpoint or "vpn.local"
        where = node.name
        try:
            result = agent_for(node).cert_selfsigned(
                {"domain": domain, "force": payload.force}
            )
        except (SSHError, NodeError) as exc:
            raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc

    if not result.get("ok"):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, result.get("error", "ساخت گواهی ناموفق بود")
        )
    result.setdefault("self_signed", True)
    result = _apply_result(db, payload, result, node)
    sync_service.log(db, "cert_self_signed", f"{domain} on {where}",
                     admin.username, target=domain)
    return result


# --------------------------------------------------------------------------
# panel settings
# --------------------------------------------------------------------------
@router.get("/panel-settings")
def get_panel_settings(db: Session = Depends(get_db), _: Admin = Depends(current_admin)):
    cfg = settings_store.load(db)
    return {
        **cfg,
        "sub_base_url": settings_store.sub_base_url(db),
        "page_base_url": settings_store.page_base_url(db),
    }


@router.put("/panel-settings")
def update_panel_settings(payload: PanelSettings, db: Session = Depends(get_db),
                          admin: Admin = Depends(require_sudo)):
    values = payload.model_dump(exclude_unset=True)
    settings_store.save(db, values)
    sync_service.log(db, "panel_settings", "domain/subscription settings updated",
                     admin.username)
    cfg = settings_store.load(db)
    return {
        **cfg,
        "sub_base_url": settings_store.sub_base_url(db),
        "page_base_url": settings_store.page_base_url(db),
        "note": "برای تغییر پورتِ شنیدنِ پنل، PORT را در فایل .env عوض کرده و سرویس را ری‌استارت کنید",
    }
