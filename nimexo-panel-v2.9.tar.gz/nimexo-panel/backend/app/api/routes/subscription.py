"""Public subscription endpoints — no authentication, keyed by sub_id."""
import base64
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from app.config import settings
from app.db import get_db
from app.models import Inbound, Node, NodeInbound, User, utcnow
from app.models.enums import CoreType, UserStatus
from app.services import links as link_service
from app.services import qr as qr_service
from app.services import settings_store
from app.services import sync as sync_service
from app.services.cores import ocserv as ocserv_core
from app.services.cores import openvpn as ovpn_core
from app.services.cores import ppp as ppp_core

router = APIRouter(tags=["subscription"])

BROWSER_HINTS = ("mozilla", "chrome", "safari", "edge", "opera")


def _get_user(db: Session, sub_id: str) -> User:
    user = db.query(User).filter(User.sub_id == sub_id).one_or_none()
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "subscription not found")
    return user


def _touch(db: Session, user: User, request: Request) -> None:
    user.sub_last_user_agent = request.headers.get("user-agent", "")[:250]
    user.sub_updated_at = utcnow()
    db.add(user)
    db.commit()


def _user_info_header(user: User) -> str:
    expire = int(user.expire_at.timestamp()) if user.expire_at else 0
    return (
        f"upload=0; download={user.used_traffic}; "
        f"total={user.data_limit}; expire={expire}"
    )


def _entitlements(db: Session, user: User) -> tuple[list[Node], list[Inbound]]:
    return sync_service.effective_nodes(db, user), sync_service.effective_inbounds(db, user)


def _openvpn_pki(db: Session, node: Node) -> tuple[str, str]:
    """CA + tls-auth for a node, fetched from the node itself if not cached.

    The install job caches them, but a node installed out of band (or one whose
    PKI was regenerated) would otherwise never hand out a working .ovpn.
    """
    cores = dict(node.installed_cores or {})
    ca, tls_auth = cores.get("openvpn_ca", ""), cores.get("openvpn_tls_auth", "")
    if ca:
        return ca, tls_auth

    from app.services.node_manager import NodeError, agent_for
    from app.services.ssh import SSHError

    try:
        pki = agent_for(node).ovpn_pki()
    except (NodeError, SSHError) as exc:
        raise HTTPException(
            status.HTTP_502_BAD_GATEWAY,
            f"could not read the OpenVPN certificates from {node.name}: {exc}",
        ) from exc

    ca, tls_auth = pki.get("ca", ""), pki.get("tls_auth", "")
    if ca:
        cores["openvpn_ca"] = ca
        cores["openvpn_tls_auth"] = tls_auth
        node.installed_cores = cores
        db.add(node)
        db.commit()
    return ca, tls_auth


@router.get("/sub/{sub_id}")
def subscription(sub_id: str, request: Request, db: Session = Depends(get_db)):
    """Serve v2ray-style base64 links, or bounce browsers to the user page."""
    user = _get_user(db, sub_id)
    _touch(db, user, request)

    agent = request.headers.get("user-agent", "").lower()
    accept = request.headers.get("accept", "")
    if "text/html" in accept and any(h in agent for h in BROWSER_HINTS):
        from fastapi.responses import RedirectResponse

        return RedirectResponse(url=f"/u/{sub_id}", status_code=302)

    nodes, inbounds = _entitlements(db, user)
    if user.status not in (UserStatus.ACTIVE, UserStatus.ON_HOLD):
        payload = ""
    else:
        payload = "\n".join(link_service.build_subscription_links(db, user, nodes, inbounds))

    cfg = settings_store.load(db)
    return Response(
        content=base64.b64encode(payload.encode()).decode(),
        media_type="text/plain; charset=utf-8",
        headers={
            "subscription-userinfo": _user_info_header(user),
            "profile-update-interval": str(settings.SUB_UPDATE_INTERVAL_HOURS),
            "profile-title": base64.b64encode(
                f"{cfg['sub_profile_title']} · {user.username}".encode()
            ).decode(),
            "profile-web-page-url": (
                f"{settings_store.page_base_url(db, request.headers.get('host', ''))}"
                f"/u/{sub_id}"
            ),
        },
    )


@router.get("/sub/{sub_id}/links", response_class=PlainTextResponse)
def raw_links(sub_id: str, db: Session = Depends(get_db)):
    user = _get_user(db, sub_id)
    nodes, inbounds = _entitlements(db, user)
    return "\n".join(link_service.build_subscription_links(db, user, nodes, inbounds))


def user_payload(db: Session, user: User, request_host: str = "") -> dict:
    """Everything the user-facing pages need (usage, days left, configs)."""
    sub_id = user.sub_id
    nodes, inbounds = _entitlements(db, user)
    now = utcnow()
    days_left = None
    if user.expire_at:
        days_left = max(0, (user.expire_at - now).days)

    available = []
    ni_map = {(ni.inbound_id, ni.node_id): ni for ni in db.query(NodeInbound).all()}
    for node in nodes:
        for inbound in inbounds:
            ni = ni_map.get((inbound.id, node.id))
            if ni is None or not ni.is_enabled:
                continue
            entry = {
                "inbound_id": inbound.id,
                "node_id": node.id,
                "node": node.name,
                "country": node.country,
                "core": inbound.core.value,
                "protocol": inbound.protocol.value,
                "remark": inbound.remark or inbound.tag,
            }
            if inbound.core == CoreType.XRAY:
                entry["link"] = link_service.build_share_link(user, inbound, node, ni, db)
                entry["qr"] = f"/sub/{sub_id}/qr/{inbound.id}/{node.id}"
            elif inbound.core == CoreType.WIREGUARD:
                entry["download"] = f"/sub/{sub_id}/wireguard/{inbound.id}/{node.id}"
                entry["qr"] = f"/sub/{sub_id}/qr/{inbound.id}/{node.id}"
            elif inbound.core == CoreType.OPENVPN:
                entry["download"] = f"/sub/{sub_id}/openvpn/{inbound.id}/{node.id}"
            elif inbound.core == CoreType.OCSERV:
                entry["credentials"] = ocserv_core.credentials(
                    inbound, node, user, ni.port_override, ni.address_override,
                    host=link_service.public_host(node, ni, db),
                )
            elif inbound.core in (CoreType.L2TP, CoreType.PPTP):
                entry["credentials"] = ppp_core.credentials(
                    inbound, node, user, ni.port_override, ni.address_override,
                    host=link_service.public_host(node, ni, db),
                )
            available.append(entry)

    return {
        "username": user.username,
        "status": user.status.value,
        "group": user.group.title or user.group.name if user.group else None,
        "data_limit": user.data_limit,
        "used_traffic": user.used_traffic,
        "remaining": max(0, user.data_limit - user.used_traffic) if user.data_limit else None,
        "expire_at": user.expire_at,
        "days_left": days_left,
        "device_limit": user.device_limit,
        "online": bool(user.online_at and now - user.online_at < timedelta(minutes=3)),
        "subscription_url": f"{settings_store.sub_base_url(db, request_host)}/{sub_id}",
        "subscription_qr": f"/sub/{sub_id}/qr",
        "configs": available,
        "brand": settings_store.load(db)["brand_name"],
    }


@router.get("/api/sub/{sub_id}/info")
def sub_info(sub_id: str, request: Request, db: Session = Depends(get_db)):
    return user_payload(db, _get_user(db, sub_id),
                        request.headers.get("host", ""))


@router.get("/sub/{sub_id}/qr")
def subscription_qr(sub_id: str, request: Request, db: Session = Depends(get_db)):
    """QR of the subscription link itself."""
    user = _get_user(db, sub_id)
    url = f"{settings_store.sub_base_url(db, request.headers.get('host', ''))}/{user.sub_id}"
    return Response(content=qr_service.png(url), media_type="image/png",
                    headers={"cache-control": "no-store"})


@router.get("/sub/{sub_id}/qr/{inbound_id}/{node_id}")
def config_qr(sub_id: str, inbound_id: int, node_id: int,
              db: Session = Depends(get_db)):
    """QR of one config: a share link, or the whole WireGuard file."""
    user = _get_user(db, sub_id)
    inbound = db.query(Inbound).get(inbound_id)
    node = db.query(Node).get(node_id)
    if inbound is None or node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "config not found")
    ni = (
        db.query(NodeInbound)
        .filter(NodeInbound.inbound_id == inbound_id, NodeInbound.node_id == node_id)
        .one_or_none()
    )

    if inbound.core == CoreType.XRAY:
        payload = link_service.build_share_link(user, inbound, node, ni)
    elif inbound.core == CoreType.WIREGUARD:
        payload = link_service.build_wireguard_config(db, user, inbound, node, ni)
        db.commit()
    else:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "این پروتکل با نام کاربری و گذرواژه وصل می‌شود و QR ندارد",
        )

    if not payload:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "config not found")
    if qr_service.too_large(payload):
        raise HTTPException(
            status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            "این کانفیگ برای QR بیش از حد بزرگ است — فایل را دانلود کنید",
        )
    return Response(content=qr_service.png(payload), media_type="image/png",
                    headers={"cache-control": "no-store"})


@router.get("/sub/{sub_id}/wireguard/{inbound_id}/{node_id}",
            response_class=PlainTextResponse)
def wireguard_config(sub_id: str, inbound_id: int, node_id: int,
                     db: Session = Depends(get_db)):
    user = _get_user(db, sub_id)
    inbound = db.query(Inbound).get(inbound_id)
    node = db.query(Node).get(node_id)
    if inbound is None or node is None or inbound.core != CoreType.WIREGUARD:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "config not found")
    ni = (
        db.query(NodeInbound)
        .filter(NodeInbound.inbound_id == inbound_id, NodeInbound.node_id == node_id)
        .one_or_none()
    )
    config = link_service.build_wireguard_config(db, user, inbound, node, ni)
    db.commit()
    filename = f"{user.username}-{node.name}.conf"
    return PlainTextResponse(
        config, headers={"content-disposition": f'attachment; filename="{filename}"'}
    )


@router.get("/sub/{sub_id}/openvpn/{inbound_id}/{node_id}",
            response_class=PlainTextResponse)
def openvpn_config(sub_id: str, inbound_id: int, node_id: int,
                   db: Session = Depends(get_db)):
    user = _get_user(db, sub_id)
    inbound = db.query(Inbound).get(inbound_id)
    node = db.query(Node).get(node_id)
    if inbound is None or node is None or inbound.core != CoreType.OPENVPN:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "config not found")
    ca, tls_auth = _openvpn_pki(db, node)
    if not ca:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "the OpenVPN core on this node has not finished installing yet",
        )
    ni = (
        db.query(NodeInbound)
        .filter(NodeInbound.inbound_id == inbound_id, NodeInbound.node_id == node_id)
        .one_or_none()
    )
    config = ovpn_core.build_client_config(
        inbound, node, user, ca, tls_auth,
        ni.port_override if ni else None,
        link_service.public_host(node, ni, db),
    )
    filename = f"{user.username}-{node.name}.ovpn"
    return PlainTextResponse(
        config, headers={"content-disposition": f'attachment; filename="{filename}"'}
    )
