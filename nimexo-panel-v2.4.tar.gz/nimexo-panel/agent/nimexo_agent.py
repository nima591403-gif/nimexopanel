#!/usr/bin/env python3
"""NimexoPanel node agent.

A dependency-free helper that the panel uploads to every node
(/opt/nimexo/agent.py) and invokes over SSH:

    python3 /opt/nimexo/agent.py <command> [args]     # JSON payload on stdin
    -> a single JSON object on stdout

It never listens on a port; the panel is always the initiator.

Commands
--------
ping                      agent + core versions
sysinfo                   cpu / mem / disk / uptime / net counters
install <core>            install or update xray | wireguard | openvpn
apply-xray                write config.json (stdin) and reload the core
xray-stats [--reset]      per-user up/down counters from the Xray stats API
apply-wireguard           write interfaces + peers (stdin) and sync them
wg-stats                  per-peer transfer counters
apply-openvpn             write the account list (stdin)
ovpn-stats                per-CN transfer counters and live sessions
restart <core>            restart a managed service
logs <core> [n]           last n journal lines
uninstall <core>          stop and remove a managed core
"""
from __future__ import annotations

import base64
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request

AGENT_VERSION = "2.2.0"
BASE_DIR = "/opt/nimexo"
XRAY_DIR = f"{BASE_DIR}/xray"
WG_DIR = "/etc/wireguard"
OVPN_DIR = f"{BASE_DIR}/openvpn"
OCSERV_DIR = f"{BASE_DIR}/ocserv"
PPP_DIR = f"{BASE_DIR}/ppp"
STATE_DIR = f"{BASE_DIR}/state"

XRAY_BIN = "/usr/local/bin/nimexo-xray"
XRAY_SERVICE = "nimexo-xray"
XRAY_API = "127.0.0.1:10085"
XRAY_RELEASE = (
    "https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip"
)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def run(cmd, input_data=None, timeout=300, check=False):
    proc = subprocess.run(
        cmd,
        shell=isinstance(cmd, str),
        input=input_data.encode() if isinstance(input_data, str) else input_data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    out = proc.stdout.decode("utf-8", "replace")
    err = proc.stderr.decode("utf-8", "replace")
    if check and proc.returncode != 0:
        raise RuntimeError(f"{cmd} -> {proc.returncode}: {err.strip() or out.strip()}")
    return proc.returncode, out, err


def which(binary):
    return shutil.which(binary) or ""


def ensure_dirs():
    for d in (BASE_DIR, XRAY_DIR, OVPN_DIR, OCSERV_DIR, PPP_DIR, STATE_DIR,
              f"{PPP_DIR}/sessions", f"{PPP_DIR}/totals"):
        os.makedirs(d, exist_ok=True)
    os.chmod(BASE_DIR, 0o750)


def crypt_password(password):
    """SHA-512 crypt hash, the format ocserv's plain auth expects."""
    code, out, err = run(f"openssl passwd -6 {shell_quote(password)}")
    if code != 0 or not out.strip():
        raise RuntimeError(f"openssl passwd failed: {err.strip()[:200]}")
    return out.strip()


def shell_quote(value):
    return "'" + str(value).replace("'", "'\\''") + "'"


def netmask_to_prefix(mask):
    return sum(bin(int(part)).count("1") for part in mask.split("."))


def write_file(path, content, mode=0o600):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as fh:
        fh.write(content)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def read_stdin_json():
    data = sys.stdin.read()
    return json.loads(data) if data.strip() else {}


def systemd_write(name, unit_text):
    write_file(f"/etc/systemd/system/{name}.service", unit_text, 0o644)
    run("systemctl daemon-reload")


def service_active(name):
    code, out, _ = run(f"systemctl is-active {name}")
    return out.strip() == "active"


def apt_install(packages):
    env = "DEBIAN_FRONTEND=noninteractive"
    install = f"{env} apt-get install -y --no-install-recommends {' '.join(packages)}"

    run(f"{env} apt-get update -y", timeout=600)
    code, out, err = run(install, timeout=900)

    if code != 0 and "Unable to locate package" in (out + err):
        # pptpd and a few others live in Ubuntu's "universe" component, which
        # minimal cloud images ship with disabled.
        run(f"{env} apt-get install -y software-properties-common", timeout=600)
        code2, _, _ = run("add-apt-repository -y universe", timeout=300)
        if code2 != 0:
            # no add-apt-repository (Debian): append the component by hand
            run(
                "sed -i -E 's/^(deb .*ubuntu.com\\/ubuntu\\/? [a-z-]+ .*main)$/\\1 universe/' "
                "/etc/apt/sources.list"
            )
        run(f"{env} apt-get update -y", timeout=600)
        code, out, err = run(install, timeout=900)

    if code != 0:
        raise RuntimeError(f"apt install failed: {(err or out).strip()[:500]}")


def default_iface():
    code, out, _ = run("ip route show default")
    m = re.search(r"dev\s+(\S+)", out)
    return m.group(1) if m else "eth0"


def enable_forwarding():
    write_file("/etc/sysctl.d/99-nimexo.conf",
               "net.ipv4.ip_forward=1\nnet.ipv6.conf.all.forwarding=1\n", 0o644)
    run("sysctl --system")


def ensure_nat(subnet, iface=None):
    iface = iface or default_iface()
    code, _, _ = run(
        f"iptables -t nat -C POSTROUTING -s {subnet} -o {iface} -j MASQUERADE"
    )
    if code != 0:
        run(f"iptables -t nat -A POSTROUTING -s {subnet} -o {iface} -j MASQUERADE")
    for rule in (
        f"-s {subnet} -j ACCEPT",
        f"-d {subnet} -m state --state RELATED,ESTABLISHED -j ACCEPT",
    ):
        code, _, _ = run(f"iptables -C FORWARD {rule}")
        if code != 0:
            run(f"iptables -I FORWARD 1 {rule}")


# --------------------------------------------------------------------------
# sysinfo
# --------------------------------------------------------------------------
def cpu_percent(interval=0.4):
    def snapshot():
        with open("/proc/stat") as fh:
            parts = [float(x) for x in fh.readline().split()[1:]]
        idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
        return sum(parts), idle

    t1, i1 = snapshot()
    time.sleep(interval)
    t2, i2 = snapshot()
    dt, di = t2 - t1, i2 - i1
    return round(100.0 * (dt - di) / dt, 1) if dt > 0 else 0.0


def mem_info():
    info = {}
    with open("/proc/meminfo") as fh:
        for line in fh:
            k, v = line.split(":", 1)
            info[k] = int(v.strip().split()[0]) * 1024
    total = info.get("MemTotal", 0)
    available = info.get("MemAvailable", 0)
    used = total - available
    return {
        "total": total,
        "used": used,
        "percent": round(100.0 * used / total, 1) if total else 0.0,
    }


def net_counters():
    tx = rx = 0
    with open("/proc/net/dev") as fh:
        for line in fh.readlines()[2:]:
            name, _, rest = line.partition(":")
            name = name.strip()
            if name == "lo" or name.startswith(("veth", "docker", "br-")):
                continue
            fields = rest.split()
            rx += int(fields[0])
            tx += int(fields[8])
    return {"rx": rx, "tx": tx}


def cmd_sysinfo():
    st = os.statvfs("/")
    disk_total = st.f_blocks * st.f_frsize
    disk_free = st.f_bavail * st.f_frsize
    with open("/proc/uptime") as fh:
        uptime = float(fh.readline().split()[0])

    prev_path = f"{STATE_DIR}/net.json"
    now = time.time()
    counters = net_counters()
    speed = {"tx": 0.0, "rx": 0.0}
    try:
        with open(prev_path) as fh:
            prev = json.load(fh)
        dt = now - prev["ts"]
        if 0 < dt < 3600:
            speed = {
                "tx": max(0.0, (counters["tx"] - prev["tx"]) / dt),
                "rx": max(0.0, (counters["rx"] - prev["rx"]) / dt),
            }
    except Exception:
        pass
    try:
        ensure_dirs()
        write_file(prev_path, json.dumps({"ts": now, **counters}), 0o644)
    except Exception:
        pass

    return {
        "agent_version": AGENT_VERSION,
        "cpu_percent": cpu_percent(),
        "memory": mem_info(),
        "disk": {
            "total": disk_total,
            "used": disk_total - disk_free,
            "percent": round(100.0 * (disk_total - disk_free) / disk_total, 1)
            if disk_total
            else 0.0,
        },
        "uptime": int(uptime),
        "net": counters,
        "net_speed": speed,
        "load": os.getloadavg(),
        "cores": installed_cores(),
        "services": {
            XRAY_SERVICE: service_active(XRAY_SERVICE),
            "wg-quick@": bool(which("wg")),
            "openvpn-server@nimexo": service_active("openvpn-server@nimexo"),
        },
    }


def installed_cores():
    cores = {}
    if os.path.exists(XRAY_BIN):
        _, out, _ = run(f"{XRAY_BIN} version")
        m = re.search(r"Xray\s+([\d.]+)", out)
        cores["xray"] = m.group(1) if m else "unknown"
    if which("wg"):
        _, out, _ = run("wg --version")
        m = re.search(r"v([\d.]+)", out)
        cores["wireguard"] = m.group(1) if m else "installed"
    if which("openvpn"):
        _, out, _ = run("openvpn --version")
        m = re.search(r"OpenVPN\s+([\d.]+)", out)
        cores["openvpn"] = m.group(1) if m else "installed"
    if which("ocserv"):
        _, out, _ = run("ocserv -v")
        m = re.search(r"ocserv\s+([\d.]+)", out)
        cores["ocserv"] = m.group(1) if m else "installed"
    if which("xl2tpd"):
        cores["l2tp"] = "installed"
    if which("pptpd"):
        cores["pptp"] = "installed"
    return cores


# --------------------------------------------------------------------------
# xray
# --------------------------------------------------------------------------
def install_xray():
    ensure_dirs()
    if not which("unzip"):
        apt_install(["unzip", "ca-certificates", "curl"])
    tmp_zip = "/tmp/nimexo-xray.zip"
    urllib.request.urlretrieve(XRAY_RELEASE, tmp_zip)  # noqa: S310
    run(f"rm -rf /tmp/nimexo-xray && mkdir -p /tmp/nimexo-xray")
    run(f"unzip -o {tmp_zip} -d /tmp/nimexo-xray", check=True)
    shutil.copy("/tmp/nimexo-xray/xray", XRAY_BIN)
    os.chmod(XRAY_BIN, 0o755)
    for asset in ("geoip.dat", "geosite.dat"):
        src = f"/tmp/nimexo-xray/{asset}"
        if os.path.exists(src):
            shutil.copy(src, f"{XRAY_DIR}/{asset}")

    if not os.path.exists(f"{XRAY_DIR}/config.json"):
        write_file(f"{XRAY_DIR}/config.json", json.dumps(
            {"log": {"loglevel": "warning"}, "inbounds": [], "outbounds": [
                {"protocol": "freedom", "tag": "direct"}]}, indent=2))

    systemd_write(XRAY_SERVICE, f"""[Unit]
Description=NimexoPanel Xray core
After=network.target nss-lookup.target

[Service]
Type=simple
User=root
Environment=XRAY_LOCATION_ASSET={XRAY_DIR}
ExecStart={XRAY_BIN} run -config {XRAY_DIR}/config.json
Restart=on-failure
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
""")
    run(f"systemctl enable --now {XRAY_SERVICE}")
    enable_forwarding()
    return {"installed": "xray", "version": installed_cores().get("xray", "")}


def cmd_apply_xray():
    payload = read_stdin_json()
    config = payload.get("config") or payload
    ensure_dirs()
    text = json.dumps(config, indent=2, ensure_ascii=False)
    candidate = f"{XRAY_DIR}/config.new.json"
    write_file(candidate, text)
    # The systemd unit sets XRAY_LOCATION_ASSET; the test run must use the
    # same asset directory or geo lookups resolve against /usr/local/bin.
    code, out, err = run(
        f"XRAY_LOCATION_ASSET={XRAY_DIR} {XRAY_BIN} run -test -config {candidate}"
    )
    if code != 0:
        return {"ok": False, "error": (err or out).strip()[:2000]}
    os.replace(candidate, f"{XRAY_DIR}/config.json")
    code, out, err = run(f"systemctl restart {XRAY_SERVICE}")
    time.sleep(1.0)
    active = service_active(XRAY_SERVICE)
    return {
        "ok": active,
        "error": "" if active else (err or out).strip()[:2000],
        "inbounds": len(config.get("inbounds", [])),
    }


def cmd_xray_stats(reset=True):
    if not os.path.exists(XRAY_BIN):
        return {"users": {}, "inbounds": {}}
    flag = "-reset" if reset else ""
    code, out, err = run(
        f'{XRAY_BIN} api statsquery --server={XRAY_API} {flag} -pattern ""'
    )
    if code != 0:
        return {"users": {}, "inbounds": {}, "error": (err or out).strip()[:500]}
    try:
        stats = json.loads(out).get("stat", []) or []
    except json.JSONDecodeError:
        return {"users": {}, "inbounds": {}, "error": "unparsable stats output"}

    users, inbounds = {}, {}
    for item in stats:
        name = item.get("name", "")
        value = int(item.get("value", 0) or 0)
        if not value:
            continue
        parts = name.split(">>>")
        if len(parts) != 4:
            continue
        kind, ident, _, direction = parts
        bucket = users if kind == "user" else inbounds
        entry = bucket.setdefault(ident, {"up": 0, "down": 0})
        if direction in ("uplink", "downlink"):
            entry["up" if direction == "uplink" else "down"] += value
    return {"users": users, "inbounds": inbounds}


# --------------------------------------------------------------------------
# wireguard
# --------------------------------------------------------------------------
def install_wireguard():
    if not which("wg"):
        apt_install(["wireguard", "wireguard-tools", "iptables"])
    enable_forwarding()
    return {"installed": "wireguard", "version": installed_cores().get("wireguard", "")}


def cmd_apply_wireguard():
    """payload = {"interfaces": [{name, private_key, port, address, mtu,
                                  subnet, peers:[{public_key, allowed_ips,
                                  preshared_key}]}]}"""
    payload = read_stdin_json()
    results = []
    wanted = set()
    os.makedirs(WG_DIR, exist_ok=True)
    for iface in payload.get("interfaces", []):
        name = iface["name"]
        wanted.add(name)
        lines = [
            "[Interface]",
            f"PrivateKey = {iface['private_key']}",
            f"Address = {iface['address']}",
            f"ListenPort = {iface['port']}",
        ]
        if iface.get("mtu"):
            lines.append(f"MTU = {iface['mtu']}")
        lines.append("SaveConfig = false")
        for peer in iface.get("peers", []):
            lines += [
                "",
                "[Peer]",
                f"# {peer.get('name', '')}",
                f"PublicKey = {peer['public_key']}",
                f"AllowedIPs = {peer['allowed_ips']}",
            ]
            if peer.get("preshared_key"):
                lines.append(f"PresharedKey = {peer['preshared_key']}")
        write_file(f"{WG_DIR}/{name}.conf", "\n".join(lines) + "\n", 0o600)

        if iface.get("subnet"):
            ensure_nat(iface["subnet"])

        if service_active(f"wg-quick@{name}"):
            # hot-reload peers without dropping existing sessions
            code, out, err = run(
                f"bash -c 'wg syncconf {name} <(wg-quick strip {name})'"
            )
            if code != 0:
                run(f"systemctl restart wg-quick@{name}")
        else:
            run(f"systemctl enable --now wg-quick@{name}")
        results.append({"name": name, "active": service_active(f"wg-quick@{name}")})

    # tear down interfaces the panel no longer knows about
    for fname in os.listdir(WG_DIR):
        if not fname.endswith(".conf"):
            continue
        name = fname[:-5]
        if name.startswith("nx-") and name not in wanted:
            run(f"systemctl disable --now wg-quick@{name}")
            os.remove(f"{WG_DIR}/{fname}")
    return {"ok": True, "interfaces": results}


def cmd_wg_stats():
    if not which("wg"):
        return {"peers": {}}
    code, out, _ = run("wg show all dump")
    peers = {}
    if code != 0:
        return {"peers": {}}
    for line in out.splitlines():
        cols = line.split("\t")
        if len(cols) < 9:
            continue  # interface line
        iface, public_key = cols[0], cols[1]
        endpoint, handshake = cols[3], cols[4]
        rx, tx = int(cols[5] or 0), int(cols[6] or 0)
        peers[public_key] = {
            "interface": iface,
            "endpoint": endpoint if endpoint != "(none)" else "",
            "last_handshake": int(handshake or 0),
            "down": rx,
            "up": tx,
        }
    return {"peers": peers}


# --------------------------------------------------------------------------
# openvpn
# --------------------------------------------------------------------------
AUTH_SCRIPT = r"""#!/bin/bash
# NimexoPanel OpenVPN credential check (via-file)
creds="$1"
user=$(head -n 1 "$creds")
pass=$(tail -n 1 "$creds")
db=/opt/nimexo/openvpn/users
[ -f "$db" ] || exit 1
line=$(grep -m1 -F -- "${user}:" "$db") || exit 1
expected="${line#*:}"
[ -n "$expected" ] && [ "$pass" = "$expected" ] && exit 0
exit 1
"""


def install_openvpn(payload=None):
    payload = payload or {}
    if not which("openvpn"):
        apt_install(["openvpn", "easy-rsa", "openssl", "iptables"])
    ensure_dirs()
    pki = f"{OVPN_DIR}/pki"
    os.makedirs(pki, exist_ok=True)

    if not os.path.exists(f"{pki}/ca.crt"):
        run(f"openssl genrsa -out {pki}/ca.key 2048", check=True)
        run(
            f"openssl req -x509 -new -nodes -key {pki}/ca.key -sha256 -days 3650 "
            f"-subj '/CN=Nimexo-CA' -out {pki}/ca.crt",
            check=True,
        )
        run(f"openssl genrsa -out {pki}/server.key 2048", check=True)
        run(
            f"openssl req -new -key {pki}/server.key -subj '/CN=nimexo-server' "
            f"-out {pki}/server.csr",
            check=True,
        )
        run(
            f"openssl x509 -req -in {pki}/server.csr -CA {pki}/ca.crt "
            f"-CAkey {pki}/ca.key -CAcreateserial -days 3650 -sha256 "
            f"-out {pki}/server.crt",
            check=True,
        )
        run(f"openssl dhparam -out {pki}/dh.pem 2048", timeout=1800, check=True)
        run(f"openvpn --genkey secret {pki}/ta.key", check=True)

    write_file(f"{OVPN_DIR}/auth.sh", AUTH_SCRIPT, 0o750)
    if not os.path.exists(f"{OVPN_DIR}/users"):
        write_file(f"{OVPN_DIR}/users", "", 0o600)

    port = int(payload.get("port") or 1194)
    proto = payload.get("proto") or "udp"
    subnet = payload.get("subnet") or "10.20.0.0"
    mask = payload.get("mask") or "255.255.255.0"
    mtu = int(payload.get("mtu") or 1280)
    cipher = payload.get("cipher") or "AES-128-GCM"
    dns = payload.get("dns") or ["1.1.1.1", "8.8.8.8"]

    conf = f"""# managed by NimexoPanel
port {port}
proto {proto}
dev tun
ca {pki}/ca.crt
cert {pki}/server.crt
key {pki}/server.key
dh {pki}/dh.pem
tls-auth {pki}/ta.key 0
topology subnet
server {subnet} {mask}
ifconfig-pool-persist {OVPN_DIR}/ipp.txt
push "redirect-gateway def1 bypass-dhcp"
{chr(10).join(f'push "dhcp-option DNS {d}"' for d in dns)}
keepalive 10 120
data-ciphers {cipher}:AES-256-GCM:CHACHA20-POLY1305
data-ciphers-fallback {cipher}
auth SHA256
tun-mtu {mtu}
mssfix {max(mtu - 40, 1000)}
persist-key
persist-tun
float
# No key renegotiation: with username/password auth the client would be asked
# for credentials again mid-session, which shows up as a random disconnect.
reneg-sec 0
verify-client-cert none
username-as-common-name
script-security 2
auth-user-pass-verify {OVPN_DIR}/auth.sh via-file
duplicate-cn
status {OVPN_DIR}/status.log 10
status-version 3
log-append /var/log/nimexo-openvpn.log
verb 3
"""
    # Only restart when the rendered config actually changed, otherwise every
    # routine sync would drop all connected users.
    conf_path = "/etc/openvpn/server/nimexo.conf"
    previous = ""
    if os.path.exists(conf_path):
        with open(conf_path) as fh:
            previous = fh.read()
    changed = previous != conf
    if changed:
        write_file(conf_path, conf, 0o644)

    enable_forwarding()
    ensure_nat(f"{subnet}/{sum(bin(int(x)).count('1') for x in mask.split('.'))}")
    run("systemctl enable openvpn-server@nimexo")
    if changed or not service_active("openvpn-server@nimexo"):
        run("systemctl restart openvpn-server@nimexo")
        time.sleep(1.0)
    with open(f"{pki}/ca.crt") as fh:
        ca = fh.read()
    with open(f"{pki}/ta.key") as fh:
        ta = fh.read()
    return {
        "installed": "openvpn",
        "active": service_active("openvpn-server@nimexo"),
        "restarted": changed,
        "ca": ca,
        "tls_auth": ta,
        "port": port,
        "proto": proto,
    }


def cmd_apply_openvpn():
    """payload = {"users": [{"username": "...", "password": "..."}],
                  "server": {...optional server params to re-render...}}"""
    payload = read_stdin_json()
    ensure_dirs()
    lines = [
        f"{u['username']}:{u['password']}"
        for u in payload.get("users", [])
        if u.get("username")
    ]
    write_file(f"{OVPN_DIR}/users", "\n".join(lines) + "\n", 0o600)

    disconnected = []
    for username in payload.get("revoke", []):
        code, _, _ = run(
            "bash -c "
            "\"echo 'kill %s' | nc -q1 -U /run/nimexo-ovpn.sock\"" % username
        )
        if code == 0:
            disconnected.append(username)

    result = {"ok": True, "users": len(lines), "revoked": disconnected}
    if payload.get("server"):
        result.update(install_openvpn(payload["server"]))
    return result


def cmd_ovpn_pki():
    """Return the material a client config needs (CA + tls-auth key)."""
    pki = f"{OVPN_DIR}/pki"
    result = {"ca": "", "tls_auth": "", "present": False}
    ca_path, ta_path = f"{pki}/ca.crt", f"{pki}/ta.key"
    if os.path.exists(ca_path):
        with open(ca_path) as fh:
            result["ca"] = fh.read()
        result["present"] = True
    if os.path.exists(ta_path):
        with open(ta_path) as fh:
            result["tls_auth"] = fh.read()
    if not result["present"]:
        result["error"] = f"{ca_path} not found — OpenVPN is not installed yet"
    return result


def cmd_ovpn_stats():
    path = f"{OVPN_DIR}/status.log"
    if not os.path.exists(path):
        return {"clients": {}}
    clients = {}
    with open(path) as fh:
        for line in fh:
            cols = line.strip().split(",")
            if not cols or cols[0] != "CLIENT_LIST":
                continue
            # CLIENT_LIST,CN,RealAddr,VirtAddr,VirtIPv6,BytesRx,BytesTx,...
            try:
                cn = cols[1]
                entry = clients.setdefault(cn, {"up": 0, "down": 0, "sessions": []})
                entry["down"] += int(cols[5] or 0)
                entry["up"] += int(cols[6] or 0)
                entry["sessions"].append(
                    {"ip": cols[2].split(":")[0], "since": cols[7] if len(cols) > 7 else ""}
                )
            except (IndexError, ValueError):
                continue
    return {"clients": clients}


# --------------------------------------------------------------------------
# ocserv (OpenConnect / Cisco AnyConnect)
# --------------------------------------------------------------------------
OCSERV_DEFAULTS = {
    "port": 8443,
    "subnet": "10.30.0.0",
    "mask": "255.255.255.0",
    "mtu": 1280,
    "dns": ["1.1.1.1", "8.8.8.8"],
    "max_same": 0,
    "udp": True,
}


def ocserv_certs():
    """Self-signed CA + server certificate, generated once."""
    ca_crt, ca_key = f"{OCSERV_DIR}/ca.crt", f"{OCSERV_DIR}/ca.key"
    crt, key = f"{OCSERV_DIR}/server.crt", f"{OCSERV_DIR}/server.key"
    if os.path.exists(crt):
        return crt, key, ca_crt
    run(f"openssl genrsa -out {ca_key} 2048", check=True)
    run(
        f"openssl req -x509 -new -nodes -key {ca_key} -sha256 -days 3650 "
        f"-subj '/CN=Nimexo-OC-CA' -out {ca_crt}",
        check=True,
    )
    run(f"openssl genrsa -out {key} 2048", check=True)
    run(
        f"openssl req -new -key {key} -subj '/CN=nimexo-vpn' "
        f"-out {OCSERV_DIR}/server.csr",
        check=True,
    )
    run(
        f"openssl x509 -req -in {OCSERV_DIR}/server.csr -CA {ca_crt} -CAkey {ca_key} "
        f"-CAcreateserial -days 3650 -sha256 -out {crt}",
        check=True,
    )
    for path in (ca_key, key):
        os.chmod(path, 0o600)
    return crt, key, ca_crt


def install_ocserv(payload=None):
    payload = payload or {}
    ensure_dirs()
    if not which("ocserv"):
        apt_install(["ocserv", "gnutls-bin", "openssl", "iptables"])

    opts = dict(OCSERV_DEFAULTS)
    opts.update({k: v for k, v in payload.items() if v not in (None, "")})
    crt, key, ca = ocserv_certs()

    passwd_file = f"{OCSERV_DIR}/passwd"
    if not os.path.exists(passwd_file):
        write_file(passwd_file, "", 0o600)

    dns_lines = "\n".join(f"dns = {d}" for d in opts["dns"])
    udp_line = f"udp-port = {opts['port']}" if opts.get("udp", True) else ""
    conf = f"""# managed by NimexoPanel
auth = "plain[passwd={passwd_file}]"
tcp-port = {opts['port']}
{udp_line}
run-as-user = nobody
run-as-group = daemon
socket-file = /run/ocserv-socket
use-occtl = true
pid-file = /run/ocserv.pid
server-cert = {crt}
server-key = {key}
ca-cert = {ca}
isolate-workers = false
max-clients = 0
max-same-clients = {opts['max_same']}
keepalive = 32400
dpd = 90
mobile-dpd = 1800
switch-to-tcp-timeout = 25
try-mtu-discovery = true
cert-user-oid = 2.5.4.3
tls-priorities = "NORMAL:%SERVER_PRECEDENCE:%COMPAT:-VERS-SSL3.0"
auth-timeout = 240
min-reauth-time = 300
max-ban-score = 80
ban-reset-time = 300
cookie-timeout = 300
deny-roaming = false
rekey-time = 172800
rekey-method = ssl
device = vpns
predictable-ips = true
default-domain = nimexo.vpn
ipv4-network = {opts['subnet']}
ipv4-netmask = {opts['mask']}
tunnel-all-dns = true
{dns_lines}
ping-leases = false
mtu = {opts['mtu']}
cisco-client-compat = true
dtls-legacy = true
compression = false
"""
    conf_path = "/etc/ocserv/ocserv.conf"
    previous = ""
    if os.path.exists(conf_path):
        with open(conf_path) as fh:
            previous = fh.read()
    changed = previous != conf
    if changed:
        write_file(conf_path, conf, 0o600)

    enable_forwarding()
    ensure_nat(f"{opts['subnet']}/{netmask_to_prefix(opts['mask'])}")
    run("systemctl enable ocserv")
    if changed or not service_active("ocserv"):
        run("systemctl restart ocserv")
        time.sleep(1.0)
    return {
        "installed": "ocserv",
        "active": service_active("ocserv"),
        "restarted": changed,
        "port": opts["port"],
    }


def cmd_apply_ocserv():
    """payload = {"users": [{username, password}], "server": {...}}"""
    payload = read_stdin_json()
    ensure_dirs()
    lines = []
    for user in payload.get("users", []):
        if not user.get("username") or not user.get("password"):
            continue
        lines.append(f"{user['username']}:*:{crypt_password(user['password'])}")
    write_file(f"{OCSERV_DIR}/passwd", "\n".join(lines) + "\n", 0o600)

    result = {"ok": True, "users": len(lines)}
    if payload.get("server"):
        result.update(install_ocserv(payload["server"]))
    elif service_active("ocserv"):
        # plain auth re-reads the file per connection; nothing to reload
        pass
    for username in payload.get("revoke", []):
        run(f"occtl disconnect user {shell_quote(username)}")
    return result


def cmd_ocserv_stats():
    if not which("occtl"):
        return {"users": {}}
    code, out, _ = run("occtl --json show users")
    if code != 0 or not out.strip():
        return {"users": {}}
    try:
        rows = json.loads(out)
    except json.JSONDecodeError:
        return {"users": {}}
    users = {}
    for row in rows if isinstance(rows, list) else []:
        name = row.get("Username") or row.get("username") or ""
        if not name:
            continue
        entry = users.setdefault(name, {"up": 0, "down": 0, "ip": ""})
        entry["up"] += int(row.get("RX", row.get("rx", 0)) or 0)
        entry["down"] += int(row.get("TX", row.get("tx", 0)) or 0)
        entry["ip"] = row.get("Remote IP") or row.get("remote_ip") or entry["ip"]
    return {"users": users}


# --------------------------------------------------------------------------
# ppp based cores: L2TP/IPsec and PPTP
# --------------------------------------------------------------------------
L2TP_DEFAULTS = {
    "port": 1701,
    "local_ip": "10.40.0.1",
    "range": "10.40.0.10-10.40.0.250",
    "subnet": "10.40.0.0/24",
    "mtu": 1280,
    "psk": "nimexo",
    "dns": ["1.1.1.1", "8.8.8.8"],
}

PPTP_DEFAULTS = {
    "local_ip": "10.50.0.1",
    "range": "10.50.0.10-10.50.0.250",
    "subnet": "10.50.0.0/24",
    "mtu": 1280,
    "dns": ["1.1.1.1", "8.8.8.8"],
}

IP_UP_HOOK = """#!/bin/bash
# NimexoPanel: remember which interface belongs to which account
mkdir -p /opt/nimexo/ppp/sessions
printf '%s' "$PEERNAME" > "/opt/nimexo/ppp/sessions/$IFNAME"
exit 0
"""

IP_DOWN_HOOK = """#!/bin/bash
# NimexoPanel: fold the closed session's counters into the account total
set -e
sess="/opt/nimexo/ppp/sessions/$IFNAME"
[ -f "$sess" ] || exit 0
user=$(cat "$sess")
mkdir -p /opt/nimexo/ppp/totals
rx=$(cat "/sys/class/net/$IFNAME/statistics/rx_bytes" 2>/dev/null || echo 0)
tx=$(cat "/sys/class/net/$IFNAME/statistics/tx_bytes" 2>/dev/null || echo 0)
total="/opt/nimexo/ppp/totals/$user"
prev_rx=0; prev_tx=0
if [ -f "$total" ]; then read -r prev_rx prev_tx < "$total"; fi
echo "$((prev_rx + rx)) $((prev_tx + tx))" > "$total"
rm -f "$sess"
exit 0
"""


def install_ppp_hooks():
    for directory, script in (("ip-up.d", IP_UP_HOOK), ("ip-down.d", IP_DOWN_HOOK)):
        path = f"/etc/ppp/{directory}/nimexo"
        os.makedirs(f"/etc/ppp/{directory}", exist_ok=True)
        write_file(path, script, 0o755)


def write_ppp_options(name, opts, mppe=False):
    dns_lines = "\n".join(f"ms-dns {d}" for d in opts["dns"])
    extra = (
        "require-mppe-128\nrefuse-pap\nrefuse-eap\nrefuse-chap\nrefuse-mschap\n"
        if mppe
        else "refuse-pap\nrefuse-eap\n"
    )
    return f"""# managed by NimexoPanel
name nimexo
{dns_lines}
require-mschap-v2
{extra}auth
mtu {opts['mtu']}
mru {opts['mtu']}
nodefaultroute
lock
proxyarp
silent
novj
novjccomp
nopcomp
noaccomp
lcp-echo-interval 30
lcp-echo-failure 4
connect-delay 5000
"""


def install_l2tp(payload=None):
    payload = payload or {}
    ensure_dirs()
    if not which("xl2tpd") or not which("ipsec"):
        apt_install(["strongswan", "xl2tpd", "ppp", "iptables"])
    install_ppp_hooks()

    opts = dict(L2TP_DEFAULTS)
    opts.update({k: v for k, v in payload.items() if v not in (None, "")})

    ipsec_conf = """# managed by NimexoPanel
config setup
    uniqueids=no
    charondebug="ike 1, knl 1, cfg 0"

conn L2TP-PSK
    keyexchange=ikev1
    authby=secret
    auto=add
    type=transport
    rekey=no
    forceencaps=yes
    dpdaction=clear
    dpddelay=30s
    left=%defaultroute
    leftprotoport=17/1701
    right=%any
    rightprotoport=17/%any
    ike=aes256-sha1-modp1024,aes128-sha1-modp1024,3des-sha1-modp1024!
    esp=aes256-sha1,aes128-sha1,3des-sha1!
"""
    write_file("/etc/ipsec.conf", ipsec_conf, 0o644)
    write_file("/etc/ipsec.secrets", f'%any %any : PSK "{opts["psk"]}"\n', 0o600)

    xl2tpd_conf = f"""; managed by NimexoPanel
[global]
port = {opts['port']}
access control = no
ipsec saref = no

[lns default]
ip range = {opts['range']}
local ip = {opts['local_ip']}
require chap = yes
refuse pap = yes
require authentication = yes
name = nimexo
ppp debug = no
pppoptfile = /etc/ppp/options.xl2tpd
length bit = yes
"""
    write_file("/etc/xl2tpd/xl2tpd.conf", xl2tpd_conf, 0o644)
    write_file("/etc/ppp/options.xl2tpd", write_ppp_options("l2tp", opts), 0o644)

    enable_forwarding()
    ensure_nat(opts["subnet"])
    for service in ("strongswan-starter", "strongswan", "ipsec"):
        code, _, _ = run(f"systemctl list-unit-files {service}.service")
        if code == 0:
            run(f"systemctl enable {service}")
            run(f"systemctl restart {service}")
            break
    run("systemctl enable xl2tpd")
    run("systemctl restart xl2tpd")
    time.sleep(1.0)
    return {
        "installed": "l2tp",
        "active": service_active("xl2tpd"),
        "port": opts["port"],
        "psk": opts["psk"],
    }


def install_pptp(payload=None):
    payload = payload or {}
    ensure_dirs()
    if not which("pptpd"):
        apt_install(["pptpd", "ppp", "iptables"])
    install_ppp_hooks()

    opts = dict(PPTP_DEFAULTS)
    opts.update({k: v for k, v in payload.items() if v not in (None, "")})

    write_file(
        "/etc/pptpd.conf",
        "# managed by NimexoPanel\noption /etc/ppp/pptpd-options\n"
        f"localip {opts['local_ip']}\nremoteip {opts['range']}\n",
        0o644,
    )
    write_file("/etc/ppp/pptpd-options", write_ppp_options("pptp", opts, mppe=True), 0o644)

    enable_forwarding()
    ensure_nat(opts["subnet"])
    run("systemctl enable pptpd")
    run("systemctl restart pptpd")
    time.sleep(1.0)
    return {
        "installed": "pptp",
        "active": service_active("pptpd"),
        "note": "PPTP needs GRE (protocol 47) to pass end to end",
    }


def cmd_apply_ppp():
    """payload = {"users": [...], "l2tp": {...}|None, "pptp": {...}|None}

    L2TP and PPTP share /etc/ppp/chap-secrets, so the account list is written
    once for both.
    """
    payload = read_stdin_json()
    ensure_dirs()
    install_ppp_hooks()

    lines = ["# managed by NimexoPanel", "# client\tserver\tsecret\tIP addresses"]
    for user in payload.get("users", []):
        if not user.get("username") or not user.get("password"):
            continue
        lines.append(f"{user['username']}\tnimexo\t{user['password']}\t*")
        lines.append(f"{user['username']}\t*\t{user['password']}\t*")
    write_file("/etc/ppp/chap-secrets", "\n".join(lines) + "\n", 0o600)

    result = {"ok": True, "users": len(payload.get("users", []))}
    if payload.get("l2tp"):
        result["l2tp"] = install_l2tp(payload["l2tp"])
    if payload.get("pptp"):
        result["pptp"] = install_pptp(payload["pptp"])
    return result


def cmd_ppp_stats():
    """Cumulative per-account counters: closed sessions plus live interfaces."""
    users = {}
    totals_dir = f"{PPP_DIR}/totals"
    sessions_dir = f"{PPP_DIR}/sessions"

    if os.path.isdir(totals_dir):
        for name in os.listdir(totals_dir):
            try:
                with open(f"{totals_dir}/{name}") as fh:
                    rx, tx = (int(x) for x in fh.read().split()[:2])
            except (ValueError, OSError):
                continue
            entry = users.setdefault(name, {"up": 0, "down": 0, "online": False})
            entry["down"] += rx
            entry["up"] += tx

    if os.path.isdir(sessions_dir):
        for iface in os.listdir(sessions_dir):
            try:
                with open(f"{sessions_dir}/{iface}") as fh:
                    name = fh.read().strip()
                with open(f"/sys/class/net/{iface}/statistics/rx_bytes") as fh:
                    rx = int(fh.read().strip())
                with open(f"/sys/class/net/{iface}/statistics/tx_bytes") as fh:
                    tx = int(fh.read().strip())
            except (OSError, ValueError):
                continue
            if not name:
                continue
            entry = users.setdefault(name, {"up": 0, "down": 0, "online": False})
            entry["down"] += rx
            entry["up"] += tx
            entry["online"] = True

    return {"users": users}


# --------------------------------------------------------------------------
# TLS certificates (Let's Encrypt via certbot)
# --------------------------------------------------------------------------
LE_DIR = "/etc/letsencrypt/live"


def cert_paths(domain):
    return f"{LE_DIR}/{domain}/fullchain.pem", f"{LE_DIR}/{domain}/privkey.pem"


def cmd_cert_issue():
    """payload = {domain, email, method: http|cloudflare, cf_token, staging}

    http        -> standalone challenge, needs port 80 reachable
    cloudflare  -> DNS-01, works even when port 80 is blocked upstream
    """
    payload = read_stdin_json()
    domain = (payload.get("domain") or "").strip()
    if not domain:
        return {"ok": False, "error": "no domain given"}
    method = payload.get("method", "http")
    email = payload.get("email") or f"admin@{domain}"

    packages = ["certbot"]
    if method == "cloudflare":
        packages.append("python3-certbot-dns-cloudflare")
    if not which("certbot") or (
        method == "cloudflare" and not os.path.exists("/usr/lib/python3/dist-packages/certbot_dns_cloudflare")
    ):
        apt_install(packages)

    full, key = cert_paths(domain)
    if os.path.exists(full) and not payload.get("force"):
        code, out, _ = run(f"openssl x509 -enddate -noout -in {full}")
        return {"ok": True, "domain": domain, "cert": full, "key": key,
                "existing": True, "expires": out.strip().split("=", 1)[-1]}

    base = (
        f"certbot certonly --non-interactive --agree-tos --email {shell_quote(email)} "
        f"-d {shell_quote(domain)} --key-type ecdsa "
        f"--deploy-hook 'systemctl restart {XRAY_SERVICE} 2>/dev/null || true'"
    )
    if payload.get("staging"):
        base += " --staging"

    if method == "cloudflare":
        token = payload.get("cf_token", "").strip()
        if not token:
            return {"ok": False, "error": "cloudflare token missing"}
        creds = f"{BASE_DIR}/cloudflare.ini"
        write_file(creds, f"dns_cloudflare_api_token = {token}\n", 0o600)
        cmd = (
            f"{base} --dns-cloudflare --dns-cloudflare-credentials {creds} "
            "--dns-cloudflare-propagation-seconds 40"
        )
    else:
        # free port 80 for the challenge, then hand it back
        cmd = f"{base} --standalone --preferred-challenges http --http-01-port 80"

    code, out, err = run(cmd, timeout=600)
    if code != 0 or not os.path.exists(full):
        return {"ok": False, "error": (err or out).strip()[-1500:]}

    code, out, _ = run(f"openssl x509 -enddate -noout -in {full}")
    return {
        "ok": True,
        "domain": domain,
        "cert": full,
        "key": key,
        "expires": out.strip().split("=", 1)[-1],
    }


def cmd_cert_list():
    certs = []
    if os.path.isdir(LE_DIR):
        for domain in sorted(os.listdir(LE_DIR)):
            full, key = cert_paths(domain)
            if not os.path.exists(full):
                continue
            _, out, _ = run(f"openssl x509 -enddate -noout -in {full}")
            certs.append(
                {
                    "domain": domain,
                    "cert": full,
                    "key": key,
                    "expires": out.strip().split("=", 1)[-1],
                }
            )
    return {"certs": certs, "certbot": bool(which("certbot"))}


# --------------------------------------------------------------------------
# generic
# --------------------------------------------------------------------------
SERVICE_MAP = {
    "xray": XRAY_SERVICE,
    "openvpn": "openvpn-server@nimexo",
    "ocserv": "ocserv",
    "l2tp": "xl2tpd",
    "pptp": "pptpd",
}


def cmd_restart(core, name=None):
    service = SERVICE_MAP.get(core) or (f"wg-quick@{name}" if core == "wireguard" else core)
    code, out, err = run(f"systemctl restart {service}")
    return {"ok": code == 0, "service": service, "error": (err or out).strip()[:500]}


def cmd_logs(core, lines=200, name=None):
    service = SERVICE_MAP.get(core) or (f"wg-quick@{name}" if core == "wireguard" else core)
    _, out, _ = run(f"journalctl -u {service} -n {int(lines)} --no-pager -o short-iso")
    return {"service": service, "logs": out}


def cmd_uninstall(core):
    if core == "xray":
        run(f"systemctl disable --now {XRAY_SERVICE}")
        for p in (XRAY_BIN, f"/etc/systemd/system/{XRAY_SERVICE}.service"):
            if os.path.exists(p):
                os.remove(p)
        run("systemctl daemon-reload")
    elif core == "openvpn":
        run("systemctl disable --now openvpn-server@nimexo")
        if os.path.exists("/etc/openvpn/server/nimexo.conf"):
            os.remove("/etc/openvpn/server/nimexo.conf")
    elif core == "wireguard":
        for fname in os.listdir(WG_DIR) if os.path.isdir(WG_DIR) else []:
            if fname.startswith("nx-") and fname.endswith(".conf"):
                run(f"systemctl disable --now wg-quick@{fname[:-5]}")
                os.remove(f"{WG_DIR}/{fname}")
    return {"ok": True, "core": core}


def main(argv):
    ensure_dirs()
    if len(argv) < 2:
        return {"error": "no command"}
    cmd = argv[1]
    args = argv[2:]

    if cmd == "ping":
        return {"agent_version": AGENT_VERSION, "cores": installed_cores()}
    if cmd == "sysinfo":
        return cmd_sysinfo()
    if cmd == "install":
        core = args[0] if args else ""
        payload = read_stdin_json() if not sys.stdin.isatty() else {}
        if core == "xray":
            return install_xray()
        if core == "wireguard":
            return install_wireguard()
        if core == "openvpn":
            return install_openvpn(payload.get("server") or payload)
        if core == "ocserv":
            return install_ocserv(payload.get("server") or payload)
        if core == "l2tp":
            return install_l2tp(payload.get("server") or payload)
        if core == "pptp":
            return install_pptp(payload.get("server") or payload)
        return {"error": f"unknown core {core}"}
    if cmd == "apply-xray":
        return cmd_apply_xray()
    if cmd == "xray-stats":
        return cmd_xray_stats(reset="--no-reset" not in args)
    if cmd == "apply-wireguard":
        return cmd_apply_wireguard()
    if cmd == "wg-stats":
        return cmd_wg_stats()
    if cmd == "apply-openvpn":
        return cmd_apply_openvpn()
    if cmd == "ovpn-stats":
        return cmd_ovpn_stats()
    if cmd == "ovpn-pki":
        return cmd_ovpn_pki()
    if cmd == "apply-ocserv":
        return cmd_apply_ocserv()
    if cmd == "ocserv-stats":
        return cmd_ocserv_stats()
    if cmd == "apply-ppp":
        return cmd_apply_ppp()
    if cmd == "ppp-stats":
        return cmd_ppp_stats()
    if cmd == "cert-issue":
        return cmd_cert_issue()
    if cmd == "cert-list":
        return cmd_cert_list()
    if cmd == "restart":
        return cmd_restart(args[0] if args else "", args[1] if len(args) > 1 else None)
    if cmd == "logs":
        return cmd_logs(
            args[0] if args else "",
            int(args[1]) if len(args) > 1 else 200,
            args[2] if len(args) > 2 else None,
        )
    if cmd == "uninstall":
        return cmd_uninstall(args[0] if args else "")
    return {"error": f"unknown command {cmd}"}


if __name__ == "__main__":
    try:
        result = main(sys.argv)
    except Exception as exc:  # noqa: BLE001
        result = {"error": f"{type(exc).__name__}: {exc}"}
        print(json.dumps(result))
        sys.exit(1)
    print(json.dumps(result))
