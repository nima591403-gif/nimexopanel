#!/usr/bin/env bash
# NimexoPanel installer — Ubuntu 20.04+ / Debian 11+
#
#   bash install.sh                 install or update
#   bash install.sh --update        pull the latest code and restart
#   bash install.sh --uninstall     remove the panel (keeps the database)
set -euo pipefail

APP_DIR=/opt/nimexo
REPO_DIR="$APP_DIR/src"
VENV="$APP_DIR/venv"
WEB_DIR="$APP_DIR/web"
ENV_FILE="$APP_DIR/.env"
SERVICE=nimexo-panel
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

blue()  { printf "\033[1;35m%s\033[0m\n" "$*"; }
green() { printf "\033[1;32m%s\033[0m\n" "$*"; }
warn()  { printf "\033[1;33m%s\033[0m\n" "$*"; }
die()   { printf "\033[1;31m%s\033[0m\n" "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "این اسکریپت باید با root اجرا شود."

if [[ "${1:-}" == "--uninstall" ]]; then
  systemctl disable --now "$SERVICE" 2>/dev/null || true
  rm -f "/etc/systemd/system/$SERVICE.service"
  systemctl daemon-reload
  rm -rf "$REPO_DIR" "$VENV" "$WEB_DIR"
  green "پنل حذف شد. دیتابیس در $APP_DIR/panel.db باقی ماند."
  exit 0
fi

blue "» نصب پیش‌نیازها"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null
apt-get install -y --no-install-recommends \
  python3 python3-venv python3-pip curl ca-certificates git openssl >/dev/null

if ! command -v node >/dev/null 2>&1 || [[ "$(node -v 2>/dev/null | cut -c2- | cut -d. -f1)" -lt 18 ]]; then
  blue "» نصب Node.js 20 (برای ساخت رابط کاربری)"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null
  apt-get install -y nodejs >/dev/null
fi

blue "» کپی کد در $REPO_DIR"
mkdir -p "$APP_DIR"
rm -rf "$REPO_DIR"
mkdir -p "$REPO_DIR"
cp -r "$SOURCE_DIR/backend" "$SOURCE_DIR/agent" "$SOURCE_DIR/frontend" "$REPO_DIR/"

blue "» ساخت محیط پایتون"
python3 -m venv "$VENV"
"$VENV/bin/pip" install --upgrade pip >/dev/null
"$VENV/bin/pip" install -r "$REPO_DIR/backend/requirements.txt" >/dev/null

blue "» ساخت رابط کاربری"
pushd "$REPO_DIR/frontend" >/dev/null
npm install --no-audit --no-fund --silent
npm run build --silent
popd >/dev/null
rm -rf "$WEB_DIR"
cp -r "$REPO_DIR/frontend/dist" "$WEB_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  blue "» ساخت فایل تنظیمات"
  ADMIN_PASS=$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-14)
  read -rp "پورت پنل [8080]: " PANEL_PORT
  PANEL_PORT=${PANEL_PORT:-8080}
  read -rp "دامنه یا IP عمومی پنل (برای لینک اشتراک): " PANEL_HOST
  cat > "$ENV_FILE" <<EOF
BRAND_NAME=NimexoPanel
HOST=0.0.0.0
PORT=$PANEL_PORT
SECRET_KEY=$(openssl rand -hex 32)
CREDENTIAL_KEY=$(openssl rand -hex 32)
DATABASE_URL=sqlite:///$APP_DIR/panel.db
DATA_DIR=$APP_DIR
PANEL_DOMAIN=$PANEL_HOST
PANEL_PUBLIC_URL=https://$PANEL_HOST
SUB_DOMAIN=$PANEL_HOST
SUB_PATH=sub
SUB_PORT=$PANEL_PORT
SUB_PROFILE_TITLE=NimexoPanel
TIMEZONE=Asia/Tehran
LOG_LEVEL=INFO
ADMIN_USERNAME=admin
ADMIN_PASSWORD=$ADMIN_PASS
EOF
  chmod 600 "$ENV_FILE"
  green "  نام کاربری: admin"
  green "  گذرواژه   : $ADMIN_PASS"
  warn  "  این اطلاعات را ذخیره کنید — بعداً از تنظیمات قابل تغییر است."
fi

blue "» ساخت سرویس systemd"
cat > "/etc/systemd/system/$SERVICE.service" <<EOF
[Unit]
Description=NimexoPanel — VPN management panel
After=network.target

[Service]
Type=simple
WorkingDirectory=$REPO_DIR/backend
EnvironmentFile=$ENV_FILE
Environment=FRONTEND_DIR=$WEB_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$VENV/bin/uvicorn app.main:app --host \${HOST} --port \${PORT} --proxy-headers --forwarded-allow-ips=*
Restart=always
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now "$SERVICE"
sleep 2

if systemctl is-active --quiet "$SERVICE"; then
  PORT_NOW=$(grep -E '^PORT=' "$ENV_FILE" | cut -d= -f2)
  green "✔ پنل بالا آمد → http://$(curl -s -4 ifconfig.me 2>/dev/null || echo SERVER_IP):$PORT_NOW"
  echo
  echo "  وضعیت سرویس : systemctl status $SERVICE"
  echo "  لاگ زنده     : journalctl -u $SERVICE -f"
  echo "  تنظیمات      : $ENV_FILE"
else
  die "سرویس بالا نیامد — journalctl -u $SERVICE -n 50 را ببینید."
fi
