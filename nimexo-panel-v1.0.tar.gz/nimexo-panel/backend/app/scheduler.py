"""Background jobs: node health, traffic collection and quota enforcement."""
import logging

from apscheduler.schedulers.background import BackgroundScheduler

from app.config import settings
from app.db import session_scope
from app.models import Node, utcnow
from app.models.enums import NodeStatus
from app.services import sync as sync_service
from app.services import traffic as traffic_service
from app.services.node_manager import NodeError, agent_for
from app.services.ssh import SSHError

logger = logging.getLogger(__name__)
scheduler = BackgroundScheduler(timezone="UTC")


def job_node_health() -> None:
    with session_scope() as db:
        for node in db.query(Node).filter(Node.is_enabled.is_(True)).all():
            try:
                info = agent_for(node).sysinfo()
            except (SSHError, NodeError) as exc:
                node.status = NodeStatus.OFFLINE
                node.status_message = str(exc)[:500]
                db.add(node)
                continue
            node.cpu_percent = info.get("cpu_percent", 0.0)
            node.mem_percent = (info.get("memory") or {}).get("percent", 0.0)
            node.disk_percent = (info.get("disk") or {}).get("percent", 0.0)
            node.uptime_seconds = info.get("uptime", 0)
            node.net_tx_speed = (info.get("net_speed") or {}).get("tx", 0.0)
            node.net_rx_speed = (info.get("net_speed") or {}).get("rx", 0.0)
            cores = info.get("cores", {}) or {}
            merged = dict(node.installed_cores or {})
            merged.update(cores)
            node.installed_cores = merged
            node.xray_version = cores.get("xray", node.xray_version)
            node.agent_version = info.get("agent_version", node.agent_version)
            node.status = NodeStatus.ONLINE
            node.status_message = ""
            node.last_seen = utcnow()
            db.add(node)


def job_collect_traffic() -> None:
    with session_scope() as db:
        traffic_service.collect_all(db)


def job_enforce_limits() -> None:
    with session_scope() as db:
        changed = traffic_service.enforce_limits(db)
        if changed:
            logger.info("limit enforcement: %s", changed)
            # push the new state so blocked users actually lose access
            sync_service.sync_all(db)


def start() -> None:
    if scheduler.running:
        return
    scheduler.add_job(job_node_health, "interval",
                      seconds=settings.NODE_HEALTH_INTERVAL, id="node_health",
                      max_instances=1, coalesce=True)
    scheduler.add_job(job_collect_traffic, "interval",
                      seconds=settings.TRAFFIC_SYNC_INTERVAL, id="traffic",
                      max_instances=1, coalesce=True)
    scheduler.add_job(job_enforce_limits, "interval",
                      seconds=settings.EXPIRY_CHECK_INTERVAL, id="limits",
                      max_instances=1, coalesce=True)
    scheduler.start()
    logger.info("scheduler started")


def stop() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
