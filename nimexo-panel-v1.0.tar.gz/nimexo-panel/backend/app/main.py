"""NimexoPanel — application entry point."""
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app import scheduler
from app.api.routes import (
    admins,
    auth,
    groups,
    inbounds,
    migration,
    nodes,
    stats,
    subscription,
    system,
    users,
)
from app.config import settings
from app.db import Base, engine, session_scope
from app.models import Admin
from app.models.enums import AdminRole
from app.utils.crypto import hash_password, random_token

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
)
logger = logging.getLogger("nimexo")

FRONTEND_DIR = Path(os.getenv("FRONTEND_DIR", "/opt/nimexo/web"))


def bootstrap() -> None:
    """Create tables and make sure at least one admin exists."""
    os.makedirs(settings.DATA_DIR, exist_ok=True)
    Base.metadata.create_all(engine)
    with session_scope() as db:
        if db.query(Admin).count() == 0:
            username = os.getenv("ADMIN_USERNAME", "admin")
            password = os.getenv("ADMIN_PASSWORD") or random_token(12)
            db.add(
                Admin(
                    username=username,
                    password_hash=hash_password(password),
                    role=AdminRole.SUDO,
                )
            )
            logger.warning(
                "created the first admin -> username: %s  password: %s",
                username, password,
            )


@asynccontextmanager
async def lifespan(_: FastAPI):
    bootstrap()
    scheduler.start()
    yield
    scheduler.stop()
    from app.services.ssh import pool

    pool.close_all()


app = FastAPI(
    title=f"{settings.BRAND_NAME} API",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url=None,
    openapi_url="/api/openapi.json",
    root_path=settings.ROOT_PATH,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for module in (auth, admins, users, groups, nodes, inbounds, stats, system,
               migration, subscription):
    app.include_router(module.router)


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):  # pragma: no cover
    logger.exception("unhandled error on %s", request.url.path)
    return JSONResponse(status_code=500, content={"detail": str(exc)})


# --------------------------------------------------------------------------
# static frontend (built with `npm run build`)
# --------------------------------------------------------------------------
if FRONTEND_DIR.is_dir():
    assets = FRONTEND_DIR / "assets"
    if assets.is_dir():
        app.mount("/assets", StaticFiles(directory=assets), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa(full_path: str):
        candidate = FRONTEND_DIR / full_path
        if full_path and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(FRONTEND_DIR / "index.html")
