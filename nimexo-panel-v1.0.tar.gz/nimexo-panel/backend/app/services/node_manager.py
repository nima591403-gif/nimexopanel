"""Panel-side driver for the node agent."""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

from app.models import Node
from app.models.enums import SSHAuthMethod
from app.services.ssh import CommandResult, SSHError, SSHTarget, pool
from app.utils.crypto import decrypt_secret

logger = logging.getLogger(__name__)

AGENT_REMOTE_PATH = "/opt/nimexo/agent.py"
AGENT_LOCAL_PATH = Path(__file__).resolve().parents[3] / "agent" / "nimexo_agent.py"


class NodeError(RuntimeError):
    pass


def agent_source() -> str:
    return AGENT_LOCAL_PATH.read_text()


def agent_version() -> str:
    for line in agent_source().splitlines():
        if line.startswith("AGENT_VERSION"):
            return line.split("=", 1)[1].strip().strip('"')
    return "0"


def target_for(node: Node) -> SSHTarget:
    secret = decrypt_secret(node.secret_enc)
    return SSHTarget(
        host=node.address,
        port=node.ssh_port,
        username=node.ssh_user,
        password=secret if node.auth_method == SSHAuthMethod.PASSWORD else "",
        private_key=secret if node.auth_method == SSHAuthMethod.KEY else "",
        key_passphrase=decrypt_secret(node.key_passphrase_enc),
        host_key=node.host_key,
        node_id=node.id,
    )


def target_from_credentials(
    address: str,
    port: int,
    username: str,
    auth_method: SSHAuthMethod | str,
    secret: str,
    passphrase: str = "",
    host_key: str = "",
) -> SSHTarget:
    method = SSHAuthMethod(auth_method)
    return SSHTarget(
        host=address,
        port=port,
        username=username,
        password=secret if method == SSHAuthMethod.PASSWORD else "",
        private_key=secret if method == SSHAuthMethod.KEY else "",
        key_passphrase=passphrase,
        host_key=host_key,
    )


class NodeAgent:
    """Runs agent commands on one node over SSH."""

    def __init__(self, target: SSHTarget):
        self.target = target
        self.conn = pool.get(target)

    # -- plumbing ----------------------------------------------------------
    @property
    def learned_host_key(self) -> str:
        return self.conn.learned_host_key

    def probe(self) -> dict:
        """Open the connection and report basic facts about the box."""
        res = self.conn.run("uname -a; python3 --version 2>&1 || true; id -u")
        res.raise_for_status("probe")
        lines = [l for l in res.stdout.strip().splitlines() if l.strip()]
        uid = lines[-1] if lines else "?"
        if uid != "0":
            sudo = self.conn.run("sudo -n true")
            if not sudo.ok:
                raise NodeError(
                    "the SSH user is not root and cannot run passwordless sudo"
                )
        return {
            "uname": lines[0] if lines else "",
            "python": lines[1] if len(lines) > 1 else "",
            "root": uid == "0",
            "host_key": self.conn.learned_host_key,
        }

    def ensure_agent(self, force: bool = False) -> str:
        """Upload the agent if it is missing or out of date."""
        if not force:
            res = self.conn.run(
                f"test -f {AGENT_REMOTE_PATH} && python3 {AGENT_REMOTE_PATH} ping"
            )
            if res.ok:
                try:
                    payload = json.loads(res.stdout.strip().splitlines()[-1])
                    if payload.get("agent_version") == agent_version():
                        return payload["agent_version"]
                except Exception:
                    pass
        self.conn.sudo("mkdir -p /opt/nimexo && chmod 750 /opt/nimexo")
        self.conn.write_file(AGENT_REMOTE_PATH, agent_source(), mode="750")
        return agent_version()

    def call(self, command: str, payload: dict | None = None,
             timeout: int = 300) -> dict:
        """Run an agent command and decode its JSON answer."""
        self.ensure_agent()
        stdin_data = json.dumps(payload) if payload is not None else ""
        cmd = f"python3 {AGENT_REMOTE_PATH} {command}"
        if self.target.username != "root":
            from app.services.ssh import shell_quote

            cmd = f"sudo -n bash -c {shell_quote(cmd)}"
        res: CommandResult = self.conn.run(cmd, stdin_data=stdin_data, timeout=timeout)
        text = res.stdout.strip()
        if not text:
            raise NodeError(
                f"agent returned nothing for '{command}': {res.stderr.strip()[:400]}"
            )
        try:
            data = json.loads(text.splitlines()[-1])
        except json.JSONDecodeError as exc:
            raise NodeError(f"unparsable agent output: {text[:400]}") from exc
        if isinstance(data, dict) and data.get("error") and not res.ok:
            raise NodeError(str(data["error"]))
        return data

    # -- high level --------------------------------------------------------
    def ping(self) -> dict:
        return self.call("ping", timeout=60)

    def sysinfo(self) -> dict:
        return self.call("sysinfo", timeout=90)

    def install_core(self, core: str, options: dict | None = None) -> dict:
        return self.call(f"install {core}", options or {}, timeout=1800)

    def uninstall_core(self, core: str) -> dict:
        return self.call(f"uninstall {core}", timeout=300)

    def apply_xray(self, config: dict) -> dict:
        return self.call("apply-xray", {"config": config}, timeout=180)

    def xray_stats(self, reset: bool = True) -> dict:
        return self.call("xray-stats" if reset else "xray-stats --no-reset", timeout=90)

    def apply_wireguard(self, payload: dict) -> dict:
        return self.call("apply-wireguard", payload, timeout=180)

    def wg_stats(self) -> dict:
        return self.call("wg-stats", timeout=60)

    def apply_openvpn(self, payload: dict) -> dict:
        return self.call("apply-openvpn", payload, timeout=1800)

    def ovpn_stats(self) -> dict:
        return self.call("ovpn-stats", timeout=60)

    def restart(self, core: str, name: str = "") -> dict:
        return self.call(f"restart {core} {name}".strip(), timeout=120)

    def logs(self, core: str, lines: int = 200, name: str = "") -> dict:
        return self.call(f"logs {core} {lines} {name}".strip(), timeout=90)


def agent_for(node: Node) -> NodeAgent:
    return NodeAgent(target_for(node))


__all__ = [
    "NodeAgent",
    "NodeError",
    "SSHError",
    "agent_for",
    "agent_version",
    "target_for",
    "target_from_credentials",
]
