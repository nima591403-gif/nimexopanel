"""Turn the panel's database state into live configuration on the nodes."""
from __future__ import annotations

import logging
from collections import defaultdict
from datetime import datetime

from sqlalchemy.orm import Session, selectinload

from app.models import AuditLog, Inbound, Node, NodeInbound, User, utcnow
from app.models.enums import CoreType, NodeStatus, UserStatus
from app.services.cores import openvpn as ovpn_core
from app.services.cores import wireguard as wg_core
from app.services.cores import xray as xray_core
from app.services.node_manager import NodeError, agent_for
from app.services.ssh import SSHError

logger = logging.getLogger(__name__)

ACTIVE_STATES = (UserStatus.ACTIVE, UserStatus.ON_HOLD)


# --------------------------------------------------------------------------
# eligibility
# --------------------------------------------------------------------------
def effective_inbounds(db: Session, user: User) -> list[Inbound]:
    """Explicit user inbounds win; otherwise the group's; plus defaults."""
    chosen = list(user.inbounds)
    if not chosen and user.group:
        chosen = list(user.group.inbounds)
    defaults = db.query(Inbound).filter(Inbound.is_default.is_(True)).all()
    merged = {i.id: i for i in chosen + defaults}
    return [i for i in merged.values() if i.is_enabled]


def effective_nodes(db: Session, user: User) -> list[Node]:
    chosen = list(user.nodes)
    if not chosen and user.group:
        chosen = list(user.group.nodes)
    if not chosen:
        chosen = db.query(Node).filter(Node.is_enabled.is_(True)).all()
    return [n for n in chosen if n.is_enabled]


def users_for(db: Session, node: Node, inbound: Inbound) -> list[User]:
    """Every active user entitled to this inbound on this node."""
    users = (
        db.query(User)
        .options(selectinload(User.inbounds), selectinload(User.nodes),
                 selectinload(User.group))
        .filter(User.status.in_(ACTIVE_STATES))
        .all()
    )
    result = []
    for user in users:
        inbound_ids = {i.id for i in effective_inbounds(db, user)}
        if inbound.id not in inbound_ids:
            continue
        node_ids = {n.id for n in effective_nodes(db, user)}
        if node.id not in node_ids:
            continue
        result.append(user)
    return result


def node_inbounds(db: Session, node: Node) -> list[tuple[NodeInbound, Inbound]]:
    rows = (
        db.query(NodeInbound)
        .options(selectinload(NodeInbound.inbound))
        .filter(NodeInbound.node_id == node.id, NodeInbound.is_enabled.is_(True))
        .all()
    )
    return [(ni, ni.inbound) for ni in rows if ni.inbound and ni.inbound.is_enabled]


# --------------------------------------------------------------------------
# per-core sync
# --------------------------------------------------------------------------
def sync_node(db: Session, node: Node, cores: set[CoreType] | None = None) -> dict:
    """Push the desired state of one node. Returns a per-core report."""
    report: dict[str, dict] = {}
    pairs = node_inbounds(db, node)
    if not pairs:
        report["info"] = {"ok": True, "message": "no inbounds assigned to this node"}

    grouped: dict[CoreType, list[tuple[NodeInbound, Inbound]]] = defaultdict(list)
    for ni, inbound in pairs:
        grouped[inbound.core].append((ni, inbound))

    agent = agent_for(node)

    try:
        # ---- Xray -----------------------------------------------------
        if (cores is None or CoreType.XRAY in cores):
            xray_pairs = []
            for ni, inbound in grouped.get(CoreType.XRAY, []):
                xray_pairs.append(
                    (inbound, users_for(db, node, inbound), ni.port_override)
                )
            if xray_pairs or grouped.get(CoreType.XRAY) is not None:
                config = xray_core.build_config(xray_pairs)
                result = agent.apply_xray(config)
                report["xray"] = result
                _mark(db, [ni for ni, _ in grouped.get(CoreType.XRAY, [])],
                      result.get("ok", False), result.get("error", ""))

        # ---- WireGuard ------------------------------------------------
        if (cores is None or CoreType.WIREGUARD in cores) and grouped.get(CoreType.WIREGUARD):
            interfaces = []
            for ni, inbound in grouped[CoreType.WIREGUARD]:
                interfaces.append(
                    wg_core.build_interface_payload(
                        db, inbound, users_for(db, node, inbound), ni.port_override
                    )
                )
            db.flush()
            result = agent.apply_wireguard({"interfaces": interfaces})
            report["wireguard"] = result
            _mark(db, [ni for ni, _ in grouped[CoreType.WIREGUARD]],
                  result.get("ok", False), result.get("error", ""))

        # ---- OpenVPN --------------------------------------------------
        if (cores is None or CoreType.OPENVPN in cores) and grouped.get(CoreType.OPENVPN):
            ovpn_users: dict[int, User] = {}
            server_opts = None
            for ni, inbound in grouped[CoreType.OPENVPN]:
                for u in users_for(db, node, inbound):
                    ovpn_users[u.id] = u
                if server_opts is None:
                    server_opts = ovpn_core.server_options(inbound, ni.port_override)
            payload = {
                "users": [
                    {"username": u.username, "password": u.password}
                    for u in ovpn_users.values()
                    if u.password
                ]
            }
            result = agent.apply_openvpn(payload)
            report["openvpn"] = result
            _mark(db, [ni for ni, _ in grouped[CoreType.OPENVPN]],
                  result.get("ok", True), result.get("error", ""))

        node.status = NodeStatus.ONLINE
        node.status_message = ""
        node.last_seen = utcnow()
    except (NodeError, SSHError) as exc:
        node.status = NodeStatus.ERROR
        node.status_message = str(exc)[:500]
        report["error"] = {"ok": False, "error": str(exc)}
        logger.warning("sync failed for node %s: %s", node.name, exc)

    db.add(node)
    db.commit()
    return report


def _mark(db: Session, node_inbound_rows, ok: bool, error: str) -> None:
    now = utcnow()
    for ni in node_inbound_rows:
        ni.synced_at = now if ok else ni.synced_at
        ni.sync_error = "" if ok else error[:500]
        db.add(ni)


def sync_all(db: Session, cores: set[CoreType] | None = None) -> dict[str, dict]:
    reports = {}
    for node in db.query(Node).filter(Node.is_enabled.is_(True)).all():
        reports[node.name] = sync_node(db, node, cores)
    return reports


def sync_nodes_for_user(db: Session, user: User) -> dict[str, dict]:
    """Cheap-ish targeted sync after a single user changed."""
    reports = {}
    for node in effective_nodes(db, user):
        reports[node.name] = sync_node(db, node)
    return reports


def log(db: Session, action: str, message: str, actor: str = "system",
        target: str = "", level: str = "info", ip: str = "", **meta) -> None:
    db.add(
        AuditLog(
            action=action, message=message, actor=actor, target=target,
            level=level, ip=ip, meta=meta or {},
        )
    )
    db.commit()
