# NimexoPanel

پنل اختصاصی مدیریت سرورهای VPN — چندنودی، چندپروتکلی، با گروه‌بندی کاربران و
مهاجرت مستقیم از پنل `vpn-ui`.

> فاز ۱ شامل هسته‌های **Xray/V2ray**، **OpenVPN** و **WireGuard** است.
> OpenConnect (Cisco) و L2TP/IPsec در فاز بعد اضافه می‌شوند؛ ساختار کد برای
> افزودن‌شان آماده است (`CoreType.OCSERV` / `CoreType.L2TP`).

---

## معماری در یک نگاه

```
┌────────────────────────────┐        SSH (بدون پورت باز اضافه)
│      NimexoPanel           │  ───────────────────────────────┐
│  FastAPI + SQLite/Postgres │                                 │
│  React (RTL) + APScheduler │                                 ▼
└────────────────────────────┘                    ┌──────────────────────────┐
        ▲            ▲                            │  نود ۱ (آلمان)           │
        │            │                            │  agent.py                │
   لینک اشتراک   پنل مدیریت                        │  Xray · WireGuard · OVPN │
   /sub/{id}    /users …                          └──────────────────────────┘
                                                  ┌──────────────────────────┐
                                                  │  نود ۲ (فنلاند) …        │
                                                  └──────────────────────────┘
```

* پنل **هیچ پورتی روی نود باز نمی‌کند**؛ همه‌چیز از طریق SSH موجود انجام می‌شود.
* کلید میزبان SSH هر نود در لحظه‌ی افزودن **پین** می‌شود و در هر اتصال بررسی
  می‌گردد — اگر عوض شود (rebuild سرور) پنل وصل نمی‌شود تا خودتان «تأیید مجدد» بزنید.
* گذرواژه/کلید SSH با Fernet و `CREDENTIAL_KEY` رمزنگاری شده در دیتابیس ذخیره می‌شود.
* یک عامل (agent) بدون وابستگی خارجی روی نود کپی می‌شود و فقط با فراخوانی از سمت
  پنل اجرا می‌شود.

---

## نصب

روی سرور پنل (Ubuntu 20.04+ / Debian 11+):

```bash
git clone <repo-url> nimexo-panel
cd nimexo-panel
bash install.sh
```

اسکریپت پایتون، Node، وابستگی‌ها و رابط کاربری را نصب می‌کند، فایل `.env` را
می‌سازد، سرویس `nimexo-panel` را بالا می‌آورد و نام کاربری/گذرواژه‌ی اولین مدیر
را چاپ می‌کند.

پشت Nginx و SSL (پیشنهادی):

```nginx
server {
    listen 443 ssl http2;
    server_name panel.example.com;

    ssl_certificate     /etc/letsencrypt/live/panel.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/panel.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## راه‌اندازی گام‌به‌گام

1. **نود اضافه کنید** — `نودها ← افزودن نود`: IP، پورت SSH، کاربر (root یا کاربری
   با `sudo -n`) و گذرواژه/کلید. دکمه‌ی «تست اتصال» کلید میزبان را نشان می‌دهد و
   بعد از ذخیره، هسته‌های انتخابی روی نود نصب می‌شوند.
2. **اینباند بسازید** — `پروتکل‌ها ← افزودن اینباند`: مثلاً VLESS + Reality روی
   پورت ۲۰۵۳، یا WireGuard، یا OpenVPN. نودهایی که این اینباند باید روی آن‌ها بالا
   بیاید را انتخاب کنید؛ پنل کانفیگ را می‌سازد و هسته را ری‌لود می‌کند.
3. **گروه (پلن) تعریف کنید** — `گروه‌ها`: تست ۱ روزه، ماهانه ۵۰ گیگ، سه‌ماهه…
   هر گروه حجم، مدت، تعداد دستگاه، قیمت، اینباندهای مجاز و لوکیشن‌های مجاز دارد.
4. **کاربر بسازید یا مهاجرت کنید** — بخش بعدی.

---

## مهاجرت از vpn-ui

### الف) ایمپورت یک‌باره (پیشنهادی)

```bash
scp root@old-server:/opt/vpn-ui/vpn-ui.db /tmp/
```

سپس در پنل: `مهاجرت ← انتخاب فایل vpn-ui.db`، گروه/اینباند/نود مقصد را انتخاب
کنید، اول «شبیه‌سازی» و بعد «شروع مهاجرت».

یا از خط فرمان:

```bash
cd /opt/nimexo/src/backend
/opt/nimexo/venv/bin/python scripts/migrate_vpnui.py /tmp/vpn-ui.db --inspect
/opt/nimexo/venv/bin/python scripts/migrate_vpnui.py /tmp/vpn-ui.db \
    --group monthly --inbounds 1,2 --nodes 1 --dry-run
/opt/nimexo/venv/bin/python scripts/migrate_vpnui.py /tmp/vpn-ui.db --group monthly
```

منتقل می‌شود: نام کاربری، گذرواژه، UUID، `sub_id`، حجم مجاز، **مصرف فعلی**،
تاریخ انقضا و وضعیت فعال/غیرفعال.

نکات سازگاری که در کد لحاظ شده‌اند:

| فیلد در vpn-ui   | معنا                                       |
|------------------|--------------------------------------------|
| `total_gb`       | در واقع **بایت** است، `0` = نامحدود        |
| `expiry_time`    | یونیکس‌تایم **میلی‌ثانیه**، `0` = بدون انقضا |
| مصرف             | `SUM(up+down)` از جدول `account_inbounds`   |
| `sub_id`         | برابر `vpn_username` و بخش قبل از `@` ایمیل |

چون `sub_id` حفظ می‌شود، **لینک اشتراک قدیمی کاربران با همان مسیر `/sub/{id}`
کار می‌کند** — کافی است دامنه‌ی اشتراک را به پنل جدید بدهید.

### ب) خودانتقالی کاربر

آدرس `https://<دامنه>/migrate` را به کاربران بدهید: نام کاربری و گذرواژه‌ی پنل
قبلی را وارد می‌کنند و حسابشان با همان حجم/مصرف/انقضا در پنل جدید ساخته و لینک
جدید نمایش داده می‌شود. برای این کار باید یک‌بار فایل دیتابیس قدیمی ایمپورت شده
باشد (اسنپ‌شات در جدول `legacy_accounts` نگه داشته می‌شود).

---

## صفحه‌ی کاربر

`https://<دامنه>/u/{sub_id}` — حجم مصرفی، حجم باقی‌مانده، روز باقی‌مانده، وضعیت،
لینک اشتراک و کارت جداگانه برای هر پروتکل با دکمه‌ی «کپی کانفیگ» یا «دریافت
کانفیگ» (`.ovpn` / `.conf`).

مسیر `/sub/{sub_id}` هوشمند است: اگر مرورگر باشد به صفحه‌ی بالا هدایت می‌شود و
اگر کلاینت v2ray باشد، لیست Base64 با هدرهای `subscription-userinfo` و
`profile-title` برمی‌گرداند.

---

## چند نود و انتخاب لوکیشن

هر اینباند می‌تواند روی چند نود مستقر شود. لینک اشتراک کاربر به‌ازای هر
(اینباند × نود مجاز) یک کانفیگ جداگانه با نام «🇩🇪 Germany · VLESS Reality»
تولید می‌کند، پس کاربر داخل اپلیکیشن خودش لوکیشن را انتخاب می‌کند.

محدودسازی دسترسی در دو سطح ممکن است:

* سطح گروه: `گروه‌ها ← لوکیشن‌های مجاز`
* سطح کاربر: `کاربران ← ویرایش ← لوکیشن‌ها` (خالی = ارث‌بری از گروه)

اگر نودی پشت تونل است، در «آدرس عمومی برای کاربران» دامنه/آی‌پی سرور ایران را
بگذارید تا لینک‌ها به آن اشاره کنند و آی‌پی سرور خارج مخفی بماند.

---

## حسابداری ترافیک

| هسته      | منبع آمار                       | نحوه‌ی محاسبه         |
|-----------|---------------------------------|-----------------------|
| Xray      | `xray api statsquery -reset`    | مستقیماً دلتا         |
| WireGuard | `wg show all dump`              | تفاضل با آخرین مقدار  |
| OpenVPN   | `status.log` (نسخه ۳)           | تفاضل، مقاوم به ریست  |

مقادیر در `user_node_usage` (تجمعی) و `traffic_records` (سطل ساعتی برای نمودار)
ذخیره می‌شوند. `usage_coefficient` هر نود اجازه می‌دهد ترافیک یک نود گران‌تر
حساب شود.

هر ۱۲۰ ثانیه محدودیت‌ها بررسی می‌شود: اتمام حجم → `limited`، پایان تاریخ →
`expired` و کانفیگ نودها بلافاصله بدون آن کاربر بازنویسی می‌شود.

---

## ساختار پروژه

```
backend/app/
├── main.py                 اپلیکیشن، سرو کردن SPA، bootstrap
├── config.py  db.py        تنظیمات و لایه‌ی دیتابیس
├── scheduler.py            جاب‌های سلامت نود / ترافیک / انقضا
├── models/                 مدل‌های SQLAlchemy و enumها
├── schemas/                مدل‌های ورودی/خروجی API
├── api/routes/             auth, users, groups, nodes, inbounds,
│                           stats, system, migration, subscription
└── services/
    ├── ssh.py              اتصال SSH با پین کلید میزبان + استخر اتصال
    ├── node_manager.py     آپلود و فراخوانی agent روی نود
    ├── sync.py             وضعیت مطلوب → کانفیگ روی نودها
    ├── traffic.py          جمع‌آوری آمار و اعمال محدودیت‌ها
    ├── links.py            ساخت لینک‌های vless/vmess/trojan/ss و فایل‌ها
    ├── migration.py        ایمپورت از vpn-ui + خودانتقالی
    └── cores/              سازنده‌های کانفیگ xray / wireguard / openvpn

agent/nimexo_agent.py       عاملی که روی هر نود اجرا می‌شود (بدون وابستگی)
frontend/src/               رابط React (RTL فارسی، تم تیره‌ی بنفش)
```

---

## API

مستندات تعاملی: `https://<دامنه>/api/docs`

```bash
TOKEN=$(curl -s -X POST https://panel/api/auth/login \
  -d 'username=admin&password=***' | jq -r .access_token)

curl -s https://panel/api/users -H "Authorization: Bearer $TOKEN"
curl -s -X POST https://panel/api/users -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"username":"ali","group_id":1,"duration_days":30}'
```

---

## نگهداری

```bash
systemctl status nimexo-panel
journalctl -u nimexo-panel -f
bash install.sh --update          # بروزرسانی کد و ری‌استارت
sqlite3 /opt/nimexo/panel.db .dump > backup-$(date +%F).sql
```

---

## نقشه‌ی راه فاز بعد

- [ ] هسته‌ی OpenConnect (ocserv) و L2TP/IPsec
- [ ] ربات تلگرام (وضعیت حساب، فروشگاه، تیکت)
- [ ] محدودسازی واقعی تعداد دستگاه هم‌زمان (قطع نشست اضافه)
- [ ] نمایندگی/ریسلر با کیف پول
- [ ] گواهی‌نامه‌ی خودکار Let's Encrypt از داخل پنل
