import clsx from "clsx";
import { useEffect, useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";

import { api, setToken } from "../lib/api";

const NAV = [
  { to: "/", label: "داشبورد", icon: "▦", end: true },
  { to: "/users", label: "کاربران", icon: "☺" },
  { to: "/groups", label: "گروه‌ها و پلن‌ها", icon: "◈" },
  { to: "/connections", label: "اتصالات", icon: "∿" },
  { to: "/nodes", label: "نودها", icon: "⬡" },
  { to: "/protocols", label: "پروتکل‌ها", icon: "⊕" },
  { to: "/migration", label: "مهاجرت", icon: "⇄" },
  { to: "/logs", label: "لاگ‌ها", icon: "☰" },
  { to: "/settings", label: "تنظیمات", icon: "⚙" },
];

export default function Layout() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [me, setMe] = useState<{ username: string; role: string } | null>(null);
  const [light, setLight] = useState(
    () => localStorage.getItem("nimexo.theme") === "light",
  );

  useEffect(() => {
    document.documentElement.classList.toggle("light", light);
    document.documentElement.classList.toggle("dark", !light);
    localStorage.setItem("nimexo.theme", light ? "light" : "dark");
  }, [light]);

  useEffect(() => {
    api
      .get<{ username: string; role: string }>("/api/auth/me")
      .then(setMe)
      .catch(() => navigate("/login"));
  }, [navigate]);

  const logout = () => {
    setToken("");
    navigate("/login");
  };

  return (
    <div className="flex min-h-screen">
      {/* sidebar */}
      <aside
        className={clsx(
          "fixed inset-y-0 right-0 z-40 w-64 border-l border-white/5 bg-ink-900/95 p-4 backdrop-blur transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "translate-x-full lg:translate-x-0",
        )}
      >
        <div className="mb-6 flex items-center gap-2 px-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-600 to-brand-400 text-lg font-bold text-white">
            N
          </span>
          <div>
            <p className="text-sm font-bold">NimexoPanel</p>
            <p className="text-[10px] text-ink-500">مدیریت سرورهای VPN</p>
          </div>
        </div>

        <nav className="space-y-1">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                clsx(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition",
                  isActive
                    ? "border-r-2 border-brand-400 bg-brand-500/15 font-medium text-brand-200"
                    : "text-ink-300 hover:bg-white/5",
                )
              }
            >
              <span className="w-4 text-center opacity-70">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="absolute inset-x-4 bottom-4 rounded-xl border border-white/5 bg-white/5 p-3">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-500/20 text-sm text-brand-200">
              {me?.username?.[0]?.toUpperCase() || "?"}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm">{me?.username || "…"}</p>
              <p className="text-[10px] text-ink-500">
                {me?.role === "sudo" ? "مدیر ارشد" : me?.role === "reseller" ? "نماینده" : "مدیر"}
              </p>
            </div>
            <button onClick={logout} title="خروج" className="rounded-lg p-1.5 text-ink-400 hover:bg-white/10">
              ⏻
            </button>
          </div>
        </div>
      </aside>

      {open && (
        <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setOpen(false)} />
      )}

      {/* main */}
      <div className="flex min-w-0 flex-1 flex-col lg:mr-64">
        <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-white/5 bg-ink-950/80 px-4 py-3 backdrop-blur">
          <button
            className="btn-ghost px-2.5 py-1.5 lg:hidden"
            onClick={() => setOpen((v) => !v)}
          >
            ☰
          </button>
          <div className="flex-1" />
          <button
            className="btn-ghost px-2.5 py-1.5"
            onClick={() => location.reload()}
            title="بازخوانی"
          >
            ⟳
          </button>
          <button
            className="btn-ghost px-2.5 py-1.5"
            onClick={() => setLight((v) => !v)}
            title="تغییر تم"
          >
            {light ? "☾" : "☀"}
          </button>
        </header>

        <main className="flex-1 p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
