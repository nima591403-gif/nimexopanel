import clsx from "clsx";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

/* ---------------------------------------------------------------- layout */
export function Card({
  children,
  className,
  title,
  subtitle,
  actions,
}: {
  children?: React.ReactNode;
  className?: string;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <section className={clsx("card", className)}>
      {(title || actions) && (
        <header className="mb-4 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="text-base font-semibold">{title}</h2>}
            {subtitle && <p className="mt-1 text-xs text-ink-400">{subtitle}</p>}
          </div>
          {actions && <div className="flex shrink-0 gap-2">{actions}</div>}
        </header>
      )}
      {children}
    </section>
  );
}

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "brand",
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  icon?: React.ReactNode;
  tone?: "brand" | "green" | "blue" | "amber" | "red";
}) {
  const tones = {
    brand: "from-brand-600 to-brand-400",
    green: "from-emerald-600 to-emerald-400",
    blue: "from-sky-600 to-sky-400",
    amber: "from-amber-600 to-amber-400",
    red: "from-rose-600 to-rose-400",
  } as const;
  return (
    <div className="card flex items-start justify-between gap-4">
      <div className="min-w-0">
        <p className="text-xs text-ink-400">{label}</p>
        <p className="mt-2 truncate text-2xl font-bold tabular-nums">{value}</p>
        {hint && <p className="mt-1 text-xs text-ink-500">{hint}</p>}
      </div>
      <div
        className={clsx(
          "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-white",
          tones[tone],
        )}
      >
        {icon}
      </div>
    </div>
  );
}

export function Progress({ value, total, className }: { value: number; total: number; className?: string }) {
  const pct = total ? Math.min(100, (value / total) * 100) : 0;
  const tone = pct > 90 ? "bg-rose-500" : pct > 70 ? "bg-amber-500" : "bg-brand-500";
  return (
    <div className={clsx("h-1.5 w-full overflow-hidden rounded-full bg-white/10", className)}>
      <div className={clsx("h-full rounded-full transition-all", tone)} style={{ width: `${pct}%` }} />
    </div>
  );
}

/* ---------------------------------------------------------------- badges */
const STATUS_STYLES: Record<string, string> = {
  active: "bg-emerald-500/15 text-emerald-300",
  online: "bg-emerald-500/15 text-emerald-300",
  disabled: "bg-ink-500/20 text-ink-300",
  offline: "bg-ink-500/20 text-ink-300",
  expired: "bg-amber-500/15 text-amber-300",
  limited: "bg-rose-500/15 text-rose-300",
  error: "bg-rose-500/15 text-rose-300",
  on_hold: "bg-sky-500/15 text-sky-300",
  installing: "bg-brand-500/15 text-brand-300",
  unknown: "bg-ink-500/20 text-ink-300",
};

export const STATUS_LABELS: Record<string, string> = {
  active: "فعال",
  disabled: "غیرفعال",
  expired: "منقضی",
  limited: "اتمام حجم",
  on_hold: "در انتظار اتصال",
  online: "آنلاین",
  offline: "آفلاین",
  error: "خطا",
  installing: "در حال نصب",
  unknown: "نامشخص",
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={clsx("badge", STATUS_STYLES[status] || STATUS_STYLES.unknown)}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {STATUS_LABELS[status] || status}
    </span>
  );
}

export function Chip({ children, tone = "default" }: { children: React.ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    default: "bg-white/5 text-ink-300",
    brand: "bg-brand-500/15 text-brand-300",
    green: "bg-emerald-500/15 text-emerald-300",
  };
  return <span className={clsx("badge", tones[tone] || tones.default)}>{children}</span>;
}

/* ----------------------------------------------------------------- forms */
export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="label">{label}</label>
      {children}
      {hint && <p className="mt-1 text-[11px] text-ink-500">{hint}</p>}
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center gap-2 text-sm"
    >
      <span
        className={clsx(
          "relative h-6 w-11 rounded-full transition",
          checked ? "bg-emerald-500" : "bg-ink-700",
        )}
      >
        <span
          className={clsx(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all",
            checked ? "right-0.5" : "right-[22px]",
          )}
        />
      </span>
      {label && <span className="text-ink-300">{label}</span>}
    </button>
  );
}

export function MultiSelect<T extends { id: number }>({
  options,
  selected,
  onChange,
  render,
  empty = "موردی موجود نیست",
}: {
  options: T[];
  selected: number[];
  onChange: (ids: number[]) => void;
  render: (item: T) => React.ReactNode;
  empty?: string;
}) {
  if (!options.length) return <p className="text-xs text-ink-500">{empty}</p>;
  return (
    <div className="flex max-h-44 flex-wrap gap-2 overflow-y-auto rounded-xl border border-white/10 bg-ink-950/50 p-2">
      {options.map((option) => {
        const on = selected.includes(option.id);
        return (
          <button
            key={option.id}
            type="button"
            onClick={() =>
              onChange(on ? selected.filter((i) => i !== option.id) : [...selected, option.id])
            }
            className={clsx(
              "rounded-lg border px-2.5 py-1.5 text-xs transition",
              on
                ? "border-brand-500 bg-brand-500/20 text-brand-200"
                : "border-white/10 bg-white/5 text-ink-300 hover:border-white/20",
            )}
          >
            {render(option)}
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------- modals */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center overflow-y-auto bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-6">
      <div
        className={clsx(
          "w-full rounded-t-3xl border border-white/10 bg-ink-900 p-5 shadow-2xl sm:rounded-2xl",
          wide ? "sm:max-w-3xl" : "sm:max-w-lg",
        )}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-ink-400 hover:bg-white/5">
            ✕
          </button>
        </div>
        <div className="max-h-[65vh] overflow-y-auto pl-1">{children}</div>
        {footer && <div className="mt-5 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- toasts */
type Toast = { id: number; text: string; tone: "ok" | "error" };
const ToastCtx = createContext<(text: string, tone?: "ok" | "error") => void>(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((text: string, tone: "ok" | "error" = "ok") => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev, { id, text, tone }]);
    setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4000);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed bottom-4 left-1/2 z-[60] flex w-[min(92vw,26rem)] -translate-x-1/2 flex-col gap-2">
        {items.map((t) => (
          <div
            key={t.id}
            className={clsx(
              "rounded-xl border px-4 py-3 text-sm shadow-lg backdrop-blur",
              t.tone === "ok"
                ? "border-emerald-500/30 bg-emerald-500/15 text-emerald-100"
                : "border-rose-500/30 bg-rose-500/15 text-rose-100",
            )}
          >
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/* ----------------------------------------------------------------- misc */
export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={clsx(
        "inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent",
        className,
      )}
    />
  );
}

export function Empty({ text }: { text: string }) {
  return (
    <div className="rounded-xl border border-dashed border-white/10 p-8 text-center text-sm text-ink-400">
      {text}
    </div>
  );
}

export function CopyButton({ value, label = "کپی" }: { value: string; label?: string }) {
  const toast = useToast();
  return (
    <button
      type="button"
      className="btn-ghost px-2.5 py-1 text-xs"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          toast("کپی شد");
        } catch {
          toast("مرورگر اجازه‌ی کپی نداد", "error");
        }
      }}
    >
      {label}
    </button>
  );
}
