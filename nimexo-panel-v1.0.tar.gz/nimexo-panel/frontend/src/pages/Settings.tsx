import { useEffect, useState } from "react";

import { Card, Chip, Field, Spinner, useToast } from "../components/ui";
import { api } from "../lib/api";
import { duration } from "../lib/format";

interface SystemInfo {
  brand: string;
  version: string;
  python: string;
  platform: string;
  timezone: string;
  sub_base_url: string;
  uptime: number;
}

interface AdminRow {
  id: number;
  username: string;
  role: string;
  is_active: boolean;
}

export default function Settings() {
  const toast = useToast();
  const [info, setInfo] = useState<SystemInfo | null>(null);
  const [admins, setAdmins] = useState<AdminRow[]>([]);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get<SystemInfo>("/api/system/info").then(setInfo).catch(() => {});
    api.get<AdminRow[]>("/api/admins").then(setAdmins).catch(() => {});
  }, []);

  const changePassword = async () => {
    setBusy(true);
    try {
      await api.post("/api/auth/change-password", {
        current_password: current,
        new_password: next,
      });
      toast("گذرواژه تغییر کرد");
      setCurrent("");
      setNext("");
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const maintenance = async (path: string, label: string) => {
    setBusy(true);
    try {
      await api.post(`/api/system/${path}`);
      toast(`${label} انجام شد`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">تنظیمات</h1>
        <p className="mt-1 text-xs text-ink-400">اطلاعات پنل، حساب مدیریت و عملیات نگهداری</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="اطلاعات پنل">
          {info ? (
            <dl className="space-y-2 text-sm">
              <Row k="نسخه" v={info.version} />
              <Row k="پایتون" v={info.python} />
              <Row k="سیستم" v={<span className="text-xs">{info.platform}</span>} />
              <Row k="منطقه زمانی" v={info.timezone} />
              <Row k="زمان کارکرد" v={duration(info.uptime)} />
              <Row
                k="آدرس پایه‌ی اشتراک"
                v={<code className="text-[11px]">{info.sub_base_url}</code>}
              />
            </dl>
          ) : (
            <Spinner />
          )}
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("sync-all", "همگام‌سازی همه نودها")}
            >
              همگام‌سازی همه نودها
            </button>
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("collect", "خواندن آمار")}
            >
              خواندن آمار ترافیک
            </button>
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("enforce", "بررسی محدودیت‌ها")}
            >
              بررسی انقضا و حجم
            </button>
            <a className="btn-ghost text-xs" href="/api/docs" target="_blank" rel="noreferrer">
              مستندات API
            </a>
          </div>
        </Card>

        <Card title="تغییر گذرواژه">
          <div className="space-y-3">
            <Field label="گذرواژه فعلی">
              <input
                type="password"
                className="input"
                value={current}
                onChange={(e) => setCurrent(e.target.value)}
              />
            </Field>
            <Field label="گذرواژه جدید">
              <input
                type="password"
                className="input"
                value={next}
                onChange={(e) => setNext(e.target.value)}
              />
            </Field>
            <button className="btn-primary" onClick={changePassword} disabled={busy || !next}>
              {busy ? <Spinner /> : "ذخیره"}
            </button>
          </div>
        </Card>
      </div>

      <Card title="مدیران" subtitle="فقط مدیر ارشد می‌تواند مدیران را ببیند و تغییر دهد">
        {admins.length ? (
          <div className="space-y-2">
            {admins.map((a) => (
              <div
                key={a.id}
                className="flex items-center justify-between rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
              >
                <span className="text-sm">{a.username}</span>
                <div className="flex gap-2">
                  <Chip tone="brand">
                    {a.role === "sudo" ? "مدیر ارشد" : a.role === "reseller" ? "نماینده" : "مدیر"}
                  </Chip>
                  <Chip tone={a.is_active ? "green" : "default"}>
                    {a.is_active ? "فعال" : "غیرفعال"}
                  </Chip>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-ink-500">
            دسترسی مدیر ارشد لازم است یا هنوز مدیری ثبت نشده.
          </p>
        )}
      </Card>
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between border-b border-white/5 pb-2">
      <dt className="text-ink-400">{k}</dt>
      <dd>{v}</dd>
    </div>
  );
}
