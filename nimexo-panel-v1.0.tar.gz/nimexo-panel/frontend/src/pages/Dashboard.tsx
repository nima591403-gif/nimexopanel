import { useEffect, useState } from "react";
import {
  Area,
  AreaChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { Card, Empty, Progress, StatCard, StatusBadge } from "../components/ui";
import { api } from "../lib/api";
import { bytes, duration, number, speed } from "../lib/format";
import type { Dashboard as DashboardData } from "../lib/types";

const PIE_COLORS = ["#8b3dff", "#22c55e", "#38bdf8", "#f59e0b", "#f43f5e", "#a78bfa"];

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [series, setSeries] = useState<{ t: string; up: number; down: number }[]>([]);

  const load = () => {
    api.get<DashboardData>("/api/stats/dashboard").then(setData).catch(() => {});
    api
      .get<{ t: string; up: number; down: number }[]>("/api/stats/traffic?hours=48")
      .then(setSeries)
      .catch(() => {});
  };

  useEffect(() => {
    load();
    const timer = setInterval(load, 15_000);
    return () => clearInterval(timer);
  }, []);

  const pie = Object.entries(data?.protocol_distribution || {}).map(([name, value]) => ({
    name,
    value,
  }));

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">داشبورد</h1>
        <p className="mt-1 text-xs text-ink-400">نمای کلی سرورهای VPN شما</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="کل کاربران"
          value={number(data?.users_total)}
          hint={`${number(data?.users_active)} فعال`}
          icon="☺"
        />
        <StatCard
          label="کاربران آنلاین"
          value={number(data?.users_online)}
          hint="هم‌اکنون متصل"
          icon="∿"
          tone="blue"
        />
        <StatCard
          label="ترافیک امروز"
          value={bytes(data?.traffic_today)}
          hint={`${bytes(data?.traffic_month)} در ۳۰ روز`}
          icon="↕"
          tone="green"
        />
        <StatCard
          label="نودهای آنلاین"
          value={`${number(data?.nodes_online)} / ${number(data?.nodes_total)}`}
          hint={`${number(data?.inbounds_total)} اینباند`}
          icon="⬡"
          tone="amber"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="نمودار ترافیک" subtitle="۴۸ ساعت گذشته" className="lg:col-span-2">
          {series.length ? (
            <div className="h-64" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={series}>
                  <defs>
                    <linearGradient id="up" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8b3dff" stopOpacity={0.6} />
                      <stop offset="100%" stopColor="#8b3dff" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="down" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="#38bdf8" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="t"
                    tick={{ fontSize: 10, fill: "#8484b3" }}
                    tickFormatter={(v) => new Date(`${v}Z`).getHours() + ":00"}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 10, fill: "#8484b3" }}
                    tickFormatter={(v) => bytes(v, 0)}
                    axisLine={false}
                    tickLine={false}
                    width={60}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "#141428",
                      border: "1px solid rgba(255,255,255,.1)",
                      borderRadius: 12,
                      fontSize: 12,
                    }}
                    formatter={(v: number) => bytes(v)}
                  />
                  <Area
                    type="monotone"
                    dataKey="down"
                    stroke="#38bdf8"
                    fill="url(#down)"
                    strokeWidth={2}
                    name="دانلود"
                  />
                  <Area
                    type="monotone"
                    dataKey="up"
                    stroke="#8b3dff"
                    fill="url(#up)"
                    strokeWidth={2}
                    name="آپلود"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <Empty text="هنوز ترافیکی ثبت نشده است" />
          )}
        </Card>

        <Card title="توزیع پروتکل‌ها" subtitle="تعداد کاربر روی هر پروتکل">
          {pie.length ? (
            <div className="h-64" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pie}
                    dataKey="value"
                    nameKey="name"
                    innerRadius="55%"
                    outerRadius="85%"
                    paddingAngle={3}
                  >
                    {pie.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "#141428",
                      border: "1px solid rgba(255,255,255,.1)",
                      borderRadius: 12,
                      fontSize: 12,
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <Empty text="اینباندی تعریف نشده" />
          )}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="وضعیت نودها">
          <div className="space-y-3">
            {(data?.node_status || []).map((node) => (
              <div key={node.id} className="rounded-xl border border-white/5 bg-white/5 p-3">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{node.name}</span>
                    {node.country && <span className="text-xs text-ink-400">{node.country}</span>}
                  </div>
                  <StatusBadge status={node.status} />
                </div>
                <div className="grid grid-cols-3 gap-3 text-xs text-ink-400">
                  <div>
                    <div className="mb-1 flex justify-between">
                      <span>پردازنده</span>
                      <span className="tabular-nums">{node.cpu.toFixed(0)}%</span>
                    </div>
                    <Progress value={node.cpu} total={100} />
                  </div>
                  <div>
                    <div className="mb-1 flex justify-between">
                      <span>حافظه</span>
                      <span className="tabular-nums">{node.memory.toFixed(0)}%</span>
                    </div>
                    <Progress value={node.memory} total={100} />
                  </div>
                  <div>
                    <div className="mb-1 flex justify-between">
                      <span>دیسک</span>
                      <span className="tabular-nums">{node.disk.toFixed(0)}%</span>
                    </div>
                    <Progress value={node.disk} total={100} />
                  </div>
                </div>
                <div className="mt-2 flex gap-4 text-[11px] text-ink-500">
                  <span>↑ {speed(node.tx)}</span>
                  <span>↓ {speed(node.rx)}</span>
                  <span>زمان کارکرد: {duration(node.uptime)}</span>
                </div>
              </div>
            ))}
            {!data?.node_status.length && <Empty text="هنوز نودی اضافه نشده است" />}
          </div>
        </Card>

        <Card title="پرمصرف‌ترین کاربران">
          {data?.top_users.length ? (
            <div className="space-y-3">
              {data.top_users.map((u) => (
                <div key={u.username}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span>{u.username}</span>
                    <span className="tabular-nums text-ink-400">{bytes(u.used)}</span>
                  </div>
                  <Progress value={u.used} total={u.limit || u.used} />
                </div>
              ))}
            </div>
          ) : (
            <Empty text="نسبت ترافیکی وجود ندارد" />
          )}
        </Card>
      </div>
    </div>
  );
}
