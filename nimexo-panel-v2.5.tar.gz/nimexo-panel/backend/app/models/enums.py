"""Shared enumerations."""
from enum import Enum


class StrEnum(str, Enum):
    def __str__(self) -> str:  # pragma: no cover
        return self.value


class AdminRole(StrEnum):
    SUDO = "sudo"          # full control, manages other admins
    ADMIN = "admin"        # manages users/nodes but not admins
    RESELLER = "reseller"  # only manages its own users, has a quota


class UserStatus(StrEnum):
    ACTIVE = "active"
    DISABLED = "disabled"    # manually turned off
    EXPIRED = "expired"      # passed expire date
    LIMITED = "limited"      # ran out of traffic
    ON_HOLD = "on_hold"      # countdown starts on first connection


class CoreType(StrEnum):
    XRAY = "xray"
    WIREGUARD = "wireguard"
    OPENVPN = "openvpn"
    OCSERV = "ocserv"        # Cisco AnyConnect
    L2TP = "l2tp"            # L2TP/IPsec
    PPTP = "pptp"


class Protocol(StrEnum):
    VLESS = "vless"
    VMESS = "vmess"
    TROJAN = "trojan"
    SHADOWSOCKS = "shadowsocks"
    WIREGUARD = "wireguard"
    OPENVPN = "openvpn"
    OCSERV = "ocserv"
    L2TP = "l2tp"
    PPTP = "pptp"


XRAY_PROTOCOLS = {
    Protocol.VLESS,
    Protocol.VMESS,
    Protocol.TROJAN,
    Protocol.SHADOWSOCKS,
}

PROTOCOL_CORE = {
    Protocol.VLESS: CoreType.XRAY,
    Protocol.VMESS: CoreType.XRAY,
    Protocol.TROJAN: CoreType.XRAY,
    Protocol.SHADOWSOCKS: CoreType.XRAY,
    Protocol.WIREGUARD: CoreType.WIREGUARD,
    Protocol.OPENVPN: CoreType.OPENVPN,
    Protocol.OCSERV: CoreType.OCSERV,
    Protocol.L2TP: CoreType.L2TP,
    Protocol.PPTP: CoreType.PPTP,
}


class Network(StrEnum):
    TCP = "tcp"
    WS = "ws"
    GRPC = "grpc"
    KCP = "kcp"
    HTTPUPGRADE = "httpupgrade"
    XHTTP = "xhttp"
    H2 = "h2"


class Security(StrEnum):
    NONE = "none"
    TLS = "tls"
    REALITY = "reality"


class NodeStatus(StrEnum):
    ONLINE = "online"
    OFFLINE = "offline"
    ERROR = "error"
    UNKNOWN = "unknown"
    INSTALLING = "installing"


class SSHAuthMethod(StrEnum):
    PASSWORD = "password"
    KEY = "key"


class GroupKind(StrEnum):
    TEST = "test"
    DAILY = "daily"
    MONTHLY = "monthly"
    MULTI_MONTH = "multi_month"
    CUSTOM = "custom"


class DataLimitStrategy(StrEnum):
    NO_RESET = "no_reset"
    DAILY = "day"
    WEEKLY = "week"
    MONTHLY = "month"
    YEARLY = "year"
