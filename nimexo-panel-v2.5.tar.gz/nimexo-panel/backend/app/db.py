"""Database engine / session helpers."""
from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import settings


class Base(DeclarativeBase):
    pass


connect_args = {}
if settings.DATABASE_URL.startswith("sqlite"):
    connect_args = {"check_same_thread": False, "timeout": 30}

engine = create_engine(
    settings.DATABASE_URL,
    connect_args=connect_args,
    pool_pre_ping=True,
    echo=False,
)

if settings.DATABASE_URL.startswith("sqlite"):

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, _):
        cur = dbapi_connection.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False,
                           expire_on_commit=False)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def ensure_schema() -> list[str]:
    """Add columns that exist in the models but not yet in the database.

    `create_all` only ever creates missing *tables*, so upgrading a live panel
    would otherwise crash on any newly added column. This keeps upgrades a
    matter of dropping in new code, without an Alembic revision per change.
    Column removals and type changes are deliberately not handled — those are
    rare enough to deserve a real migration.
    """
    import logging

    from sqlalchemy import inspect, text

    logger = logging.getLogger(__name__)
    added: list[str] = []
    # start from fresh connections so nothing is working off a cached schema
    engine.dispose()
    inspector = inspect(engine)

    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if not inspector.has_table(table.name):
                continue
            existing = {c["name"] for c in inspector.get_columns(table.name)}
            for column in table.columns:
                if column.name in existing:
                    continue
                col_type = column.type.compile(engine.dialect)
                clause = f'ALTER TABLE "{table.name}" ADD COLUMN "{column.name}" {col_type}'
                default = getattr(column.default, "arg", None)
                if default is not None and not callable(default):
                    literal = (
                        f"'{default}'" if isinstance(default, str)
                        else str(int(default) if isinstance(default, bool) else default)
                    )
                    clause += f" DEFAULT {literal}"
                elif column.default is not None and callable(default):
                    # list/dict factories -> start from an empty JSON value
                    sample = default(None) if default.__code__.co_argcount else default()
                    if isinstance(sample, (list, dict)):
                        clause += " DEFAULT '{}'".format(
                            "[]" if isinstance(sample, list) else "{}"
                        )
                try:
                    conn.execute(text(clause))
                    added.append(f"{table.name}.{column.name}")
                except Exception as exc:  # noqa: BLE001
                    logger.warning("could not add %s.%s: %s", table.name, column.name, exc)

    if added:
        logger.warning("schema updated, new columns: %s", ", ".join(added))
    return added


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """Use inside background jobs / scripts."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
