"""QR codes for subscription links and individual configs."""
from __future__ import annotations

import io

import qrcode
from qrcode.constants import ERROR_CORRECT_L, ERROR_CORRECT_M

# A WireGuard config is far longer than a share link, so drop to the lowest
# error correction for big payloads to keep the code scannable on a phone.
LOW_EC_THRESHOLD = 700
MAX_PAYLOAD = 2800  # beyond this a QR is too dense to scan reliably


def png(data: str, box_size: int = 8, border: int = 2) -> bytes:
    code = qrcode.QRCode(
        version=None,
        error_correction=ERROR_CORRECT_L if len(data) > LOW_EC_THRESHOLD else ERROR_CORRECT_M,
        box_size=box_size,
        border=border,
    )
    code.add_data(data)
    code.make(fit=True)
    image = code.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


def too_large(data: str) -> bool:
    return len(data) > MAX_PAYLOAD
