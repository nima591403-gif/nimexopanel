"""Import accounts from the old vpn-ui / 3X-UI style panel.

The importer is deliberately defensive: it introspects the source schema
instead of assuming fixed column names, because vpn-ui forks rename things
between releases.

Known semantics of vpn-ui (confirmed against a live panel):
  * accounts.total_gb    -> BYTES despite the name, 0 = unlimited
  * accounts.expiry_time -> unix timestamp in MILLISECONDS, 0 = never
  * usage                -> SUM(up + down) over account_inbounds
  * accounts.password    -> stored in plaintext
  * sub_id == vpn_username == the part of the email before '@'
"""
from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable

from sqlalchemy.orm import Session

from app.models import Group, Inbound, LegacyAccount, Node, User, utcnow
from app.models.enums import UserStatus
from app.services import users as user_service

logger = logging.getLogger(__name__)

ACCOUNT_TABLES = ("accounts", "clients", "inbound_clients", "users")
USERNAME_COLUMNS = ("vpn_username", "username", "email", "remark", "name")
UUID_COLUMNS = ("uuid", "id_uuid", "client_id", "subid")
LIMIT_COLUMNS = ("total_gb", "total", "data_limit", "traffic_limit")
EXPIRY_COLUMNS = ("expiry_time", "expire", "expiry", "expire_time")
ENABLE_COLUMNS = ("enable", "enabled", "is_active", "active")


@dataclass
class LegacyRow:
    username: str
    email: str = ""
    password: str = ""
    uuid: str = ""
    sub_id: str = ""
    data_limit: int = 0
    used_traffic: int = 0
    expire_at: datetime | None = None
    enabled: bool = True
    raw: dict = field(default_factory=dict)


def _columns(cur: sqlite3.Cursor, table: str) -> list[str]:
    cur.execute(f"PRAGMA table_info({table})")
    return [r[1] for r in cur.fetchall()]


def _tables(cur: sqlite3.Cursor) -> list[str]:
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    return [r[0] for r in cur.fetchall()]


def _pick(columns: Iterable[str], candidates: Iterable[str]) -> str:
    cols = {c.lower(): c for c in columns}
    for candidate in candidates:
        if candidate in cols:
            return cols[candidate]
    return ""


def _to_datetime(value) -> datetime | None:
    """vpn-ui stores milliseconds; other forks store seconds."""
    try:
        number = int(value or 0)
    except (TypeError, ValueError):
        return None
    if number <= 0:
        return None
    if number > 10_000_000_000:      # milliseconds
        number //= 1000
    try:
        return datetime.utcfromtimestamp(number)
    except (OverflowError, OSError, ValueError):
        return None


def inspect(db_path: str) -> dict:
    """Return a short description of the source database."""
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        cur = conn.cursor()
        tables = _tables(cur)
        table = next((t for t in ACCOUNT_TABLES if t in tables), "")
        if not table:
            raise ValueError(
                f"no recognizable account table in {db_path} (found: {', '.join(tables)})"
            )
        cols = _columns(cur, table)
        cur.execute(f"SELECT COUNT(*) FROM {table}")
        count = cur.fetchone()[0]

        inbounds = []
        if "inbounds" in tables:
            in_cols = _columns(cur, "inbounds")
            wanted = [c for c in ("id", "tag", "remark", "protocol", "port", "enable")
                      if c in in_cols]
            cur.execute(f"SELECT {', '.join(wanted)} FROM inbounds")
            inbounds = [dict(zip(wanted, row)) for row in cur.fetchall()]

        sample = []
        cur.execute(f"SELECT * FROM {table} LIMIT 3")
        for row in cur.fetchall():
            sample.append({k: row[i] for i, k in enumerate(cols)})

        return {
            "table": table,
            "tables": tables,
            "columns": cols,
            "accounts": count,
            "inbounds": inbounds,
            "sample": sample,
        }
    finally:
        conn.close()


def read_accounts(db_path: str) -> list[LegacyRow]:
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        tables = _tables(cur)
        table = next((t for t in ACCOUNT_TABLES if t in tables), "")
        if not table:
            raise ValueError("no account table found in the source database")
        cols = _columns(cur, table)

        col_user = _pick(cols, USERNAME_COLUMNS)
        col_uuid = _pick(cols, UUID_COLUMNS)
        col_limit = _pick(cols, LIMIT_COLUMNS)
        col_expire = _pick(cols, EXPIRY_COLUMNS)
        col_enable = _pick(cols, ENABLE_COLUMNS)
        col_sub = _pick(cols, ("sub_id", "subid", "sub"))
        col_pass = _pick(cols, ("password", "passwd", "pass"))
        col_email = _pick(cols, ("email",))
        col_id = "id" if "id" in cols else ""

        # usage: prefer the per-inbound table, fall back to columns on the row
        usage: dict[str, int] = {}
        if "account_inbounds" in tables:
            ai_cols = _columns(cur, "account_inbounds")
            key = _pick(ai_cols, ("account_id", "client_id", "user_id"))
            if key and "up" in ai_cols and "down" in ai_cols:
                cur.execute(
                    f"SELECT {key}, SUM(COALESCE(up,0) + COALESCE(down,0)) "
                    f"FROM account_inbounds GROUP BY {key}"
                )
                usage = {str(r[0]): int(r[1] or 0) for r in cur.fetchall()}
        if not usage and "client_traffics" in tables:
            ct_cols = _columns(cur, "client_traffics")
            key = _pick(ct_cols, ("email", "username"))
            if key and "up" in ct_cols and "down" in ct_cols:
                cur.execute(
                    f"SELECT {key}, SUM(COALESCE(up,0) + COALESCE(down,0)) "
                    f"FROM client_traffics GROUP BY {key}"
                )
                usage = {str(r[0]): int(r[1] or 0) for r in cur.fetchall()}

        rows: list[LegacyRow] = []
        cur.execute(f"SELECT * FROM {table}")
        for record in cur.fetchall():
            data = dict(record)
            raw_user = str(data.get(col_user) or "").strip()
            if not raw_user:
                continue
            username = raw_user.split("@")[0].lower()
            used = 0
            if col_id and str(data.get(col_id)) in usage:
                used = usage[str(data.get(col_id))]
            elif col_email and str(data.get(col_email)) in usage:
                used = usage[str(data.get(col_email))]
            elif raw_user in usage:
                used = usage[raw_user]
            elif "up" in data and "down" in data:
                used = int(data.get("up") or 0) + int(data.get("down") or 0)

            rows.append(
                LegacyRow(
                    username=username,
                    email=str(data.get(col_email) or raw_user),
                    password=str(data.get(col_pass) or ""),
                    uuid=str(data.get(col_uuid) or ""),
                    sub_id=str(data.get(col_sub) or username),
                    data_limit=int(data.get(col_limit) or 0),
                    used_traffic=used,
                    expire_at=_to_datetime(data.get(col_expire)),
                    enabled=bool(data.get(col_enable, 1)),
                    raw=data,
                )
            )
        return rows
    finally:
        conn.close()


def run_import(
    db: Session,
    db_path: str,
    *,
    group_id: int | None = None,
    inbound_ids: list[int] | None = None,
    node_ids: list[int] | None = None,
    keep_sub_id: bool = True,
    keep_uuid: bool = True,
    keep_usage: bool = True,
    dry_run: bool = False,
    default_status: UserStatus = UserStatus.ACTIVE,
    owner_id: int | None = None,
) -> dict:
    rows = read_accounts(db_path)
    imported = updated = skipped = 0
    errors: list[str] = []
    touched: list[str] = []

    group = db.query(Group).get(group_id) if group_id else None
    inbounds = (
        db.query(Inbound).filter(Inbound.id.in_(inbound_ids)).all()
        if inbound_ids
        else []
    )
    nodes = db.query(Node).filter(Node.id.in_(node_ids)).all() if node_ids else []

    for row in rows:
        try:
            snapshot = (
                db.query(LegacyAccount)
                .filter(LegacyAccount.username == row.username)
                .one_or_none()
            )
            if snapshot is None:
                snapshot = LegacyAccount(username=row.username)
                db.add(snapshot)
            snapshot.email = row.email
            snapshot.password = row.password
            snapshot.uuid = row.uuid
            snapshot.sub_id = row.sub_id
            snapshot.data_limit = row.data_limit
            snapshot.used_traffic = row.used_traffic
            snapshot.expire_at = row.expire_at
            snapshot.enabled = row.enabled
            snapshot.raw = {k: str(v) for k, v in (row.raw or {}).items()}
            snapshot.imported_at = utcnow()

            existing = (
                db.query(User).filter(User.username == row.username).one_or_none()
            )
            status = default_status if row.enabled else UserStatus.DISABLED

            if existing:
                existing.data_limit = row.data_limit
                if keep_usage:
                    existing.used_traffic = row.used_traffic
                    existing.lifetime_used_traffic = max(
                        existing.lifetime_used_traffic, row.used_traffic
                    )
                existing.expire_at = row.expire_at
                existing.status = status
                existing.legacy_source = "vpn-ui"
                existing.legacy_id = row.username
                if row.password:
                    existing.password = row.password
                if keep_uuid and row.uuid:
                    existing.uuid = row.uuid
                if group and existing.group_id is None:
                    existing.group_id = group.id
                if inbounds and not existing.inbounds:
                    existing.inbounds = inbounds
                if nodes and not existing.nodes:
                    existing.nodes = nodes
                snapshot.claimed_user_id = existing.id
                snapshot.claimed_at = utcnow()
                db.add(existing)
                updated += 1
                touched.append(row.username)
                continue

            if dry_run:
                imported += 1
                touched.append(row.username)
                continue

            user = user_service.create_user(
                db,
                username=row.username,
                password=row.password,
                uuid=row.uuid if keep_uuid else "",
                sub_id=row.sub_id if keep_sub_id else "",
                group_id=group.id if group else None,
                data_limit=row.data_limit,
                expire_at=row.expire_at,
                status=status,
                email=row.email,
                owner_id=owner_id,
                inbound_ids=[i.id for i in inbounds] or None,
                node_ids=[n.id for n in nodes] or None,
                legacy_source="vpn-ui",
                legacy_id=row.username,
                used_traffic=row.used_traffic if keep_usage else 0,
            )
            snapshot.claimed_user_id = user.id
            snapshot.claimed_at = utcnow()
            imported += 1
            touched.append(row.username)
        except Exception as exc:  # noqa: BLE001
            skipped += 1
            errors.append(f"{row.username}: {exc}")
            logger.warning("import failed for %s: %s", row.username, exc)

    if dry_run:
        db.rollback()
    else:
        db.commit()

    return {
        "imported": imported,
        "updated": updated,
        "skipped": skipped,
        "errors": errors[:50],
        "users": touched[:200],
    }


def claim(db: Session, username: str, password: str = "") -> User | None:
    """Self-service migration: an end user proves ownership of an old account."""
    username = username.strip().lower().split("@")[0]
    snapshot = (
        db.query(LegacyAccount).filter(LegacyAccount.username == username).one_or_none()
    )
    if snapshot is None:
        return None
    if snapshot.password and password and snapshot.password != password:
        return None
    if snapshot.claimed_user_id:
        return db.query(User).get(snapshot.claimed_user_id)

    user = db.query(User).filter(User.username == username).one_or_none()
    if user is None:
        user = user_service.create_user(
            db,
            username=username,
            password=snapshot.password,
            uuid=snapshot.uuid,
            sub_id=snapshot.sub_id,
            data_limit=snapshot.data_limit,
            expire_at=snapshot.expire_at,
            status=UserStatus.ACTIVE if snapshot.enabled else UserStatus.DISABLED,
            email=snapshot.email,
            legacy_source="vpn-ui",
            legacy_id=username,
            used_traffic=snapshot.used_traffic,
        )
    snapshot.claimed_user_id = user.id
    snapshot.claimed_at = utcnow()
    db.commit()
    return user
