"""OpenConnect / Cisco AnyConnect (ocserv) helpers."""
from __future__ import annotations

from typing import Sequence

from app.models import Inbound, Node, User

DEFAULTS = {
    "port": 8443,
    "subnet": "10.30.0.0",
    "mask": "255.255.255.0",
    "mtu": 1280,
    "dns": ["1.1.1.1", "8.8.8.8"],
    "max_same": 0,
    "udp": True,
}


def server_options(inbound: Inbound, port_override: int | None = None) -> dict:
    opts = dict(DEFAULTS)
    opts.update({k: v for k, v in (inbound.settings or {}).items() if v not in (None, "")})
    opts["port"] = port_override or inbound.port or opts["port"]
    if inbound.settings and "device_limit" in inbound.settings:
        opts["max_same"] = inbound.settings["device_limit"]
    return opts


def build_payload(inbound: Inbound, users: Sequence[User],
                  port_override: int | None = None,
                  include_server: bool = True) -> dict:
    payload = {
        "users": [
            {"username": u.username, "password": u.password} for u in users if u.password
        ]
    }
    if include_server:
        payload["server"] = server_options(inbound, port_override)
    return payload


def credentials(inbound: Inbound, node: Node, user: User,
                port_override: int | None = None,
                address_override: str = "") -> dict:
    opts = server_options(inbound, port_override)
    return {
        "host": address_override or node.endpoint,
        "port": opts["port"],
        "username": user.username,
        "password": user.password,
        "hint": "در اپلیکیشن Cisco AnyConnect یا OpenConnect آدرس را به شکل "
                f"{address_override or node.endpoint}:{opts['port']} وارد کنید.",
    }
