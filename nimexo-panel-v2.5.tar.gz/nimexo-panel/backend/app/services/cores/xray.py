"""Build an Xray-core configuration out of the panel's inbounds and users."""
from __future__ import annotations

from typing import Iterable, Sequence

from app.models import Inbound, User
from app.models.enums import Network, Protocol, Security

API_PORT = 10085
API_TAG = "api"

# Keeps users from reaching the node's own LAN / loopback services.
PRIVATE_RANGES = [
    "0.0.0.0/8",
    "10.0.0.0/8",
    "100.64.0.0/10",
    "127.0.0.0/8",
    "169.254.0.0/16",
    "172.16.0.0/12",
    "192.168.0.0/16",
    "::1/128",
    "fc00::/7",
    "fe80::/10",
]


def _v(value) -> str:
    """Accept either an enum member or a plain string."""
    return getattr(value, "value", value)


# --------------------------------------------------------------------------
# stream settings
# --------------------------------------------------------------------------
def build_stream_settings(inbound: Inbound) -> dict:
    stream: dict = {"network": _v(inbound.network)}

    if inbound.network == Network.WS:
        ws: dict = {"path": inbound.path or "/"}
        if inbound.host:
            ws["headers"] = {"Host": inbound.host}
        stream["wsSettings"] = ws
    elif inbound.network == Network.GRPC:
        stream["grpcSettings"] = {
            "serviceName": inbound.service_name or "",
            "multiMode": bool(inbound.settings.get("multi_mode", False)),
        }
    elif inbound.network == Network.HTTPUPGRADE:
        hu: dict = {"path": inbound.path or "/"}
        if inbound.host:
            hu["host"] = inbound.host
        stream["httpupgradeSettings"] = hu
    elif inbound.network == Network.XHTTP:
        xh: dict = {"path": inbound.path or "/", "mode": inbound.settings.get("mode", "auto")}
        if inbound.host:
            xh["host"] = inbound.host
        stream["xhttpSettings"] = xh
    elif inbound.network == Network.H2:
        stream["httpSettings"] = {
            "path": inbound.path or "/",
            "host": [inbound.host] if inbound.host else [],
        }
    elif inbound.network == Network.KCP:
        stream["kcpSettings"] = {
            "mtu": inbound.settings.get("mtu", 1350),
            "tti": inbound.settings.get("tti", 50),
            "uplinkCapacity": inbound.settings.get("uplink", 5),
            "downlinkCapacity": inbound.settings.get("downlink", 20),
            "congestion": inbound.settings.get("congestion", False),
            "readBufferSize": 2,
            "writeBufferSize": 2,
            "header": {"type": inbound.header_type or "none"},
            "seed": inbound.settings.get("seed", ""),
        }
    elif inbound.network == Network.TCP and inbound.header_type == "http":
        stream["tcpSettings"] = {
            "header": {
                "type": "http",
                "request": {
                    "path": [inbound.path or "/"],
                    "headers": {"Host": [inbound.host]} if inbound.host else {},
                },
            }
        }

    if inbound.security == Security.TLS:
        tls: dict = {
            "serverName": inbound.sni or "",
            "certificates": [
                {
                    "certificateFile": inbound.cert_path,
                    "keyFile": inbound.key_path,
                }
            ]
            if inbound.cert_path
            else [],
            "minVersion": "1.2",
        }
        if inbound.alpn:
            tls["alpn"] = [a.strip() for a in inbound.alpn.split(",") if a.strip()]
        stream["security"] = "tls"
        stream["tlsSettings"] = tls
    elif inbound.security == Security.REALITY:
        dest = inbound.reality_dest or f"{inbound.sni or 'www.google.com'}:443"
        stream["security"] = "reality"
        stream["realitySettings"] = {
            "show": False,
            "dest": dest,
            "xver": 0,
            "serverNames": inbound.reality_server_names
            or ([inbound.sni] if inbound.sni else []),
            "privateKey": inbound.reality_private_key,
            "shortIds": inbound.reality_short_ids or [""],
        }
    else:
        stream["security"] = "none"

    return stream


# --------------------------------------------------------------------------
# clients
# --------------------------------------------------------------------------
def client_entry(inbound: Inbound, user: User) -> dict | None:
    email = user.username
    if inbound.protocol == Protocol.VLESS:
        entry = {"id": user.uuid, "email": email, "level": 0}
        if inbound.flow:
            entry["flow"] = inbound.flow
        return entry
    if inbound.protocol == Protocol.VMESS:
        return {"id": user.uuid, "email": email, "level": 0, "alterId": 0}
    if inbound.protocol == Protocol.TROJAN:
        return {"password": user.password or user.uuid, "email": email, "level": 0}
    if inbound.protocol == Protocol.SHADOWSOCKS:
        method = inbound.settings.get("method", "chacha20-ietf-poly1305")
        password = (
            user_ss_password(user, inbound) if method.startswith("2022") else
            (user.password or user.uuid)
        )
        return {"password": password, "email": email, "method": method, "level": 0}
    return None


def user_ss_password(user: User, inbound: Inbound) -> str:
    """Shadowsocks-2022 needs a base64 key of an exact length."""
    from app.utils.crypto import ss2022_password

    key_len = 16 if "128" in inbound.settings.get("method", "") else 32
    return ss2022_password(f"{user.username}:{user.uuid}", key_len)


def build_inbound(inbound: Inbound, users: Sequence[User],
                  port_override: int | None = None) -> dict:
    settings: dict = {}
    clients = [c for c in (client_entry(inbound, u) for u in users) if c]

    if inbound.protocol == Protocol.VLESS:
        settings = {"clients": clients, "decryption": "none"}
        if inbound.settings.get("fallbacks"):
            settings["fallbacks"] = inbound.settings["fallbacks"]
    elif inbound.protocol == Protocol.VMESS:
        settings = {"clients": clients}
    elif inbound.protocol == Protocol.TROJAN:
        settings = {"clients": clients}
        if inbound.settings.get("fallbacks"):
            settings["fallbacks"] = inbound.settings["fallbacks"]
    elif inbound.protocol == Protocol.SHADOWSOCKS:
        method = inbound.settings.get("method", "chacha20-ietf-poly1305")
        settings = {
            "clients": clients,
            "network": inbound.settings.get("network", "tcp,udp"),
        }
        if method.startswith("2022"):
            settings["method"] = method
            settings["password"] = inbound.settings.get("server_password", "")
        else:
            settings["method"] = method

    node_inbound = {
        "tag": inbound.tag,
        "listen": inbound.listen or None,
        "port": port_override or inbound.port,
        "protocol": _v(inbound.protocol),
        "settings": settings,
        "streamSettings": build_stream_settings(inbound),
    }
    if inbound.sniffing:
        node_inbound["sniffing"] = {
            "enabled": True,
            "destOverride": ["http", "tls", "quic"],
            "routeOnly": False,
        }
    if node_inbound["listen"] is None:
        node_inbound.pop("listen")
    return node_inbound


# --------------------------------------------------------------------------
# whole config
# --------------------------------------------------------------------------
def build_config(
    pairs: Iterable[tuple[Inbound, Sequence[User], int | None]],
    log_level: str = "warning",
    extra_outbounds: list | None = None,
    routing_rules: list | None = None,
) -> dict:
    inbounds = [
        {
            "tag": API_TAG,
            "listen": "127.0.0.1",
            "port": API_PORT,
            "protocol": "dokodemo-door",
            "settings": {"address": "127.0.0.1"},
        }
    ]
    for inbound, users, port_override in pairs:
        inbounds.append(build_inbound(inbound, users, port_override))

    outbounds = [
        {"protocol": "freedom", "tag": "direct", "settings": {}},
        {"protocol": "blackhole", "tag": "blocked", "settings": {}},
    ]
    if extra_outbounds:
        outbounds.extend(extra_outbounds)

    rules = [
        {"type": "field", "inboundTag": [API_TAG], "outboundTag": API_TAG},
        {"type": "field", "protocol": ["bittorrent"], "outboundTag": "blocked"},
        # Written out as plain CIDRs on purpose: "geoip:private" needs
        # geoip.dat next to the binary, and a missing asset makes Xray reject
        # the whole config instead of just this rule.
        {"type": "field", "ip": PRIVATE_RANGES, "outboundTag": "blocked"},
    ]
    if routing_rules:
        rules.extend(routing_rules)

    return {
        "log": {"loglevel": log_level, "access": "none"},
        "api": {"tag": API_TAG, "services": ["HandlerService", "StatsService"]},
        "stats": {},
        "policy": {
            "levels": {
                "0": {
                    "statsUserUplink": True,
                    "statsUserDownlink": True,
                    "handshake": 4,
                    "connIdle": 300,
                }
            },
            "system": {
                "statsInboundUplink": True,
                "statsInboundDownlink": True,
                "statsOutboundUplink": True,
                "statsOutboundDownlink": True,
            },
        },
        "inbounds": inbounds,
        "outbounds": outbounds,
        "routing": {"domainStrategy": "AsIs", "rules": rules},
    }
