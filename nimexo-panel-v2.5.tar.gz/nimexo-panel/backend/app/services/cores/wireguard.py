"""WireGuard helpers: key material, address allocation, node payloads."""
from __future__ import annotations

import base64
import ipaddress
from typing import Sequence

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from sqlalchemy.orm import Session

from app.models import Inbound, User, UserCredential

DEFAULT_SUBNET = "10.66.0.0/24"
DEFAULT_MTU = 1280
DEFAULT_DNS = "1.1.1.1, 8.8.8.8"


def generate_keypair() -> tuple[str, str]:
    private = X25519PrivateKey.generate()
    priv_raw = private.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_raw = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(priv_raw).decode(), base64.b64encode(pub_raw).decode()


def public_from_private(private_b64: str) -> str:
    raw = base64.b64decode(private_b64)
    key = X25519PrivateKey.from_private_bytes(raw)
    return base64.b64encode(
        key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
    ).decode()


def interface_name(inbound: Inbound) -> str:
    """Kernel interface names are limited to 15 characters."""
    slug = "".join(c for c in inbound.tag if c.isalnum())[:10]
    return f"nx-{slug or inbound.id}"


def ensure_server_keys(inbound: Inbound) -> tuple[str, str]:
    settings = dict(inbound.settings or {})
    if not settings.get("private_key"):
        priv, pub = generate_keypair()
        settings["private_key"] = priv
        settings["public_key"] = pub
        inbound.settings = settings
    elif not settings.get("public_key"):
        settings["public_key"] = public_from_private(settings["private_key"])
        inbound.settings = settings
    return inbound.settings["private_key"], inbound.settings["public_key"]


def _network(inbound: Inbound) -> ipaddress.IPv4Network:
    return ipaddress.ip_network(
        (inbound.settings or {}).get("subnet") or DEFAULT_SUBNET, strict=False
    )


def server_address(inbound: Inbound) -> str:
    net = _network(inbound)
    return f"{net.network_address + 1}/{net.prefixlen}"


def ensure_user_credential(db: Session, inbound: Inbound, user: User) -> dict:
    """Create (once) and return the user's WireGuard key pair and tunnel IP."""
    cred = (
        db.query(UserCredential)
        .filter(UserCredential.user_id == user.id, UserCredential.inbound_id == inbound.id)
        .one_or_none()
    )
    if cred and cred.data.get("private_key") and cred.data.get("ip"):
        return cred.data

    net = _network(inbound)
    taken = {
        c.data.get("ip")
        for c in db.query(UserCredential)
        .filter(UserCredential.inbound_id == inbound.id)
        .all()
        if c.data
    }
    taken.add(str(net.network_address + 1))  # server side
    address = None
    for host in net.hosts():
        candidate = str(host)
        if candidate not in taken:
            address = candidate
            break
    if address is None:
        raise RuntimeError(f"WireGuard subnet {net} for '{inbound.tag}' is exhausted")

    priv, pub = generate_keypair()
    data = {"private_key": priv, "public_key": pub, "ip": address}
    if cred:
        cred.data = data
    else:
        db.add(UserCredential(user_id=user.id, inbound_id=inbound.id, data=data))
    db.flush()
    return data


def build_interface_payload(
    db: Session, inbound: Inbound, users: Sequence[User], port_override: int | None = None
) -> dict:
    priv, _ = ensure_server_keys(inbound)
    net = _network(inbound)
    peers = []
    for user in users:
        cred = ensure_user_credential(db, inbound, user)
        peers.append(
            {
                "name": user.username,
                "public_key": cred["public_key"],
                "allowed_ips": f"{cred['ip']}/32",
            }
        )
    return {
        "name": interface_name(inbound),
        "private_key": priv,
        "address": server_address(inbound),
        "port": port_override or inbound.port,
        "mtu": (inbound.settings or {}).get("mtu", DEFAULT_MTU),
        "subnet": str(net),
        "peers": peers,
    }
