"""Thin, pooled SSH layer used to drive the nodes.

Design notes
------------
* The panel never opens a listening port on the node. Everything happens over
  the node's existing SSH port, which keeps the attack surface (and the amount
  of traffic a censor can fingerprint) minimal.
* The host key is pinned the first time a node is added and verified on every
  later connection, so a hijacked route cannot silently MITM the panel.
* Connections are cached per node and reused; a broken channel is transparently
  reopened on the next call.
"""
from __future__ import annotations

import base64
import hashlib
import io
import logging
import threading
import time
from dataclasses import dataclass
from typing import Optional

import paramiko

logger = logging.getLogger(__name__)

CONNECT_TIMEOUT = 15
COMMAND_TIMEOUT = 120


class SSHError(RuntimeError):
    pass


class HostKeyMismatch(SSHError):
    pass


@dataclass
class SSHTarget:
    host: str
    port: int = 22
    username: str = "root"
    password: str = ""
    private_key: str = ""
    key_passphrase: str = ""
    host_key: str = ""          # pinned "SHA256:xxxx" fingerprint
    node_id: Optional[int] = None

    @property
    def cache_key(self) -> str:
        return f"{self.node_id or ''}:{self.username}@{self.host}:{self.port}"


@dataclass
class CommandResult:
    exit_code: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.exit_code == 0

    def raise_for_status(self, context: str = "") -> "CommandResult":
        if not self.ok:
            msg = (self.stderr or self.stdout or "").strip()[:2000]
            raise SSHError(f"{context or 'command'} failed ({self.exit_code}): {msg}")
        return self


def fingerprint(key: paramiko.PKey) -> str:
    digest = hashlib.sha256(key.asbytes()).digest()
    return "SHA256:" + base64.b64encode(digest).decode().rstrip("=")


class _PinnedPolicy(paramiko.MissingHostKeyPolicy):
    """Accept the key on first use, otherwise compare with the pinned value."""

    def __init__(self, expected: str, learned: list[str]):
        self.expected = expected
        self.learned = learned

    def missing_host_key(self, client, hostname, key):  # noqa: D401
        fp = fingerprint(key)
        if self.expected and fp != self.expected:
            raise HostKeyMismatch(
                f"host key for {hostname} changed: expected {self.expected}, got {fp}"
            )
        self.learned.append(fp)


def _load_key(material: str, passphrase: str = ""):
    material = material.strip()
    errors = []
    for cls in (
        paramiko.Ed25519Key,
        paramiko.ECDSAKey,
        paramiko.RSAKey,
        paramiko.DSSKey,
    ):
        try:
            return cls.from_private_key(io.StringIO(material), password=passphrase or None)
        except Exception as exc:  # noqa: PERF203
            errors.append(f"{cls.__name__}: {exc}")
    raise SSHError("unsupported or malformed private key -> " + "; ".join(errors[:2]))


class SSHConnection:
    def __init__(self, target: SSHTarget):
        self.target = target
        self.client: paramiko.SSHClient | None = None
        self.learned_host_key: str = ""
        self._lock = threading.Lock()
        self._last_used = 0.0

    # -- lifecycle ---------------------------------------------------------
    def connect(self) -> paramiko.SSHClient:
        learned: list[str] = []
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(_PinnedPolicy(self.target.host_key, learned))

        kwargs = dict(
            hostname=self.target.host,
            port=self.target.port,
            username=self.target.username,
            timeout=CONNECT_TIMEOUT,
            banner_timeout=CONNECT_TIMEOUT,
            auth_timeout=CONNECT_TIMEOUT,
            allow_agent=False,
            look_for_keys=False,
        )
        if self.target.private_key:
            kwargs["pkey"] = _load_key(self.target.private_key, self.target.key_passphrase)
        else:
            kwargs["password"] = self.target.password

        try:
            client.connect(**kwargs)
        except HostKeyMismatch:
            raise
        except paramiko.AuthenticationException as exc:
            raise SSHError("Authentication failed — check the SSH username/password (or key)") from exc
        except Exception as exc:
            raise SSHError(f"cannot connect to {self.target.host}:{self.target.port}: {exc}") from exc

        if learned:
            self.learned_host_key = learned[0]
        self.client = client
        self._last_used = time.time()
        return client

    def _ensure(self) -> paramiko.SSHClient:
        if self.client is not None:
            transport = self.client.get_transport()
            if transport is not None and transport.is_active():
                return self.client
            self.close()
        return self.connect()

    def close(self) -> None:
        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass
        self.client = None

    # -- operations --------------------------------------------------------
    def run(self, command: str, stdin_data: str | None = None,
            timeout: int = COMMAND_TIMEOUT) -> CommandResult:
        with self._lock:
            client = self._ensure()
            chan_stdin, chan_out, chan_err = client.exec_command(command, timeout=timeout)
            if stdin_data is not None:
                chan_stdin.write(stdin_data)
                chan_stdin.channel.shutdown_write()
            out = chan_out.read().decode("utf-8", "replace")
            err = chan_err.read().decode("utf-8", "replace")
            code = chan_out.channel.recv_exit_status()
            self._last_used = time.time()
            return CommandResult(code, out, err)

    def sudo(self, command: str, **kw) -> CommandResult:
        """Run as root; uses sudo -n when not already root."""
        if self.target.username == "root":
            return self.run(command, **kw)
        return self.run(f"sudo -n bash -c {shell_quote(command)}", **kw)

    def write_file(self, path: str, content: str, mode: str = "600") -> CommandResult:
        """Atomically write a file on the node (content streamed over stdin)."""
        cmd = (
            f"set -e; mkdir -p $(dirname {shell_quote(path)}); "
            f"tmp=$(mktemp); cat > $tmp; chmod {mode} $tmp; "
            f"mv $tmp {shell_quote(path)}"
        )
        return self.sudo(cmd, stdin_data=content)

    def upload(self, path: str, content: bytes, mode: int = 0o600) -> None:
        with self._lock:
            client = self._ensure()
            sftp = client.open_sftp()
            try:
                parts = path.strip("/").split("/")[:-1]
                cur = ""
                for p in parts:
                    cur += "/" + p
                    try:
                        sftp.stat(cur)
                    except IOError:
                        sftp.mkdir(cur)
                with sftp.file(path, "wb") as fh:
                    fh.write(content)
                sftp.chmod(path, mode)
            finally:
                sftp.close()


def shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


class SSHPool:
    """Process-wide cache of SSH connections keyed by node."""

    def __init__(self) -> None:
        self._conns: dict[str, SSHConnection] = {}
        self._lock = threading.Lock()

    def get(self, target: SSHTarget) -> SSHConnection:
        with self._lock:
            conn = self._conns.get(target.cache_key)
            if conn is None or conn.target != target:
                if conn is not None:
                    conn.close()
                conn = SSHConnection(target)
                self._conns[target.cache_key] = conn
            return conn

    def drop(self, target: SSHTarget) -> None:
        with self._lock:
            conn = self._conns.pop(target.cache_key, None)
        if conn:
            conn.close()

    def close_all(self) -> None:
        with self._lock:
            conns = list(self._conns.values())
            self._conns.clear()
        for c in conns:
            c.close()


pool = SSHPool()
