"""Reseller accounting.

A reseller buys traffic credit up front. Everything their users consume is
charged against that credit; when it runs out their users stop working until
more credit is added.

Usage is always *derived* from the users' own counters rather than kept as a
separate running total, so it can never drift out of sync with reality.
"""
from __future__ import annotations

import logging

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models import Admin, ResellerTransaction, User, utcnow
from app.models.enums import AdminRole, UserStatus

logger = logging.getLogger(__name__)


def usage_of(db: Session, admin: Admin) -> int:
    """Total bytes consumed by every account this reseller owns."""
    total = (
        db.query(func.coalesce(func.sum(User.lifetime_used_traffic), 0))
        .filter(User.owner_id == admin.id)
        .scalar()
    )
    return int(total or 0)


def summary(db: Session, admin: Admin) -> dict:
    used = usage_of(db, admin)
    quota = admin.traffic_quota or 0
    users = db.query(User).filter(User.owner_id == admin.id).all()
    active = [u for u in users if u.status in (UserStatus.ACTIVE, UserStatus.ON_HOLD)]
    return {
        "id": admin.id,
        "username": admin.username,
        "role": admin.role.value,
        "is_active": admin.is_active,
        "note": admin.note,
        "telegram_id": admin.telegram_id,
        "traffic_quota": quota,
        "traffic_used": used,
        "traffic_remaining": max(0, quota - used) if quota else None,
        "exhausted": bool(quota and used >= quota),
        "user_quota": admin.user_quota,
        "users_total": len(users),
        "users_active": len(active),
        "expire_at": admin.expire_at,
        "suspend_on_exhausted": admin.suspend_on_exhausted,
        "allowed_group_ids": admin.allowed_group_ids or [],
        "allowed_inbound_ids": admin.allowed_inbound_ids or [],
        "allowed_node_ids": admin.allowed_node_ids or [],
        "created_at": admin.created_at,
        "last_login_at": admin.last_login_at,
    }


def add_credit(db: Session, admin: Admin, amount: int, *, price: int = 0,
               note: str = "", actor: str = "") -> ResellerTransaction:
    """Grant (or claw back, with a negative amount) traffic credit."""
    admin.traffic_quota = max(0, (admin.traffic_quota or 0) + amount)
    tx = ResellerTransaction(
        admin_id=admin.id,
        amount=amount,
        balance_after=admin.traffic_quota,
        price=price,
        kind="credit" if amount >= 0 else "debit",
        note=note,
        created_by=actor,
    )
    db.add(admin)
    db.add(tx)
    db.commit()
    return tx


def can_create_user(db: Session, admin: Admin) -> tuple[bool, str]:
    if admin.role != AdminRole.RESELLER:
        return True, ""
    if not admin.is_active:
        return False, "حساب نمایندگی غیرفعال است"
    if admin.expire_at and admin.expire_at <= utcnow():
        return False, "اعتبار زمانی نمایندگی تمام شده است"
    if admin.user_quota:
        count = db.query(User).filter(User.owner_id == admin.id).count()
        if count >= admin.user_quota:
            return False, f"سقف {admin.user_quota} کاربر پر شده است"
    if admin.traffic_quota and usage_of(db, admin) >= admin.traffic_quota:
        return False, "حجم خریداری‌شده تمام شده است"
    return True, ""


def enforce_quotas(db: Session) -> dict:
    """Suspend or restore each reseller's users based on remaining credit."""
    changed: dict[str, list[str]] = {"suspended": [], "restored": []}

    for admin in db.query(Admin).filter(Admin.role == AdminRole.RESELLER).all():
        quota = admin.traffic_quota or 0
        if not quota or not admin.suspend_on_exhausted:
            continue
        exhausted = usage_of(db, admin) >= quota
        expired = bool(admin.expire_at and admin.expire_at <= utcnow())
        should_stop = exhausted or expired or not admin.is_active

        users = db.query(User).filter(User.owner_id == admin.id).all()
        for user in users:
            if should_stop and user.status == UserStatus.ACTIVE:
                user.status = UserStatus.DISABLED
                user.suspended_by_system = True
                db.add(user)
                changed["suspended"].append(user.username)
            elif (
                not should_stop
                and user.status == UserStatus.DISABLED
                # only bring back accounts the panel itself suspended
                and user.suspended_by_system
                and (not user.expire_at or user.expire_at > utcnow())
                and (not user.data_limit or user.used_traffic < user.data_limit)
            ):
                user.status = UserStatus.ACTIVE
                user.suspended_by_system = False
                db.add(user)
                changed["restored"].append(user.username)

    db.commit()
    return {k: v for k, v in changed.items() if v}
