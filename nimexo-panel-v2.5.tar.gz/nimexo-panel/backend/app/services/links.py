"""Client-facing config generation (share links, WireGuard/OpenVPN files)."""
from __future__ import annotations

import base64
import json
from urllib.parse import quote, urlencode

from sqlalchemy.orm import Session

from app.models import Inbound, Node, NodeInbound, User
from app.models.enums import Network, Protocol, Security
from app.services.cores import wireguard as wg
from app.services.cores.xray import _v, user_ss_password


def _b64(text: str) -> str:
    return base64.urlsafe_b64encode(text.encode()).decode().rstrip("=")


def endpoint_for(node: Node, node_inbound: NodeInbound | None, inbound: Inbound) -> tuple[str, int]:
    host = node.endpoint
    port = inbound.port
    if node_inbound:
        host = node_inbound.address_override or host
        port = node_inbound.port_override or port
    return host, port


def remark_for(user: User, node: Node, inbound: Inbound) -> str:
    label = inbound.remark or inbound.tag
    flag = f"{node.country} " if node.country else ""
    return f"{flag}{node.name} · {label}"


def _stream_params(inbound: Inbound) -> dict:
    params: dict[str, str] = {"type": _v(inbound.network)}

    if inbound.network == Network.WS:
        params["path"] = inbound.path or "/"
        if inbound.host:
            params["host"] = inbound.host
    elif inbound.network == Network.GRPC:
        params["serviceName"] = inbound.service_name or ""
        params["mode"] = "multi" if (inbound.settings or {}).get("multi_mode") else "gun"
    elif inbound.network in (Network.HTTPUPGRADE, Network.XHTTP):
        params["path"] = inbound.path or "/"
        if inbound.host:
            params["host"] = inbound.host
        if inbound.network == Network.XHTTP:
            params["mode"] = (inbound.settings or {}).get("mode", "auto")
    elif inbound.network == Network.KCP:
        params["headerType"] = inbound.header_type or "none"
        if (inbound.settings or {}).get("seed"):
            params["seed"] = inbound.settings["seed"]
    elif inbound.network == Network.TCP and inbound.header_type == "http":
        params["headerType"] = "http"
        params["path"] = inbound.path or "/"
        if inbound.host:
            params["host"] = inbound.host

    if inbound.security == Security.REALITY:
        params.update(
            {
                "security": "reality",
                "pbk": inbound.reality_public_key,
                "fp": inbound.fingerprint or "chrome",
                "sni": inbound.sni or (inbound.reality_server_names or [""])[0],
                "sid": (inbound.reality_short_ids or [""])[0],
                "spx": "/",
            }
        )
    elif inbound.security == Security.TLS:
        params["security"] = "tls"
        if inbound.sni:
            params["sni"] = inbound.sni
        if inbound.fingerprint:
            params["fp"] = inbound.fingerprint
        if inbound.alpn:
            params["alpn"] = inbound.alpn
        if inbound.allow_insecure:
            params["allowInsecure"] = "1"
    else:
        params["security"] = "none"

    return {k: v for k, v in params.items() if v not in ("", None)}


def build_share_link(user: User, inbound: Inbound, node: Node,
                     node_inbound: NodeInbound | None = None) -> str | None:
    host, port = endpoint_for(node, node_inbound, inbound)
    remark = remark_for(user, node, inbound)

    if inbound.protocol == Protocol.VLESS:
        params = _stream_params(inbound)
        if inbound.flow:
            params["flow"] = inbound.flow
        return f"vless://{user.uuid}@{host}:{port}?{urlencode(params)}#{quote(remark)}"

    if inbound.protocol == Protocol.VMESS:
        params = _stream_params(inbound)
        payload = {
            "v": "2",
            "ps": remark,
            "add": host,
            "port": str(port),
            "id": user.uuid,
            "aid": "0",
            "scy": "auto",
            "net": _v(inbound.network),
            "type": inbound.header_type or "none",
            "host": inbound.host or params.get("host", ""),
            "path": inbound.path or params.get("path", ""),
            "tls": "tls" if inbound.security == Security.TLS else "",
            "sni": inbound.sni or "",
            "fp": inbound.fingerprint or "",
        }
        if inbound.network == Network.GRPC:
            payload["path"] = inbound.service_name or ""
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        return "vmess://" + base64.b64encode(raw.encode()).decode()

    if inbound.protocol == Protocol.TROJAN:
        params = _stream_params(inbound)
        password = user.password or user.uuid
        return (
            f"trojan://{quote(password)}@{host}:{port}?{urlencode(params)}"
            f"#{quote(remark)}"
        )

    if inbound.protocol == Protocol.SHADOWSOCKS:
        method = (inbound.settings or {}).get("method", "chacha20-ietf-poly1305")
        if method.startswith("2022"):
            server_pw = (inbound.settings or {}).get("server_password", "")
            password = f"{server_pw}:{user_ss_password(user, inbound)}"
        else:
            password = user.password or user.uuid
        userinfo = base64.b64encode(f"{method}:{password}".encode()).decode().rstrip("=")
        return f"ss://{userinfo}@{host}:{port}#{quote(remark)}"

    return None


def build_wireguard_config(db: Session, user: User, inbound: Inbound, node: Node,
                           node_inbound: NodeInbound | None = None) -> str:
    cred = wg.ensure_user_credential(db, inbound, user)
    _, server_pub = wg.ensure_server_keys(inbound)
    host, port = endpoint_for(node, node_inbound, inbound)
    settings = inbound.settings or {}
    net = settings.get("subnet", wg.DEFAULT_SUBNET)
    prefix = net.split("/")[-1] if "/" in net else "24"
    lines = [
        "[Interface]",
        f"PrivateKey = {cred['private_key']}",
        f"Address = {cred['ip']}/{prefix}",
        f"DNS = {settings.get('dns', wg.DEFAULT_DNS)}",
        f"MTU = {settings.get('mtu', wg.DEFAULT_MTU)}",
        "",
        "[Peer]",
        f"PublicKey = {server_pub}",
        f"Endpoint = {host}:{port}",
        f"AllowedIPs = {settings.get('allowed_ips', '0.0.0.0/0, ::/0')}",
        "PersistentKeepalive = 25",
    ]
    return "\n".join(lines) + "\n"


def build_subscription_links(db: Session, user: User, nodes: list[Node],
                             inbounds: list[Inbound]) -> list[str]:
    """One share link per (enabled inbound × node it is deployed on)."""
    links: list[str] = []
    by_key = {
        (ni.inbound_id, ni.node_id): ni
        for ni in db.query(NodeInbound).all()
    }
    for node in sorted(nodes, key=lambda n: (n.sort_order, n.id)):
        if not node.is_enabled:
            continue
        for inbound in sorted(inbounds, key=lambda i: (i.sort_order, i.id)):
            ni = by_key.get((inbound.id, node.id))
            if ni is None or not ni.is_enabled or not inbound.is_enabled:
                continue
            link = build_share_link(user, inbound, node, ni)
            if link:
                links.append(link)
    return links
