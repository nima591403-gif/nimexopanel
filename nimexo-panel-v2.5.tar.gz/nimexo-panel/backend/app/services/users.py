"""User lifecycle helpers shared by the API, the migration tool and jobs."""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy.orm import Session

from app.config import settings
from app.models import Group, Inbound, Node, User, utcnow
from app.models.enums import UserStatus
from app.utils.crypto import new_uuid, random_password, random_token


def subscription_url(user: User) -> str:
    from app.services import settings_store

    return f"{settings_store.sub_base_url()}/{user.sub_id}"


def unique_sub_id(db: Session, preferred: str = "") -> str:
    candidate = (preferred or random_token(16)).strip()
    while db.query(User).filter(User.sub_id == candidate).first() is not None:
        candidate = random_token(16)
    return candidate


def apply_group_defaults(user: User, group: Group | None) -> None:
    if group is None:
        return
    if not user.data_limit:
        user.data_limit = group.data_limit
    if not user.device_limit:
        user.device_limit = group.device_limit
    if group.data_limit_strategy:
        user.data_limit_strategy = group.data_limit_strategy
    if group.on_hold:
        user.status = UserStatus.ON_HOLD
        user.on_hold_duration_days = user.on_hold_duration_days or group.duration_days
    elif user.expire_at is None and group.duration_days:
        user.expire_at = utcnow() + timedelta(days=group.duration_days)


def attach_relations(db: Session, user: User, inbound_ids: list[int] | None,
                     node_ids: list[int] | None) -> None:
    if inbound_ids is not None:
        user.inbounds = (
            db.query(Inbound).filter(Inbound.id.in_(inbound_ids)).all()
            if inbound_ids
            else []
        )
    if node_ids is not None:
        user.nodes = (
            db.query(Node).filter(Node.id.in_(node_ids)).all() if node_ids else []
        )


def create_user(
    db: Session,
    *,
    username: str,
    password: str = "",
    uuid: str = "",
    sub_id: str = "",
    group_id: int | None = None,
    data_limit: int = 0,
    device_limit: int = 0,
    expire_at=None,
    duration_days: int | None = None,
    on_hold_duration_days: int = 0,
    status: UserStatus = UserStatus.ACTIVE,
    note: str = "",
    email: str = "",
    telegram_id: int | None = None,
    owner_id: int | None = None,
    inbound_ids: list[int] | None = None,
    node_ids: list[int] | None = None,
    data_limit_strategy=None,
    legacy_source: str = "",
    legacy_id: str = "",
    used_traffic: int = 0,
) -> User:
    group = db.query(Group).get(group_id) if group_id else None
    if expire_at is None and duration_days:
        expire_at = utcnow() + timedelta(days=duration_days)

    user = User(
        username=username.strip().lower(),
        password=password or random_password(10),
        uuid=uuid or new_uuid(),
        sub_id=unique_sub_id(db, sub_id),
        group_id=group_id,
        owner_id=owner_id,
        data_limit=data_limit,
        device_limit=device_limit,
        expire_at=expire_at,
        on_hold_duration_days=on_hold_duration_days,
        status=status,
        note=note,
        email=email,
        telegram_id=telegram_id,
        used_traffic=used_traffic,
        lifetime_used_traffic=used_traffic,
        legacy_source=legacy_source,
        legacy_id=legacy_id,
    )
    if data_limit_strategy is not None:
        user.data_limit_strategy = data_limit_strategy
    apply_group_defaults(user, group)
    db.add(user)
    db.flush()
    attach_relations(db, user, inbound_ids, node_ids)
    db.flush()
    return user


def serialize(db: Session, user: User, online_ids: set[int] | None = None) -> dict:
    return {
        "id": user.id,
        "username": user.username,
        "password": user.password,
        "uuid": user.uuid,
        "sub_id": user.sub_id,
        "email": user.email,
        "note": user.note,
        "telegram_id": user.telegram_id,
        "group_id": user.group_id,
        "group_name": user.group.name if user.group else None,
        "owner_id": user.owner_id,
        "status": user.status,
        "data_limit": user.data_limit,
        "used_traffic": user.used_traffic,
        "lifetime_used_traffic": user.lifetime_used_traffic,
        "data_limit_strategy": user.data_limit_strategy,
        "device_limit": user.device_limit,
        "expire_at": user.expire_at,
        "created_at": user.created_at,
        "online_at": user.online_at,
        "is_online": user.id in (online_ids or set()),
        "subscription_url": subscription_url(user),
        "inbound_ids": [i.id for i in user.inbounds],
        "node_ids": [n.id for n in user.nodes],
    }
