"""Secret handling: password hashing, JWT and credential encryption."""
import base64
import hashlib
import secrets
import uuid as _uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
from cryptography.fernet import Fernet, InvalidToken
from passlib.context import CryptContext

from app.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# --------------------------------------------------------------------------
# passwords
# --------------------------------------------------------------------------
def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return pwd_context.verify(plain, hashed)
    except Exception:
        return False


# --------------------------------------------------------------------------
# jwt
# --------------------------------------------------------------------------
def create_access_token(subject: str, extra: dict | None = None,
                        expires_minutes: int | None = None) -> str:
    exp_minutes = expires_minutes or settings.ACCESS_TOKEN_EXPIRE_MINUTES
    payload: dict[str, Any] = {
        "sub": subject,
        "iat": datetime.now(timezone.utc),
        "exp": datetime.now(timezone.utc) + timedelta(minutes=exp_minutes),
    }
    if extra:
        payload.update(extra)
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
    except jwt.PyJWTError:
        return None


# --------------------------------------------------------------------------
# node credential encryption (Fernet, key derived from CREDENTIAL_KEY)
# --------------------------------------------------------------------------
def _fernet() -> Fernet:
    raw = settings.CREDENTIAL_KEY or settings.SECRET_KEY
    key = base64.urlsafe_b64encode(hashlib.sha256(raw.encode()).digest())
    return Fernet(key)


def encrypt_secret(value: str) -> str:
    if not value:
        return ""
    return _fernet().encrypt(value.encode()).decode()


def decrypt_secret(value: str) -> str:
    if not value:
        return ""
    try:
        return _fernet().decrypt(value.encode()).decode()
    except (InvalidToken, ValueError):
        return ""


# --------------------------------------------------------------------------
# identifiers
# --------------------------------------------------------------------------
def new_uuid() -> str:
    return str(_uuid.uuid4())


def uuid_from_seed(seed: str) -> str:
    """Deterministic UUID, used when migrating so old clients keep working."""
    return str(_uuid.uuid5(_uuid.NAMESPACE_DNS, seed))


def random_token(length: int = 16) -> str:
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def random_password(length: int = 10) -> str:
    return random_token(length)


def ss2022_password(seed: str | None = None, key_len: int = 32) -> str:
    """Shadowsocks-2022 requires a base64 key of an exact byte length."""
    material = (seed or secrets.token_hex(32)).encode()
    return base64.b64encode(hashlib.sha256(material).digest()[:key_len]).decode()
