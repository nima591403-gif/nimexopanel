"""A second, tiny HTTP listener that serves only the subscription endpoints.

Keeping the panel and the subscription on separate ports means only the
subscription port has to be exposed publicly (or forwarded through a relay),
while the admin panel can stay on a port you never publish.
"""
import logging
import threading

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse

from app.api.routes import subscription
from app.config import settings

logger = logging.getLogger(__name__)
_thread: threading.Thread | None = None
_server: uvicorn.Server | None = None


def build_app() -> FastAPI:
    app = FastAPI(title="Subscription", docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(
        CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
    )
    app.include_router(subscription.router)

    @app.get("/", include_in_schema=False)
    def root():
        return {"ok": True}

    @app.get("/u/{sub_id}", include_in_schema=False)
    def user_page(sub_id: str):
        """The status page itself is served by the panel, not this listener."""
        from app.services import settings_store

        return RedirectResponse(f"{settings_store.page_base_url()}/u/{sub_id}", 302)

    return app


def start() -> None:
    """Run the subscription listener when it is configured on its own port."""
    global _thread, _server
    port = settings.SUB_PORT
    if not port or port == settings.PORT or _thread is not None:
        return

    config = uvicorn.Config(
        build_app(),
        host=settings.HOST,
        port=port,
        log_level="warning",
        proxy_headers=True,
        forwarded_allow_ips="*",
    )
    _server = uvicorn.Server(config)
    _thread = threading.Thread(target=_server.run, daemon=True, name="subscription")
    _thread.start()
    logger.warning("subscription listener started on port %s", port)


def stop() -> None:
    if _server is not None:
        _server.should_exit = True
