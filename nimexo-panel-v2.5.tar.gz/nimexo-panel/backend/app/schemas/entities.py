"""Request/response models for the REST API."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator

from app.models.enums import (
    AdminRole,
    CoreType,
    DataLimitStrategy,
    GroupKind,
    Network,
    NodeStatus,
    Protocol,
    SSHAuthMethod,
    Security,
    UserStatus,
)
from app.schemas.common import ORMModel


# --------------------------------------------------------------------------
# admins
# --------------------------------------------------------------------------
class AdminBase(BaseModel):
    username: str
    role: AdminRole = AdminRole.ADMIN
    is_active: bool = True
    telegram_id: int | None = None
    note: str = ""
    traffic_quota: int = 0
    user_quota: int = 0
    expire_at: datetime | None = None


class AdminCreate(AdminBase):
    password: str = Field(min_length=6)


class AdminUpdate(BaseModel):
    password: str | None = None
    role: AdminRole | None = None
    is_active: bool | None = None
    telegram_id: int | None = None
    note: str | None = None
    traffic_quota: int | None = None
    user_quota: int | None = None
    expire_at: datetime | None = None


class AdminOut(AdminBase, ORMModel):
    id: int
    traffic_used: int = 0
    created_at: datetime
    last_login_at: datetime | None = None


# --------------------------------------------------------------------------
# inbounds
# --------------------------------------------------------------------------
class InboundBase(BaseModel):
    tag: str
    remark: str = ""
    core: CoreType
    protocol: Protocol
    listen: str = ""
    port: int = Field(ge=1, le=65535)
    network: Network = Network.TCP
    security: Security = Security.NONE
    sni: str = ""
    host: str = ""
    path: str = ""
    service_name: str = ""
    header_type: str = ""
    alpn: str = ""
    fingerprint: str = "chrome"
    flow: str = ""
    allow_insecure: bool = False
    reality_public_key: str = ""
    reality_private_key: str = ""
    reality_short_ids: list[str] = []
    reality_dest: str = ""
    reality_server_names: list[str] = []
    cert_path: str = ""
    key_path: str = ""
    settings: dict = {}
    stream_settings: dict = {}
    sniffing: bool = False
    is_enabled: bool = True
    is_default: bool = False
    sort_order: int = 0


class InboundCreate(InboundBase):
    node_ids: list[int] = []


class InboundUpdate(BaseModel):
    remark: str | None = None
    listen: str | None = None
    port: int | None = None
    network: Network | None = None
    security: Security | None = None
    sni: str | None = None
    host: str | None = None
    path: str | None = None
    service_name: str | None = None
    header_type: str | None = None
    alpn: str | None = None
    fingerprint: str | None = None
    flow: str | None = None
    allow_insecure: bool | None = None
    reality_public_key: str | None = None
    reality_private_key: str | None = None
    reality_short_ids: list[str] | None = None
    reality_dest: str | None = None
    reality_server_names: list[str] | None = None
    cert_path: str | None = None
    key_path: str | None = None
    settings: dict | None = None
    sniffing: bool | None = None
    is_enabled: bool | None = None
    is_default: bool | None = None
    sort_order: int | None = None
    node_ids: list[int] | None = None


class NodeInboundOut(ORMModel):
    node_id: int
    is_enabled: bool
    synced_at: datetime | None = None
    sync_error: str = ""
    port_override: int | None = None
    address_override: str = ""


class InboundOut(InboundBase, ORMModel):
    id: int
    created_at: datetime
    node_inbounds: list[NodeInboundOut] = []
    users_count: int = 0


# --------------------------------------------------------------------------
# nodes
# --------------------------------------------------------------------------
class NodeBase(BaseModel):
    name: str
    address: str
    public_address: str = ""
    country: str = ""
    ssh_port: int = 22
    ssh_user: str = "root"
    auth_method: SSHAuthMethod = SSHAuthMethod.PASSWORD
    usage_coefficient: float = 1.0
    is_enabled: bool = True
    is_default: bool = False
    sort_order: int = 0
    note: str = ""


class NodeCreate(NodeBase):
    secret: str = ""            # password or private key
    key_passphrase: str = ""
    host_key: str = ""          # optional pin supplied by the operator
    install_cores: list[CoreType] = []


class NodeUpdate(BaseModel):
    name: str | None = None
    address: str | None = None
    public_address: str | None = None
    country: str | None = None
    ssh_port: int | None = None
    ssh_user: str | None = None
    auth_method: SSHAuthMethod | None = None
    secret: str | None = None
    key_passphrase: str | None = None
    host_key: str | None = None
    usage_coefficient: float | None = None
    is_enabled: bool | None = None
    is_default: bool | None = None
    sort_order: int | None = None
    note: str | None = None


class NodeOut(NodeBase, ORMModel):
    id: int
    status: NodeStatus
    status_message: str = ""
    last_seen: datetime | None = None
    host_key: str = ""
    installed_cores: dict = {}
    xray_version: str = ""
    agent_version: str = ""
    cpu_percent: float = 0
    mem_percent: float = 0
    disk_percent: float = 0
    uptime_seconds: int = 0
    net_tx_speed: float = 0
    net_rx_speed: float = 0
    up_bytes: int = 0
    down_bytes: int = 0
    created_at: datetime


class NodeTestRequest(BaseModel):
    address: str
    ssh_port: int = 22
    ssh_user: str = "root"
    auth_method: SSHAuthMethod = SSHAuthMethod.PASSWORD
    secret: str
    key_passphrase: str = ""
    host_key: str = ""


class NodeInstallRequest(BaseModel):
    cores: list[CoreType]
    options: dict = {}


# --------------------------------------------------------------------------
# groups
# --------------------------------------------------------------------------
class GroupBase(BaseModel):
    name: str
    title: str = ""
    kind: GroupKind = GroupKind.CUSTOM
    description: str = ""
    data_limit: int = 0
    duration_days: int = 0
    device_limit: int = 0
    data_limit_strategy: DataLimitStrategy = DataLimitStrategy.NO_RESET
    on_hold: bool = False
    price: int = 0
    max_users: int = 0
    is_active: bool = True
    is_public: bool = True
    sort_order: int = 0


class GroupCreate(GroupBase):
    inbound_ids: list[int] = []
    node_ids: list[int] = []


class GroupUpdate(BaseModel):
    title: str | None = None
    kind: GroupKind | None = None
    description: str | None = None
    data_limit: int | None = None
    duration_days: int | None = None
    device_limit: int | None = None
    data_limit_strategy: DataLimitStrategy | None = None
    on_hold: bool | None = None
    price: int | None = None
    max_users: int | None = None
    is_active: bool | None = None
    is_public: bool | None = None
    sort_order: int | None = None
    inbound_ids: list[int] | None = None
    node_ids: list[int] | None = None


class GroupOut(GroupBase, ORMModel):
    id: int
    created_at: datetime
    inbound_ids: list[int] = []
    node_ids: list[int] = []
    users_count: int = 0


# --------------------------------------------------------------------------
# users
# --------------------------------------------------------------------------
class UserBase(BaseModel):
    username: str = Field(pattern=r"^[a-zA-Z0-9._@-]{2,64}$")
    note: str = ""
    email: str = ""
    telegram_id: int | None = None
    group_id: int | None = None
    data_limit: int = 0
    device_limit: int = 0
    data_limit_strategy: DataLimitStrategy = DataLimitStrategy.NO_RESET
    expire_at: datetime | None = None
    on_hold_duration_days: int = 0


class UserCreate(UserBase):
    password: str = ""
    uuid: str = ""
    sub_id: str = ""
    status: UserStatus = UserStatus.ACTIVE
    inbound_ids: list[int] = []
    node_ids: list[int] = []
    # convenience: expire in N days from now instead of an absolute date
    duration_days: int | None = None

    @field_validator("username")
    @classmethod
    def _lower(cls, v: str) -> str:
        return v.strip().lower()


class UserUpdate(BaseModel):
    password: str | None = None
    uuid: str | None = None
    note: str | None = None
    email: str | None = None
    telegram_id: int | None = None
    group_id: int | None = None
    data_limit: int | None = None
    device_limit: int | None = None
    data_limit_strategy: DataLimitStrategy | None = None
    expire_at: datetime | None = None
    duration_days: int | None = None
    on_hold_duration_days: int | None = None
    status: UserStatus | None = None
    inbound_ids: list[int] | None = None
    node_ids: list[int] | None = None


class UserOut(ORMModel):
    id: int
    username: str
    password: str = ""
    uuid: str
    sub_id: str
    email: str = ""
    note: str = ""
    telegram_id: int | None = None
    group_id: int | None = None
    group_name: str | None = None
    owner_id: int | None = None
    status: UserStatus
    data_limit: int
    used_traffic: int
    lifetime_used_traffic: int
    data_limit_strategy: DataLimitStrategy
    device_limit: int
    expire_at: datetime | None = None
    created_at: datetime
    online_at: datetime | None = None
    is_online: bool = False
    subscription_url: str = ""
    inbound_ids: list[int] = []
    node_ids: list[int] = []


class BulkAction(BaseModel):
    user_ids: list[int] = []
    all_matching: bool = False
    action: str  # enable | disable | delete | reset_traffic | add_days |
    #              add_traffic | set_group | revoke_sub
    value: int | str | None = None


# --------------------------------------------------------------------------
# stats
# --------------------------------------------------------------------------
class DashboardOut(BaseModel):
    users_total: int
    users_active: int
    users_online: int
    users_expired: int
    users_limited: int
    traffic_total: int
    traffic_today: int
    traffic_month: int
    nodes_total: int
    nodes_online: int
    inbounds_total: int
    protocol_distribution: dict[str, int]
    top_users: list[dict]
    node_status: list[dict]
    panel_uptime: int
    version: str


class TrafficPoint(BaseModel):
    t: datetime
    up: int
    down: int


class ConnectionOut(ORMModel):
    id: int
    user_id: int
    username: str = ""
    node_id: int | None = None
    node_name: str = ""
    protocol: Protocol | None = None
    ip: str = ""
    up: int
    down: int
    started_at: datetime
    last_seen: datetime
    is_active: bool


# --------------------------------------------------------------------------
# migration
# --------------------------------------------------------------------------
class MigrationPreview(BaseModel):
    accounts: int
    inbounds: list[dict]
    sample: list[dict]


class MigrationRunRequest(BaseModel):
    db_path: str = ""
    group_id: int | None = None
    inbound_ids: list[int] = []
    node_ids: list[int] = []
    keep_sub_id: bool = True
    keep_uuid: bool = True
    keep_usage: bool = True
    dry_run: bool = False
    default_status: UserStatus = UserStatus.ACTIVE


class MigrationResult(BaseModel):
    imported: int
    updated: int
    skipped: int
    errors: list[str] = []
    users: list[str] = []


class ClaimRequest(BaseModel):
    username: str
    password: str = ""
