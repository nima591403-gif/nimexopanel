"""Application configuration.

All settings can be overridden through environment variables or a .env file
that lives next to the project root (see .env.example).
"""
from functools import lru_cache
from typing import List

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    # --- Branding -----------------------------------------------------
    BRAND_NAME: str = "NimexoPanel"
    BRAND_LOGO: str = ""

    # --- Server -------------------------------------------------------
    HOST: str = "0.0.0.0"
    PORT: int = 8080
    DEBUG: bool = False
    ROOT_PATH: str = ""
    # Public address used when building subscription links / configs.
    PANEL_DOMAIN: str = ""
    PANEL_PUBLIC_URL: str = ""  # e.g. https://panel.example.com

    # --- Security -----------------------------------------------------
    SECRET_KEY: str = Field(default="change-me-please-generate-a-random-secret")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24
    ALGORITHM: str = "HS256"
    # Separate key used to encrypt node SSH credentials at rest.
    CREDENTIAL_KEY: str = ""

    # --- Database -----------------------------------------------------
    DATABASE_URL: str = "sqlite:////opt/nimexo/panel.db"

    # --- Subscription -------------------------------------------------
    SUB_DOMAIN: str = ""          # domain used for /sub links
    SUB_PATH: str = "sub"
    SUB_PORT: int = 0             # 0 => same as panel
    SUB_UPDATE_INTERVAL_HOURS: int = 12
    SUB_PROFILE_TITLE: str = "NimexoPanel"

    # --- Jobs ---------------------------------------------------------
    NODE_HEALTH_INTERVAL: int = 60     # seconds
    TRAFFIC_SYNC_INTERVAL: int = 30    # seconds
    EXPIRY_CHECK_INTERVAL: int = 120   # seconds

    # --- Misc ---------------------------------------------------------
    CORS_ORIGINS: List[str] = ["*"]
    TIMEZONE: str = "Asia/Tehran"
    LOG_LEVEL: str = "INFO"
    DATA_DIR: str = "/opt/nimexo"

    # Telegram notifications (optional)
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_ADMIN_IDS: List[int] = []

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def _split_origins(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(",") if x.strip()]
        return v

    @field_validator("TELEGRAM_ADMIN_IDS", mode="before")
    @classmethod
    def _split_ids(cls, v):
        if isinstance(v, str):
            return [int(x) for x in v.replace(" ", "").split(",") if x]
        return v

    @property
    def sub_base_url(self) -> str:
        if self.PANEL_PUBLIC_URL and not self.SUB_DOMAIN:
            return f"{self.PANEL_PUBLIC_URL.rstrip('/')}/{self.SUB_PATH.strip('/')}"
        domain = self.SUB_DOMAIN or self.PANEL_DOMAIN or "127.0.0.1"
        port = self.SUB_PORT or self.PORT
        scheme = "https" if port in (443, 8443, 2096, 2087, 2053) else "http"
        netloc = domain if port in (80, 443) else f"{domain}:{port}"
        return f"{scheme}://{netloc}/{self.SUB_PATH.strip('/')}"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
