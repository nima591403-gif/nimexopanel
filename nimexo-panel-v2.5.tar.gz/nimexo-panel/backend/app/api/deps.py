"""Shared FastAPI dependencies."""
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import Admin
from app.models.enums import AdminRole
from app.utils.crypto import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login", auto_error=False)


def client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else ""


def current_admin(
    token: str | None = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> Admin:
    if not token:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "not authenticated")
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid or expired token")
    admin = db.query(Admin).filter(Admin.username == payload.get("sub")).one_or_none()
    if admin is None or not admin.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "account disabled")
    return admin


def require_sudo(admin: Admin = Depends(current_admin)) -> Admin:
    if admin.role != AdminRole.SUDO:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "sudo privileges required")
    return admin


def require_manager(admin: Admin = Depends(current_admin)) -> Admin:
    """Sudo or admin — anyone allowed to touch infrastructure."""
    if admin.role == AdminRole.RESELLER:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "not allowed for resellers")
    return admin
