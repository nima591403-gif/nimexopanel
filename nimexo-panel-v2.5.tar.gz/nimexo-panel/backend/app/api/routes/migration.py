import os
import shutil
import tempfile

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.api.deps import current_admin, require_manager
from app.config import settings
from app.db import get_db
from app.models import Admin, LegacyAccount
from app.schemas.common import Message
from app.schemas.entities import ClaimRequest, MigrationResult, MigrationRunRequest
from app.services import migration as migration_service
from app.services import users as user_service

router = APIRouter(tags=["migration"])

UPLOAD_DIR = os.path.join(settings.DATA_DIR, "imports")


@router.post("/api/migration/upload")
def upload_source(file: UploadFile = File(...), _: Admin = Depends(require_manager)):
    """Upload a copy of the old panel's SQLite database (vpn-ui.db)."""
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    suffix = os.path.splitext(file.filename or "vpn-ui.db")[1] or ".db"
    fd, path = tempfile.mkstemp(dir=UPLOAD_DIR, suffix=suffix)
    with os.fdopen(fd, "wb") as out:
        shutil.copyfileobj(file.file, out)
    try:
        info = migration_service.inspect(path)
    except Exception as exc:  # noqa: BLE001
        os.remove(path)
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    return {"path": path, **info}


@router.post("/api/migration/inspect")
def inspect_source(payload: MigrationRunRequest, _: Admin = Depends(require_manager)):
    try:
        return migration_service.inspect(payload.db_path)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc


@router.post("/api/migration/run", response_model=MigrationResult)
def run_migration(payload: MigrationRunRequest, db: Session = Depends(get_db),
                  admin: Admin = Depends(require_manager)):
    if not payload.db_path or not os.path.exists(payload.db_path):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "source database not found")
    try:
        result = migration_service.run_import(
            db,
            payload.db_path,
            group_id=payload.group_id,
            inbound_ids=payload.inbound_ids,
            node_ids=payload.node_ids,
            keep_sub_id=payload.keep_sub_id,
            keep_uuid=payload.keep_uuid,
            keep_usage=payload.keep_usage,
            dry_run=payload.dry_run,
            default_status=payload.default_status,
            owner_id=admin.id,
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    return MigrationResult(**result)


@router.get("/api/migration/legacy")
def legacy_accounts(claimed: bool | None = None, limit: int = 200,
                    db: Session = Depends(get_db), _: Admin = Depends(current_admin)):
    query = db.query(LegacyAccount)
    if claimed is True:
        query = query.filter(LegacyAccount.claimed_user_id.isnot(None))
    elif claimed is False:
        query = query.filter(LegacyAccount.claimed_user_id.is_(None))
    rows = query.order_by(LegacyAccount.username).limit(limit).all()
    return [
        {
            "username": r.username,
            "email": r.email,
            "data_limit": r.data_limit,
            "used_traffic": r.used_traffic,
            "expire_at": r.expire_at,
            "enabled": r.enabled,
            "claimed": bool(r.claimed_user_id),
            "claimed_at": r.claimed_at,
        }
        for r in rows
    ]


# --------------------------------------------------------------------------
# public self-service migration
# --------------------------------------------------------------------------
@router.post("/api/migrate/claim")
def claim_account(payload: ClaimRequest, db: Session = Depends(get_db)):
    """A user types their old panel credentials and gets a new subscription."""
    user = migration_service.claim(db, payload.username, payload.password)
    if user is None:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            "no account with these credentials was found in the old panel",
        )
    return {
        "username": user.username,
        "sub_id": user.sub_id,
        "subscription_url": user_service.subscription_url(user),
        "page_url": f"/u/{user.sub_id}",
        "data_limit": user.data_limit,
        "used_traffic": user.used_traffic,
        "expire_at": user.expire_at,
        "status": user.status.value,
    }


@router.get("/api/migrate/lookup/{username}")
def lookup(username: str, db: Session = Depends(get_db)):
    """Tell the user whether their old account exists (without exposing data)."""
    normalized = username.strip().lower().split("@")[0]
    row = (
        db.query(LegacyAccount)
        .filter(LegacyAccount.username == normalized)
        .one_or_none()
    )
    return {
        "found": row is not None,
        "needs_password": bool(row and row.password),
        "already_migrated": bool(row and row.claimed_user_id),
    }
