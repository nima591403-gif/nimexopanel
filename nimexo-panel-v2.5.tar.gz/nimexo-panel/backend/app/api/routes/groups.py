from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session, selectinload

from app.api.deps import current_admin, require_manager
from app.db import get_db
from app.models import Admin, Group, Inbound, Node
from app.models.enums import AdminRole
from app.schemas.common import Message
from app.schemas.entities import GroupCreate, GroupOut, GroupUpdate

router = APIRouter(prefix="/api/groups", tags=["groups"])


def _serialize(group: Group) -> dict:
    return {
        **{
            c: getattr(group, c)
            for c in (
                "id", "name", "title", "kind", "description", "data_limit",
                "duration_days", "device_limit", "data_limit_strategy", "on_hold",
                "price", "max_users", "is_active", "is_public", "sort_order",
                "created_at",
            )
        },
        "inbound_ids": [i.id for i in group.inbounds],
        "node_ids": [n.id for n in group.nodes],
        "users_count": len(group.users),
    }


@router.get("", response_model=list[GroupOut])
def list_groups(db: Session = Depends(get_db), admin: Admin = Depends(current_admin)):
    query = db.query(Group).options(
        selectinload(Group.inbounds), selectinload(Group.nodes),
        selectinload(Group.users),
    )
    allowed = admin.allowed_group_ids or []
    if admin.role == AdminRole.RESELLER and allowed:
        query = query.filter(Group.id.in_(allowed))
    groups = query.order_by(Group.sort_order, Group.id).all()
    return [_serialize(g) for g in groups]


@router.post("", response_model=GroupOut, status_code=201)
def create_group(payload: GroupCreate, db: Session = Depends(get_db),
                 _: Admin = Depends(require_manager)):
    if db.query(Group).filter(Group.name == payload.name).first():
        raise HTTPException(status.HTTP_409_CONFLICT, "a group with this name exists")
    data = payload.model_dump(exclude={"inbound_ids", "node_ids"})
    group = Group(**data)
    group.inbounds = db.query(Inbound).filter(Inbound.id.in_(payload.inbound_ids)).all()
    group.nodes = db.query(Node).filter(Node.id.in_(payload.node_ids)).all()
    db.add(group)
    db.commit()
    return _serialize(group)


@router.patch("/{group_id}", response_model=GroupOut)
def update_group(group_id: int, payload: GroupUpdate, db: Session = Depends(get_db),
                 _: Admin = Depends(require_manager)):
    group = db.query(Group).get(group_id)
    if group is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "group not found")
    data = payload.model_dump(exclude_unset=True)
    inbound_ids = data.pop("inbound_ids", None)
    node_ids = data.pop("node_ids", None)
    for key, value in data.items():
        setattr(group, key, value)
    if inbound_ids is not None:
        group.inbounds = db.query(Inbound).filter(Inbound.id.in_(inbound_ids)).all()
    if node_ids is not None:
        group.nodes = db.query(Node).filter(Node.id.in_(node_ids)).all()
    db.add(group)
    db.commit()
    return _serialize(group)


@router.delete("/{group_id}", response_model=Message)
def delete_group(group_id: int, db: Session = Depends(get_db),
                 _: Admin = Depends(require_manager)):
    group = db.query(Group).get(group_id)
    if group is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "group not found")
    if group.users:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"{len(group.users)} users still belong to this group",
        )
    db.delete(group)
    db.commit()
    return Message(message="group deleted")
