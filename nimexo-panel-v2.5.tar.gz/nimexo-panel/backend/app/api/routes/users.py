from datetime import timedelta

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status
from sqlalchemy import func, or_
from sqlalchemy.orm import Session, selectinload

from app.api.deps import current_admin
from app.db import get_db
from app.models import Admin, Group, User, utcnow
from app.models.enums import AdminRole, UserStatus
from app.schemas.common import Message, Page
from app.schemas.entities import BulkAction, UserCreate, UserOut, UserUpdate
from app.services import resellers as reseller_service
from app.services import sync as sync_service
from app.services import traffic as traffic_service
from app.services import users as user_service
from app.utils.crypto import new_uuid, random_token

router = APIRouter(prefix="/api/users", tags=["users"])


def _scope(query, admin: Admin):
    if admin.role == AdminRole.RESELLER:
        return query.filter(User.owner_id == admin.id)
    return query


def _check_reseller_scope(admin: Admin, group_id: int | None,
                          inbound_ids: list[int] | None,
                          node_ids: list[int] | None) -> None:
    """A reseller may only hand out what the owner allocated to them."""
    groups = admin.allowed_group_ids or []
    if groups and group_id and group_id not in groups:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "این گروه در اختیار شما نیست")
    inbounds = admin.allowed_inbound_ids or []
    if inbounds and inbound_ids:
        extra = set(inbound_ids) - set(inbounds)
        if extra:
            raise HTTPException(
                status.HTTP_403_FORBIDDEN, "دسترسی به برخی از اینباندهای انتخابی ندارید"
            )
    nodes = admin.allowed_node_ids or []
    if nodes and node_ids:
        extra = set(node_ids) - set(nodes)
        if extra:
            raise HTTPException(
                status.HTTP_403_FORBIDDEN, "دسترسی به برخی از نودهای انتخابی ندارید"
            )


def _get(db: Session, user_id: int, admin: Admin) -> User:
    user = db.query(User).get(user_id)
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "user not found")
    if admin.role == AdminRole.RESELLER and user.owner_id != admin.id:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "not your user")
    return user


@router.get("", response_model=Page[UserOut])
def list_users(
    db: Session = Depends(get_db),
    admin: Admin = Depends(current_admin),
    search: str = "",
    status_filter: UserStatus | None = Query(None, alias="status"),
    group_id: int | None = None,
    node_id: int | None = None,
    online: bool | None = None,
    sort: str = "-created_at",
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=500),
):
    query = _scope(
        db.query(User).options(
            selectinload(User.group),
            selectinload(User.inbounds),
            selectinload(User.nodes),
        ),
        admin,
    )
    if search:
        pattern = f"%{search.strip().lower()}%"
        query = query.filter(
            or_(
                func.lower(User.username).like(pattern),
                func.lower(User.note).like(pattern),
                User.sub_id.like(pattern),
                User.uuid.like(pattern),
            )
        )
    if status_filter:
        query = query.filter(User.status == status_filter)
    if group_id:
        query = query.filter(User.group_id == group_id)

    online_ids = traffic_service.online_user_ids(db)
    if online is True:
        query = query.filter(User.id.in_(online_ids or {0}))
    elif online is False:
        query = query.filter(~User.id.in_(online_ids or {0}))

    total = query.count()
    direction = sort.startswith("-")
    field = getattr(User, sort.lstrip("-"), User.created_at)
    query = query.order_by(field.desc() if direction else field.asc())
    rows = query.offset((page - 1) * size).limit(size).all()

    if node_id:
        rows = [
            u for u in rows
            if node_id in {n.id for n in sync_service.effective_nodes(db, u)}
        ]

    return Page[UserOut](
        items=[user_service.serialize(db, u, online_ids) for u in rows],
        total=total,
        page=page,
        size=size,
    )


@router.post("", response_model=UserOut, status_code=201)
def create_user(
    payload: UserCreate,
    background: BackgroundTasks,
    db: Session = Depends(get_db),
    admin: Admin = Depends(current_admin),
):
    if db.query(User).filter(User.username == payload.username).first():
        raise HTTPException(status.HTTP_409_CONFLICT, "username already exists")

    if admin.role == AdminRole.RESELLER:
        allowed, reason = reseller_service.can_create_user(db, admin)
        if not allowed:
            raise HTTPException(status.HTTP_403_FORBIDDEN, reason)
        _check_reseller_scope(admin, payload.group_id, payload.inbound_ids,
                              payload.node_ids)

    if payload.group_id:
        group = db.query(Group).get(payload.group_id)
        if group is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "unknown group")
        if group.max_users and len(group.users) >= group.max_users:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "group is full")

    user = user_service.create_user(
        db,
        username=payload.username,
        password=payload.password,
        uuid=payload.uuid,
        sub_id=payload.sub_id,
        group_id=payload.group_id,
        data_limit=payload.data_limit,
        device_limit=payload.device_limit,
        expire_at=payload.expire_at,
        duration_days=payload.duration_days,
        on_hold_duration_days=payload.on_hold_duration_days,
        status=payload.status,
        note=payload.note,
        email=payload.email,
        telegram_id=payload.telegram_id,
        owner_id=admin.id,
        inbound_ids=payload.inbound_ids or None,
        node_ids=payload.node_ids or None,
        data_limit_strategy=payload.data_limit_strategy,
    )
    db.commit()
    sync_service.log(db, "user_created", f"created {user.username}", admin.username,
                     target=user.username)
    background.add_task(_sync_user_nodes, user.id)
    return user_service.serialize(db, user)


@router.get("/{user_id}", response_model=UserOut)
def get_user(user_id: int, db: Session = Depends(get_db),
             admin: Admin = Depends(current_admin)):
    user = _get(db, user_id, admin)
    return user_service.serialize(db, user, traffic_service.online_user_ids(db))


@router.patch("/{user_id}", response_model=UserOut)
def update_user(
    user_id: int,
    payload: UserUpdate,
    background: BackgroundTasks,
    db: Session = Depends(get_db),
    admin: Admin = Depends(current_admin),
):
    user = _get(db, user_id, admin)
    data = payload.model_dump(exclude_unset=True)
    inbound_ids = data.pop("inbound_ids", None)
    node_ids = data.pop("node_ids", None)
    duration_days = data.pop("duration_days", None)

    if admin.role == AdminRole.RESELLER:
        _check_reseller_scope(admin, data.get("group_id"), inbound_ids, node_ids)

    for key, value in data.items():
        setattr(user, key, value)
    if data.get("status") == UserStatus.ACTIVE:
        user.suspended_by_system = False
    if duration_days is not None:
        user.expire_at = utcnow() + timedelta(days=duration_days)
    user_service.attach_relations(db, user, inbound_ids, node_ids)

    if user.status in (UserStatus.LIMITED, UserStatus.EXPIRED):
        quota_ok = not user.data_limit or user.used_traffic < user.data_limit
        time_ok = not user.expire_at or user.expire_at > utcnow()
        if quota_ok and time_ok and "status" not in data:
            user.status = UserStatus.ACTIVE

    db.add(user)
    db.commit()
    sync_service.log(db, "user_updated", f"updated {user.username}", admin.username,
                     target=user.username)
    background.add_task(_sync_user_nodes, user.id)
    return user_service.serialize(db, user)


@router.delete("/{user_id}", response_model=Message)
def delete_user(user_id: int, background: BackgroundTasks,
                db: Session = Depends(get_db),
                admin: Admin = Depends(current_admin)):
    user = _get(db, user_id, admin)
    username = user.username
    db.delete(user)
    db.commit()
    sync_service.log(db, "user_deleted", f"deleted {username}", admin.username,
                     target=username)
    background.add_task(_sync_all_nodes)
    return Message(message=f"{username} deleted")


@router.post("/{user_id}/reset-traffic", response_model=UserOut)
def reset_traffic(user_id: int, db: Session = Depends(get_db),
                  admin: Admin = Depends(current_admin)):
    user = _get(db, user_id, admin)
    user.used_traffic = 0
    user.last_reset_at = utcnow()
    if user.status == UserStatus.LIMITED:
        user.status = UserStatus.ACTIVE
    db.add(user)
    db.commit()
    return user_service.serialize(db, user)


@router.post("/{user_id}/revoke-sub", response_model=UserOut)
def revoke_subscription(user_id: int, background: BackgroundTasks,
                        db: Session = Depends(get_db),
                        admin: Admin = Depends(current_admin)):
    user = _get(db, user_id, admin)
    user.sub_id = user_service.unique_sub_id(db, random_token(16))
    user.uuid = new_uuid()
    user.sub_revoked_at = utcnow()
    db.add(user)
    db.commit()
    background.add_task(_sync_user_nodes, user.id)
    return user_service.serialize(db, user)


@router.post("/bulk", response_model=Message)
def bulk_action(payload: BulkAction, background: BackgroundTasks,
                db: Session = Depends(get_db),
                admin: Admin = Depends(current_admin)):
    query = _scope(db.query(User), admin)
    if not payload.all_matching:
        query = query.filter(User.id.in_(payload.user_ids or [0]))
    users = query.all()
    touched = 0

    for user in users:
        action, value = payload.action, payload.value
        if action == "enable":
            user.status = UserStatus.ACTIVE
            user.suspended_by_system = False
        elif action == "disable":
            user.status = UserStatus.DISABLED
        elif action == "reset_traffic":
            user.used_traffic = 0
            user.last_reset_at = utcnow()
        elif action == "add_days":
            base = user.expire_at or utcnow()
            user.expire_at = base + timedelta(days=int(value or 0))
        elif action == "add_traffic":
            user.data_limit = max(0, user.data_limit + int(value or 0))
        elif action == "set_group":
            user.group_id = int(value) if value else None
        elif action == "revoke_sub":
            user.sub_id = user_service.unique_sub_id(db, random_token(16))
            user.uuid = new_uuid()
        elif action == "delete":
            db.delete(user)
            touched += 1
            continue
        else:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, f"unknown action {action}")
        db.add(user)
        touched += 1

    db.commit()
    sync_service.log(db, "bulk_action", f"{payload.action} on {touched} users",
                     admin.username)
    background.add_task(_sync_all_nodes)
    return Message(message=f"{touched} users updated")


# --------------------------------------------------------------------------
# background helpers
# --------------------------------------------------------------------------
def _sync_user_nodes(user_id: int) -> None:
    from app.db import session_scope

    with session_scope() as db:
        user = db.query(User).get(user_id)
        if user:
            sync_service.sync_nodes_for_user(db, user)


def _sync_all_nodes() -> None:
    from app.db import session_scope

    with session_scope() as db:
        sync_service.sync_all(db)
