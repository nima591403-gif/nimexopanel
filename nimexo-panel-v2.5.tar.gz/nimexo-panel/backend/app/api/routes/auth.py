from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import client_ip, current_admin
from app.config import settings
from app.db import get_db
from app.models import Admin, AuditLog, utcnow
from app.schemas.common import Message, Token
from app.schemas.entities import AdminOut
from app.utils.crypto import create_access_token, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=Token)
def login(
    request: Request,
    form: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    admin = db.query(Admin).filter(Admin.username == form.username).one_or_none()
    ip = client_ip(request)
    if admin is None or not verify_password(form.password, admin.password_hash):
        db.add(
            AuditLog(
                level="warning", actor=form.username, action="login_failed",
                message="wrong username or password", ip=ip,
            )
        )
        db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "wrong username or password")
    if not admin.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "account disabled")

    admin.last_login_at = utcnow()
    admin.last_login_ip = ip
    db.add(admin)
    db.add(AuditLog(actor=admin.username, action="login", message="signed in", ip=ip))
    db.commit()

    token = create_access_token(admin.username, {"role": admin.role.value})
    return Token(
        access_token=token,
        expires_at=datetime.now(timezone.utc)
        + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
        username=admin.username,
        role=admin.role.value,
    )


@router.get("/me", response_model=AdminOut)
def me(admin: Admin = Depends(current_admin)):
    return admin


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


@router.post("/change-password", response_model=Message)
def change_password(
    payload: PasswordChange,
    admin: Admin = Depends(current_admin),
    db: Session = Depends(get_db),
):
    if not verify_password(payload.current_password, admin.password_hash):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "current password is wrong")
    if len(payload.new_password) < 6:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "password is too short")
    admin.password_hash = hash_password(payload.new_password)
    db.add(admin)
    db.commit()
    return Message(message="password changed")
