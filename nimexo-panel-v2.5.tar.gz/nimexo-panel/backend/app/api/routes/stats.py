import time
from datetime import timedelta

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.api.deps import current_admin
from app.db import get_db
from app.models import Admin, Connection, Inbound, Node, TrafficRecord, User, utcnow
from app.models.enums import NodeStatus, UserStatus
from app.schemas.entities import ConnectionOut, DashboardOut
from app.services import traffic as traffic_service

router = APIRouter(prefix="/api/stats", tags=["stats"])

PANEL_STARTED_AT = time.time()
VERSION = "1.0.0"


@router.get("/dashboard", response_model=DashboardOut)
def dashboard(db: Session = Depends(get_db), _: Admin = Depends(current_admin)):
    online_ids = traffic_service.online_user_ids(db)
    counts = dict(
        db.query(User.status, func.count(User.id)).group_by(User.status).all()
    )
    total_traffic = db.query(func.coalesce(func.sum(User.lifetime_used_traffic), 0)).scalar()

    day_ago = utcnow() - timedelta(days=1)
    month_ago = utcnow() - timedelta(days=30)
    today = (
        db.query(
            func.coalesce(func.sum(TrafficRecord.up + TrafficRecord.down), 0)
        )
        .filter(TrafficRecord.bucket >= day_ago)
        .scalar()
    )
    month = (
        db.query(
            func.coalesce(func.sum(TrafficRecord.up + TrafficRecord.down), 0)
        )
        .filter(TrafficRecord.bucket >= month_ago)
        .scalar()
    )

    nodes = db.query(Node).all()
    inbounds = db.query(Inbound).all()

    distribution: dict[str, int] = {}
    for inbound in inbounds:
        distribution[inbound.protocol.value] = distribution.get(
            inbound.protocol.value, 0
        ) + len(inbound.users)

    top = (
        db.query(User)
        .filter(User.lifetime_used_traffic > 0)
        .order_by(User.lifetime_used_traffic.desc())
        .limit(5)
        .all()
    )

    return DashboardOut(
        users_total=sum(counts.values()),
        users_active=counts.get(UserStatus.ACTIVE, 0) + counts.get(UserStatus.ON_HOLD, 0),
        users_online=len(online_ids),
        users_expired=counts.get(UserStatus.EXPIRED, 0),
        users_limited=counts.get(UserStatus.LIMITED, 0),
        traffic_total=int(total_traffic or 0),
        traffic_today=int(today or 0),
        traffic_month=int(month or 0),
        nodes_total=len(nodes),
        nodes_online=len([n for n in nodes if n.status == NodeStatus.ONLINE]),
        inbounds_total=len(inbounds),
        protocol_distribution=distribution,
        top_users=[
            {
                "username": u.username,
                "used": u.lifetime_used_traffic,
                "limit": u.data_limit,
            }
            for u in top
        ],
        node_status=[
            {
                "id": n.id,
                "name": n.name,
                "status": n.status.value,
                "cpu": n.cpu_percent,
                "memory": n.mem_percent,
                "disk": n.disk_percent,
                "uptime": n.uptime_seconds,
                "tx": n.net_tx_speed,
                "rx": n.net_rx_speed,
                "country": n.country,
            }
            for n in nodes
        ],
        panel_uptime=int(time.time() - PANEL_STARTED_AT),
        version=VERSION,
    )


@router.get("/traffic")
def traffic_series(
    hours: int = Query(48, ge=1, le=24 * 90),
    user_id: int | None = None,
    node_id: int | None = None,
    db: Session = Depends(get_db),
    _: Admin = Depends(current_admin),
):
    since = utcnow() - timedelta(hours=hours)
    query = (
        db.query(
            TrafficRecord.bucket,
            func.sum(TrafficRecord.up),
            func.sum(TrafficRecord.down),
        )
        .filter(TrafficRecord.bucket >= since)
        .group_by(TrafficRecord.bucket)
        .order_by(TrafficRecord.bucket)
    )
    if user_id:
        query = query.filter(TrafficRecord.user_id == user_id)
    if node_id:
        query = query.filter(TrafficRecord.node_id == node_id)
    return [
        {"t": bucket, "up": int(up or 0), "down": int(down or 0)}
        for bucket, up, down in query.all()
    ]


@router.get("/connections", response_model=list[ConnectionOut])
def connections(
    active_only: bool = True,
    limit: int = Query(200, ge=1, le=2000),
    db: Session = Depends(get_db),
    _: Admin = Depends(current_admin),
):
    query = db.query(Connection).order_by(Connection.last_seen.desc())
    if active_only:
        query = query.filter(Connection.is_active.is_(True))
    rows = query.limit(limit).all()
    users = {u.id: u.username for u in db.query(User).all()}
    nodes = {n.id: n.name for n in db.query(Node).all()}
    return [
        {
            "id": c.id,
            "user_id": c.user_id,
            "username": users.get(c.user_id, ""),
            "node_id": c.node_id,
            "node_name": nodes.get(c.node_id, ""),
            "protocol": c.protocol,
            "ip": c.ip,
            "up": c.up,
            "down": c.down,
            "started_at": c.started_at,
            "last_seen": c.last_seen,
            "is_active": c.is_active,
        }
        for c in rows
    ]


@router.get("/top-users")
def top_users(
    limit: int = Query(20, ge=1, le=200),
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
    _: Admin = Depends(current_admin),
):
    since = utcnow() - timedelta(days=days)
    rows = (
        db.query(
            TrafficRecord.user_id,
            func.sum(TrafficRecord.up + TrafficRecord.down).label("total"),
        )
        .filter(TrafficRecord.bucket >= since, TrafficRecord.user_id.isnot(None))
        .group_by(TrafficRecord.user_id)
        .order_by(func.sum(TrafficRecord.up + TrafficRecord.down).desc())
        .limit(limit)
        .all()
    )
    users = {u.id: u for u in db.query(User).all()}
    return [
        {
            "user_id": user_id,
            "username": users[user_id].username if user_id in users else "?",
            "total": int(total or 0),
        }
        for user_id, total in rows
    ]
