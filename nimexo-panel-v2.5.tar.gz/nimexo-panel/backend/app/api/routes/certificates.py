from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import current_admin, require_manager, require_sudo
from app.db import get_db
from app.models import Admin, Inbound, Node
from app.schemas.common import Message
from app.services import settings_store
from app.services import sync as sync_service
from app.services.node_manager import NodeError, agent_for
from app.services.ssh import SSHError

router = APIRouter(prefix="/api", tags=["certificates"])


class CertRequest(BaseModel):
    node_id: int
    domain: str
    email: str = ""
    method: str = "http"          # http | cloudflare
    cf_token: str = ""            # only for the cloudflare method
    staging: bool = False
    force: bool = False
    apply_to_inbound_id: int | None = None


class PanelSettings(BaseModel):
    brand_name: str | None = None
    panel_domain: str | None = None
    panel_public_url: str | None = None
    sub_domain: str | None = None
    sub_path: str | None = None
    sub_port: int | None = None
    sub_https: bool | None = None
    sub_profile_title: str | None = None


@router.get("/certificates")
def list_certificates(node_id: int | None = None, db: Session = Depends(get_db),
                      _: Admin = Depends(require_manager)):
    """Certificates present on each node."""
    query = db.query(Node).filter(Node.is_enabled.is_(True))
    if node_id:
        query = query.filter(Node.id == node_id)
    result = []
    for node in query.all():
        entry = {"node_id": node.id, "node": node.name, "certs": [], "error": ""}
        try:
            data = agent_for(node).cert_list()
            entry["certs"] = data.get("certs", [])
            entry["certbot"] = data.get("certbot", False)
        except (SSHError, NodeError) as exc:
            entry["error"] = str(exc)[:300]
        result.append(entry)
    return result


@router.post("/certificates/issue")
def issue_certificate(payload: CertRequest, db: Session = Depends(get_db),
                      admin: Admin = Depends(require_manager)):
    node = db.query(Node).get(payload.node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    if payload.method == "cloudflare" and not payload.cf_token:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "برای روش Cloudflare توکن API لازم است"
        )

    try:
        result = agent_for(node).cert_issue(payload.model_dump())
    except (SSHError, NodeError) as exc:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc

    if not result.get("ok"):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, result.get("error", "صدور گواهی ناموفق بود")
        )

    if payload.apply_to_inbound_id:
        inbound = db.query(Inbound).get(payload.apply_to_inbound_id)
        if inbound is not None:
            inbound.cert_path = result["cert"]
            inbound.key_path = result["key"]
            if not inbound.sni:
                inbound.sni = payload.domain
            db.add(inbound)
            db.commit()
            sync_service.sync_node(db, node)
            result["applied_to"] = inbound.tag

    sync_service.log(db, "cert_issued", f"{payload.domain} on {node.name}",
                     admin.username, target=payload.domain)
    return result


@router.get("/panel-settings")
def get_panel_settings(db: Session = Depends(get_db), _: Admin = Depends(current_admin)):
    cfg = settings_store.load(db)
    return {
        **cfg,
        "sub_base_url": settings_store.sub_base_url(db),
        "page_base_url": settings_store.page_base_url(db),
    }


@router.put("/panel-settings")
def update_panel_settings(payload: PanelSettings, db: Session = Depends(get_db),
                          admin: Admin = Depends(require_sudo)):
    values = payload.model_dump(exclude_unset=True)
    settings_store.save(db, values)
    sync_service.log(db, "panel_settings", "domain/subscription settings updated",
                     admin.username)
    cfg = settings_store.load(db)
    return {
        **cfg,
        "sub_base_url": settings_store.sub_base_url(db),
        "page_base_url": settings_store.page_base_url(db),
        "note": "برای تغییر پورتِ شنیدنِ پنل، PORT را در فایل .env عوض کرده و سرویس را ری‌استارت کنید",
    }
