import platform
import time

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import current_admin, require_manager, require_sudo
from app.config import settings
from app.db import get_db
from app.models import Admin, AuditLog, Setting
from app.schemas.common import Message
from app.services import sync as sync_service
from app.services import traffic as traffic_service

router = APIRouter(prefix="/api", tags=["system"])
STARTED_AT = time.time()


@router.get("/health")
def health():
    return {"ok": True, "uptime": int(time.time() - STARTED_AT), "brand": settings.BRAND_NAME}


@router.get("/system/info")
def system_info(_: Admin = Depends(current_admin)):
    return {
        "brand": settings.BRAND_NAME,
        "version": "1.0.0",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "timezone": settings.TIMEZONE,
        "sub_base_url": settings.sub_base_url,
        "uptime": int(time.time() - STARTED_AT),
    }


@router.get("/logs")
def logs(
    level: str | None = None,
    action: str | None = None,
    search: str = "",
    limit: int = Query(200, ge=1, le=2000),
    db: Session = Depends(get_db),
    _: Admin = Depends(current_admin),
):
    query = db.query(AuditLog).order_by(AuditLog.created_at.desc())
    if level:
        query = query.filter(AuditLog.level == level)
    if action:
        query = query.filter(AuditLog.action == action)
    if search:
        query = query.filter(AuditLog.message.like(f"%{search}%"))
    return [
        {
            "id": r.id,
            "created_at": r.created_at,
            "level": r.level,
            "actor": r.actor,
            "action": r.action,
            "target": r.target,
            "message": r.message,
            "ip": r.ip,
        }
        for r in query.limit(limit).all()
    ]


@router.get("/settings")
def get_settings(db: Session = Depends(get_db), _: Admin = Depends(current_admin)):
    return {row.key: row.value for row in db.query(Setting).all()}


@router.put("/settings/{key}")
def set_setting(key: str, value: dict, db: Session = Depends(get_db),
                _: Admin = Depends(require_sudo)):
    row = db.query(Setting).get(key)
    if row is None:
        row = Setting(key=key, value=value)
    else:
        row.value = value
    db.add(row)
    db.commit()
    return {"key": key, "value": row.value}


@router.post("/system/sync-all")
def sync_all(db: Session = Depends(get_db), admin: Admin = Depends(require_manager)):
    reports = sync_service.sync_all(db)
    sync_service.log(db, "sync_all", "pushed configuration to every node", admin.username)
    return reports


@router.post("/system/collect")
def collect(db: Session = Depends(get_db), _: Admin = Depends(require_manager)):
    return traffic_service.collect_all(db)


@router.post("/system/enforce", response_model=Message)
def enforce(db: Session = Depends(get_db), _: Admin = Depends(require_manager)):
    changed = traffic_service.enforce_limits(db)
    return Message(message="limits enforced", detail=changed)
