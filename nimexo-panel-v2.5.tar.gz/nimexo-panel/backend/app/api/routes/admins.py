from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import current_admin, require_sudo
from app.db import get_db
from app.models import Admin
from app.models.enums import AdminRole
from app.schemas.common import Message
from app.schemas.entities import AdminCreate, AdminOut, AdminUpdate
from app.utils.crypto import hash_password

router = APIRouter(prefix="/api/admins", tags=["admins"])


@router.get("", response_model=list[AdminOut])
def list_admins(db: Session = Depends(get_db), _: Admin = Depends(require_sudo)):
    return db.query(Admin).order_by(Admin.id).all()


@router.post("", response_model=AdminOut, status_code=201)
def create_admin(payload: AdminCreate, db: Session = Depends(get_db),
                 _: Admin = Depends(require_sudo)):
    if db.query(Admin).filter(Admin.username == payload.username).first():
        raise HTTPException(status.HTTP_409_CONFLICT, "username already exists")
    admin = Admin(
        **payload.model_dump(exclude={"password"}),
        password_hash=hash_password(payload.password),
    )
    db.add(admin)
    db.commit()
    return admin


@router.patch("/{admin_id}", response_model=AdminOut)
def update_admin(admin_id: int, payload: AdminUpdate, db: Session = Depends(get_db),
                 actor: Admin = Depends(require_sudo)):
    admin = db.query(Admin).get(admin_id)
    if admin is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "admin not found")
    data = payload.model_dump(exclude_unset=True)
    password = data.pop("password", None)
    for key, value in data.items():
        setattr(admin, key, value)
    if password:
        admin.password_hash = hash_password(password)
    if admin.id == actor.id and data.get("is_active") is False:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "you cannot disable yourself")
    db.add(admin)
    db.commit()
    return admin


@router.delete("/{admin_id}", response_model=Message)
def delete_admin(admin_id: int, db: Session = Depends(get_db),
                 actor: Admin = Depends(require_sudo)):
    admin = db.query(Admin).get(admin_id)
    if admin is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "admin not found")
    if admin.id == actor.id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "you cannot delete yourself")
    if admin.role == AdminRole.SUDO and db.query(Admin).filter(
        Admin.role == AdminRole.SUDO
    ).count() <= 1:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "the last sudo admin must stay")
    db.delete(admin)
    db.commit()
    return Message(message="admin removed")
