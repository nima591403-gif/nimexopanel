from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.api.deps import current_admin, require_sudo
from app.db import get_db
from app.models import Admin, ResellerTransaction
from app.models.enums import AdminRole
from app.schemas.common import Message
from app.services import resellers as reseller_service
from app.services import sync as sync_service
from app.utils.crypto import hash_password

router = APIRouter(prefix="/api/resellers", tags=["resellers"])


class ResellerCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=6)
    note: str = ""
    telegram_id: int | None = None
    traffic_quota: int = 0        # bytes granted up front
    user_quota: int = 0
    expire_at: datetime | None = None
    suspend_on_exhausted: bool = True
    allowed_group_ids: list[int] = []
    allowed_inbound_ids: list[int] = []
    allowed_node_ids: list[int] = []
    price: int = 0                # what they paid for the initial credit


class ResellerUpdate(BaseModel):
    password: str | None = None
    note: str | None = None
    telegram_id: int | None = None
    is_active: bool | None = None
    user_quota: int | None = None
    expire_at: datetime | None = None
    suspend_on_exhausted: bool | None = None
    allowed_group_ids: list[int] | None = None
    allowed_inbound_ids: list[int] | None = None
    allowed_node_ids: list[int] | None = None


class CreditRequest(BaseModel):
    amount: int                   # bytes; negative takes credit back
    price: int = 0
    note: str = ""


# Declared before the /{reseller_id} routes so "me" is never parsed as an id.
@router.get("/me/summary")
def my_summary(db: Session = Depends(get_db), admin: Admin = Depends(current_admin)):
    """A reseller's own quota panel."""
    if admin.role != AdminRole.RESELLER:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "این حساب نمایندگی نیست")
    return reseller_service.summary(db, admin)


def _get(db: Session, reseller_id: int) -> Admin:
    admin = db.query(Admin).get(reseller_id)
    if admin is None or admin.role != AdminRole.RESELLER:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "reseller not found")
    return admin


@router.get("")
def list_resellers(db: Session = Depends(get_db), _: Admin = Depends(require_sudo)):
    rows = (
        db.query(Admin)
        .filter(Admin.role == AdminRole.RESELLER)
        .order_by(Admin.id)
        .all()
    )
    return [reseller_service.summary(db, a) for a in rows]


@router.post("", status_code=201)
def create_reseller(payload: ResellerCreate, db: Session = Depends(get_db),
                    actor: Admin = Depends(require_sudo)):
    if db.query(Admin).filter(Admin.username == payload.username).first():
        raise HTTPException(status.HTTP_409_CONFLICT, "username already exists")

    admin = Admin(
        username=payload.username,
        password_hash=hash_password(payload.password),
        role=AdminRole.RESELLER,
        note=payload.note,
        telegram_id=payload.telegram_id,
        user_quota=payload.user_quota,
        expire_at=payload.expire_at,
        suspend_on_exhausted=payload.suspend_on_exhausted,
        allowed_group_ids=payload.allowed_group_ids,
        allowed_inbound_ids=payload.allowed_inbound_ids,
        allowed_node_ids=payload.allowed_node_ids,
        traffic_quota=0,
    )
    db.add(admin)
    db.commit()

    if payload.traffic_quota:
        reseller_service.add_credit(
            db, admin, payload.traffic_quota, price=payload.price,
            note="اعتبار اولیه", actor=actor.username,
        )
    sync_service.log(db, "reseller_created", f"reseller {admin.username} created",
                     actor.username, target=admin.username)
    return reseller_service.summary(db, admin)


@router.patch("/{reseller_id}")
def update_reseller(reseller_id: int, payload: ResellerUpdate,
                    db: Session = Depends(get_db), _: Admin = Depends(require_sudo)):
    admin = _get(db, reseller_id)
    data = payload.model_dump(exclude_unset=True)
    password = data.pop("password", None)
    for key, value in data.items():
        setattr(admin, key, value)
    if password:
        admin.password_hash = hash_password(password)
    db.add(admin)
    db.commit()
    reseller_service.enforce_quotas(db)
    return reseller_service.summary(db, admin)


@router.delete("/{reseller_id}", response_model=Message)
def delete_reseller(reseller_id: int, transfer_users_to: int | None = None,
                    db: Session = Depends(get_db),
                    actor: Admin = Depends(require_sudo)):
    admin = _get(db, reseller_id)
    from app.models import User

    users = db.query(User).filter(User.owner_id == admin.id).all()
    if users and transfer_users_to is None:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"{len(users)} کاربر به این نماینده تعلق دارد — "
            "برای انتقالشان transfer_users_to را بفرستید",
        )
    for user in users:
        user.owner_id = transfer_users_to
        db.add(user)
    name = admin.username
    db.delete(admin)
    db.commit()
    sync_service.log(db, "reseller_deleted", f"reseller {name} removed",
                     actor.username, target=name)
    return Message(message=f"نماینده {name} حذف شد")


@router.post("/{reseller_id}/credit")
def add_credit(reseller_id: int, payload: CreditRequest,
               db: Session = Depends(get_db), actor: Admin = Depends(require_sudo)):
    admin = _get(db, reseller_id)
    reseller_service.add_credit(
        db, admin, payload.amount, price=payload.price,
        note=payload.note, actor=actor.username,
    )
    reseller_service.enforce_quotas(db)
    sync_service.log(
        db, "reseller_credit",
        f"{payload.amount / 1024 ** 3:.2f} GB for {admin.username}",
        actor.username, target=admin.username,
    )
    return reseller_service.summary(db, admin)


@router.get("/{reseller_id}/transactions")
def transactions(reseller_id: int, limit: int = Query(100, ge=1, le=1000),
                 db: Session = Depends(get_db), admin: Admin = Depends(current_admin)):
    if admin.role != AdminRole.SUDO and admin.id != reseller_id:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "not allowed")
    rows = (
        db.query(ResellerTransaction)
        .filter(ResellerTransaction.admin_id == reseller_id)
        .order_by(ResellerTransaction.created_at.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "id": r.id,
            "amount": r.amount,
            "balance_after": r.balance_after,
            "price": r.price,
            "kind": r.kind,
            "note": r.note,
            "created_by": r.created_by,
            "created_at": r.created_at,
        }
        for r in rows
    ]
