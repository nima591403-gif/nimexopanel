from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import current_admin, require_manager
from app.db import get_db, session_scope
from app.models import Admin, Node, NodeInbound, utcnow
from app.models.enums import AdminRole, CoreType, NodeStatus
from app.schemas.common import Message
from app.schemas.entities import (
    NodeCreate,
    NodeInstallRequest,
    NodeOut,
    NodeTestRequest,
    NodeUpdate,
)
from app.services import sync as sync_service
from app.services import traffic as traffic_service
from app.services.node_manager import (
    NodeAgent,
    NodeError,
    agent_for,
    target_for,
    target_from_credentials,
)
from app.services.ssh import HostKeyMismatch, SSHError, pool
from app.utils.crypto import encrypt_secret

router = APIRouter(prefix="/api/nodes", tags=["nodes"])


@router.get("", response_model=list[NodeOut])
def list_nodes(db: Session = Depends(get_db), admin: Admin = Depends(current_admin)):
    query = db.query(Node)
    allowed = admin.allowed_node_ids or []
    if admin.role == AdminRole.RESELLER and allowed:
        query = query.filter(Node.id.in_(allowed))
    return query.order_by(Node.sort_order, Node.id).all()


@router.post("/test", response_model=dict)
def test_connection(payload: NodeTestRequest, _: Admin = Depends(require_manager)):
    """Try the credentials and report the host key so the operator can pin it."""
    target = target_from_credentials(
        payload.address, payload.ssh_port, payload.ssh_user,
        payload.auth_method, payload.secret, payload.key_passphrase, payload.host_key,
    )
    agent = NodeAgent(target)
    try:
        info = agent.probe()
    except HostKeyMismatch as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    except (SSHError, NodeError) as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    finally:
        pool.drop(target)
    return {"ok": True, **info}


@router.post("", response_model=NodeOut, status_code=201)
def create_node(payload: NodeCreate, background: BackgroundTasks,
                db: Session = Depends(get_db), _: Admin = Depends(require_manager)):
    if db.query(Node).filter(Node.name == payload.name).first():
        raise HTTPException(status.HTTP_409_CONFLICT, "a node with this name exists")

    target = target_from_credentials(
        payload.address, payload.ssh_port, payload.ssh_user,
        payload.auth_method, payload.secret, payload.key_passphrase, payload.host_key,
    )
    agent = NodeAgent(target)
    try:
        info = agent.probe()
        agent.ensure_agent(force=True)
        ping = agent.ping()
    except HostKeyMismatch as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    except (SSHError, NodeError) as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    finally:
        pool.drop(target)

    node = Node(
        **payload.model_dump(exclude={"secret", "key_passphrase", "host_key",
                                      "install_cores"}),
        secret_enc=encrypt_secret(payload.secret),
        key_passphrase_enc=encrypt_secret(payload.key_passphrase),
        host_key=payload.host_key or info.get("host_key", ""),
        status=NodeStatus.ONLINE,
        last_seen=utcnow(),
        installed_cores=ping.get("cores", {}),
        agent_version=ping.get("agent_version", ""),
    )
    db.add(node)
    db.commit()
    sync_service.log(db, "node_added", f"node {node.name} added", target=node.name)

    if payload.install_cores:
        background.add_task(
            _install_cores, node.id, [c.value for c in payload.install_cores]
        )
    return node


@router.patch("/{node_id}", response_model=NodeOut)
def update_node(node_id: int, payload: NodeUpdate, db: Session = Depends(get_db),
                _: Admin = Depends(require_manager)):
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    data = payload.model_dump(exclude_unset=True)
    secret = data.pop("secret", None)
    passphrase = data.pop("key_passphrase", None)
    for key, value in data.items():
        setattr(node, key, value)
    if secret:
        node.secret_enc = encrypt_secret(secret)
    if passphrase is not None:
        node.key_passphrase_enc = encrypt_secret(passphrase)
    db.add(node)
    db.commit()
    pool.drop(target_for(node))
    return node


@router.delete("/{node_id}", response_model=Message)
def delete_node(node_id: int, db: Session = Depends(get_db),
                _: Admin = Depends(require_manager)):
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    name = node.name
    pool.drop(target_for(node))
    db.delete(node)
    db.commit()
    sync_service.log(db, "node_deleted", f"node {name} removed", target=name)
    return Message(message=f"node {name} removed")


@router.post("/{node_id}/install", response_model=Message)
def install_cores(node_id: int, payload: NodeInstallRequest,
                  background: BackgroundTasks, db: Session = Depends(get_db),
                  _: Admin = Depends(require_manager)):
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    node.status = NodeStatus.INSTALLING
    node.status_message = "installing " + ", ".join(c.value for c in payload.cores)
    db.add(node)
    db.commit()
    background.add_task(
        _install_cores, node.id, [c.value for c in payload.cores], payload.options
    )
    return Message(message="installation started in the background")


@router.post("/{node_id}/sync", response_model=dict)
def sync_node(node_id: int, db: Session = Depends(get_db),
              _: Admin = Depends(require_manager)):
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    return sync_service.sync_node(db, node)


@router.post("/{node_id}/reverify", response_model=NodeOut)
def reverify(node_id: int, db: Session = Depends(get_db),
             _: Admin = Depends(require_manager)):
    """Re-pin the host key after a legitimate server rebuild."""
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    node.host_key = ""
    db.add(node)
    db.commit()
    pool.drop(target_for(node))
    agent = agent_for(node)
    try:
        info = agent.probe()
        node.host_key = info.get("host_key", "")
        node.status = NodeStatus.ONLINE
        node.status_message = ""
    except (SSHError, NodeError) as exc:
        node.status = NodeStatus.ERROR
        node.status_message = str(exc)[:500]
    db.add(node)
    db.commit()
    return node


@router.get("/{node_id}/stats", response_model=dict)
def node_stats(node_id: int, db: Session = Depends(get_db),
               _: Admin = Depends(current_admin)):
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    try:
        info = agent_for(node).sysinfo()
    except (SSHError, NodeError) as exc:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc
    _apply_sysinfo(db, node, info)
    return info


@router.get("/{node_id}/logs", response_model=dict)
def node_logs(node_id: int, core: str = "xray", lines: int = 200,
              db: Session = Depends(get_db), _: Admin = Depends(require_manager)):
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    try:
        return agent_for(node).logs(core, lines)
    except (SSHError, NodeError) as exc:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc


@router.post("/{node_id}/collect", response_model=dict)
def collect_traffic(node_id: int, db: Session = Depends(get_db),
                    _: Admin = Depends(require_manager)):
    node = db.query(Node).get(node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "node not found")
    return traffic_service.collect_node(db, node)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _apply_sysinfo(db: Session, node: Node, info: dict) -> None:
    node.cpu_percent = info.get("cpu_percent", 0.0)
    node.mem_percent = (info.get("memory") or {}).get("percent", 0.0)
    node.disk_percent = (info.get("disk") or {}).get("percent", 0.0)
    node.uptime_seconds = info.get("uptime", 0)
    node.net_tx_speed = (info.get("net_speed") or {}).get("tx", 0.0)
    node.net_rx_speed = (info.get("net_speed") or {}).get("rx", 0.0)
    node.installed_cores = info.get("cores", {}) or {}
    node.xray_version = node.installed_cores.get("xray", "")
    node.agent_version = info.get("agent_version", node.agent_version)
    node.status = NodeStatus.ONLINE
    node.status_message = ""
    node.last_seen = utcnow()
    db.add(node)
    db.commit()


def _install_cores(node_id: int, cores: list[str], options: dict | None = None) -> None:
    with session_scope() as db:
        node = db.query(Node).get(node_id)
        if node is None:
            return
        agent = agent_for(node)
        installed = dict(node.installed_cores or {})
        errors = []
        for core in cores:
            try:
                result = agent.install_core(core, (options or {}).get(core, {}))
                installed[core] = result.get("version", "installed")
                if core == CoreType.OPENVPN.value and result.get("ca"):
                    settings = dict(node.installed_cores or {})
                    settings["openvpn_ca"] = result["ca"]
                    settings["openvpn_tls_auth"] = result.get("tls_auth", "")
                    installed.update(settings)
            except (SSHError, NodeError) as exc:
                errors.append(f"{core}: {exc}")
        node.installed_cores = installed
        node.status = NodeStatus.ERROR if errors else NodeStatus.ONLINE
        node.status_message = "; ".join(errors)[:500]
        node.last_seen = utcnow()
        db.add(node)
        db.commit()
        if not errors:
            sync_service.sync_node(db, node)
