#!/usr/bin/env python3
"""Standalone importer: vpn-ui panel -> NimexoPanel.

Copy the old panel's database to this machine and run:

    python3 backend/scripts/migrate_vpnui.py /path/to/vpn-ui.db --inspect
    python3 backend/scripts/migrate_vpnui.py /path/to/vpn-ui.db \
        --group monthly --inbounds 1,2,3 --nodes 1 --dry-run
    python3 backend/scripts/migrate_vpnui.py /path/to/vpn-ui.db --group monthly

The source database is opened read-only; nothing is ever written back to it.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.db import Base, engine, session_scope  # noqa: E402
from app.models import Group  # noqa: E402
from app.models.enums import UserStatus  # noqa: E402
from app.services import migration as migration_service  # noqa: E402


def parse_ids(value: str) -> list[int]:
    return [int(x) for x in value.split(",") if x.strip()] if value else []


def main() -> int:
    parser = argparse.ArgumentParser(description="Import accounts from vpn-ui")
    parser.add_argument("db_path", help="path to vpn-ui.db")
    parser.add_argument("--inspect", action="store_true",
                        help="only describe the source database")
    parser.add_argument("--group", default="", help="target group name")
    parser.add_argument("--inbounds", default="", help="comma separated inbound ids")
    parser.add_argument("--nodes", default="", help="comma separated node ids")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-usage", action="store_true",
                        help="do not carry over consumed traffic")
    parser.add_argument("--new-uuid", action="store_true",
                        help="generate fresh UUIDs instead of reusing the old ones")
    parser.add_argument("--new-sub", action="store_true",
                        help="generate fresh subscription ids (breaks old links)")
    parser.add_argument("--disabled", action="store_true",
                        help="import every account in the disabled state")
    args = parser.parse_args()

    if not os.path.exists(args.db_path):
        print(f"source database not found: {args.db_path}", file=sys.stderr)
        return 2

    if args.inspect:
        print(json.dumps(migration_service.inspect(args.db_path), indent=2,
                         default=str, ensure_ascii=False))
        return 0

    Base.metadata.create_all(engine)
    with session_scope() as db:
        group_id = None
        if args.group:
            group = db.query(Group).filter(Group.name == args.group).one_or_none()
            if group is None:
                print(f"group '{args.group}' does not exist", file=sys.stderr)
                return 2
            group_id = group.id

        result = migration_service.run_import(
            db,
            args.db_path,
            group_id=group_id,
            inbound_ids=parse_ids(args.inbounds),
            node_ids=parse_ids(args.nodes),
            keep_sub_id=not args.new_sub,
            keep_uuid=not args.new_uuid,
            keep_usage=not args.no_usage,
            dry_run=args.dry_run,
            default_status=UserStatus.DISABLED if args.disabled else UserStatus.ACTIVE,
        )

    print(json.dumps({k: v for k, v in result.items() if k != "users"}, indent=2))
    if result["errors"]:
        print("\nfirst errors:", file=sys.stderr)
        for err in result["errors"][:10]:
            print("  -", err, file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
