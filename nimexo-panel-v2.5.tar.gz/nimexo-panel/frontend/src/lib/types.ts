export type UserStatus = "active" | "disabled" | "expired" | "limited" | "on_hold";
export type CoreType = "xray" | "wireguard" | "openvpn" | "ocserv" | "l2tp" | "pptp";
export type Protocol =
  | "vless" | "vmess" | "trojan" | "shadowsocks"
  | "wireguard" | "openvpn" | "ocserv" | "l2tp" | "pptp";

export interface User {
  id: number;
  username: string;
  password: string;
  uuid: string;
  sub_id: string;
  email: string;
  note: string;
  telegram_id: number | null;
  group_id: number | null;
  group_name: string | null;
  status: UserStatus;
  data_limit: number;
  used_traffic: number;
  lifetime_used_traffic: number;
  data_limit_strategy: string;
  device_limit: number;
  expire_at: string | null;
  created_at: string;
  online_at: string | null;
  is_online: boolean;
  subscription_url: string;
  inbound_ids: number[];
  node_ids: number[];
}

export interface Group {
  id: number;
  name: string;
  title: string;
  kind: string;
  description: string;
  data_limit: number;
  duration_days: number;
  device_limit: number;
  data_limit_strategy: string;
  on_hold: boolean;
  price: number;
  max_users: number;
  is_active: boolean;
  is_public: boolean;
  sort_order: number;
  inbound_ids: number[];
  node_ids: number[];
  users_count: number;
}

export interface Node {
  id: number;
  name: string;
  address: string;
  public_address: string;
  country: string;
  ssh_port: number;
  ssh_user: string;
  auth_method: "password" | "key";
  status: "online" | "offline" | "error" | "unknown" | "installing";
  status_message: string;
  last_seen: string | null;
  host_key: string;
  installed_cores: Record<string, string>;
  xray_version: string;
  agent_version: string;
  cpu_percent: number;
  mem_percent: number;
  disk_percent: number;
  uptime_seconds: number;
  net_tx_speed: number;
  net_rx_speed: number;
  up_bytes: number;
  down_bytes: number;
  usage_coefficient: number;
  is_enabled: boolean;
  is_default: boolean;
  note: string;
}

export interface NodeInboundLink {
  node_id: number;
  is_enabled: boolean;
  synced_at: string | null;
  sync_error: string;
  port_override: number | null;
  address_override: string;
}

export interface Inbound {
  id: number;
  tag: string;
  remark: string;
  core: CoreType;
  protocol: Protocol;
  listen: string;
  port: number;
  network: string;
  security: string;
  sni: string;
  host: string;
  path: string;
  service_name: string;
  header_type: string;
  alpn: string;
  fingerprint: string;
  flow: string;
  allow_insecure: boolean;
  reality_public_key: string;
  reality_private_key: string;
  reality_short_ids: string[];
  reality_dest: string;
  reality_server_names: string[];
  cert_path: string;
  key_path: string;
  settings: Record<string, unknown>;
  sniffing: boolean;
  is_enabled: boolean;
  is_default: boolean;
  node_inbounds: NodeInboundLink[];
  users_count: number;
}

export interface Dashboard {
  users_total: number;
  users_active: number;
  users_online: number;
  users_expired: number;
  users_limited: number;
  traffic_total: number;
  traffic_today: number;
  traffic_month: number;
  nodes_total: number;
  nodes_online: number;
  inbounds_total: number;
  protocol_distribution: Record<string, number>;
  top_users: { username: string; used: number; limit: number }[];
  node_status: {
    id: number; name: string; status: string; cpu: number; memory: number;
    disk: number; uptime: number; tx: number; rx: number; country: string;
  }[];
  panel_uptime: number;
  version: string;
}

export interface Connection {
  id: number;
  user_id: number;
  username: string;
  node_id: number | null;
  node_name: string;
  protocol: Protocol | null;
  ip: string;
  up: number;
  down: number;
  started_at: string;
  last_seen: string;
  is_active: boolean;
}

export interface LogEntry {
  id: number;
  created_at: string;
  level: string;
  actor: string;
  action: string;
  target: string;
  message: string;
  ip: string;
}

export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
}

export interface SubInfo {
  username: string;
  status: UserStatus;
  group: string | null;
  data_limit: number;
  used_traffic: number;
  remaining: number | null;
  expire_at: string | null;
  days_left: number | null;
  device_limit: number;
  online: boolean;
  subscription_url: string;
  subscription_qr: string;
  brand: string;
  configs: {
    inbound_id: number;
    node_id: number;
    node: string;
    country: string;
    core: CoreType;
    protocol: Protocol;
    remark: string;
    link?: string;
    download?: string;
    qr?: string;
    credentials?: {
      host: string;
      port?: number;
      username: string;
      password: string;
      psk?: string;
      hint?: string;
    };
  }[];
}

export interface Reseller {
  id: number;
  username: string;
  role: string;
  is_active: boolean;
  note: string;
  telegram_id: number | null;
  traffic_quota: number;
  traffic_used: number;
  traffic_remaining: number | null;
  exhausted: boolean;
  user_quota: number;
  users_total: number;
  users_active: number;
  expire_at: string | null;
  suspend_on_exhausted: boolean;
  allowed_group_ids: number[];
  allowed_inbound_ids: number[];
  allowed_node_ids: number[];
  created_at: string;
  last_login_at: string | null;
}

export interface ResellerTransaction {
  id: number;
  amount: number;
  balance_after: number;
  price: number;
  kind: string;
  note: string;
  created_by: string;
  created_at: string;
}
