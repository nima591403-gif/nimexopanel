const UNITS = ["B", "KB", "MB", "GB", "TB", "PB"];

export function bytes(value?: number | null, digits = 2): string {
  if (value === null || value === undefined) return "—";
  if (value === 0) return "0 B";
  const i = Math.min(Math.floor(Math.log(Math.abs(value)) / Math.log(1024)), UNITS.length - 1);
  return `${(value / 1024 ** i).toFixed(i === 0 ? 0 : digits)} ${UNITS[i]}`;
}

export function speed(value?: number | null): string {
  return `${bytes(value ?? 0, 1)}/s`;
}

export function gb(value?: number | null): number {
  return Math.round(((value ?? 0) / 1024 ** 3) * 100) / 100;
}

export function toBytes(gigabytes: number): number {
  return Math.round(gigabytes * 1024 ** 3);
}

export function unlimited(value?: number | null): boolean {
  return !value;
}

const fa = new Intl.DateTimeFormat("fa-IR", {
  dateStyle: "short",
  timeStyle: "short",
  timeZone: "Asia/Tehran",
});

export function dateTime(value?: string | null): string {
  if (!value) return "—";
  const d = new Date(value.endsWith("Z") ? value : `${value}Z`);
  if (Number.isNaN(d.getTime())) return "—";
  return fa.format(d);
}

export function dateOnly(value?: string | null): string {
  if (!value) return "نامحدود";
  const d = new Date(value.endsWith("Z") ? value : `${value}Z`);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("fa-IR", {
    dateStyle: "medium",
    timeZone: "Asia/Tehran",
  }).format(d);
}

export function daysLeft(value?: string | null): number | null {
  if (!value) return null;
  const d = new Date(value.endsWith("Z") ? value : `${value}Z`).getTime();
  if (Number.isNaN(d)) return null;
  return Math.max(0, Math.ceil((d - Date.now()) / 86_400_000));
}

export function duration(seconds?: number | null): string {
  if (!seconds) return "—";
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  parts.push(`${m}m`);
  return parts.join(" ");
}

export function number(value?: number | null): string {
  return new Intl.NumberFormat("fa-IR").format(value ?? 0);
}

export function toman(value?: number | null): string {
  return `${new Intl.NumberFormat("fa-IR").format(value ?? 0)} تومان`;
}

export function percent(part: number, total: number): number {
  if (!total) return 0;
  return Math.min(100, Math.round((part / total) * 100));
}
