import { useEffect, useState } from "react";

import { Card, Chip, Empty, Spinner } from "../components/ui";
import { api } from "../lib/api";
import { dateTime } from "../lib/format";
import type { LogEntry } from "../lib/types";

export default function Logs() {
  const [rows, setRows] = useState<LogEntry[]>([]);
  const [search, setSearch] = useState("");
  const [level, setLevel] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams({ limit: "300" });
    if (search) params.set("search", search);
    if (level) params.set("level", level);
    const t = setTimeout(() => {
      setLoading(true);
      api
        .get<LogEntry[]>(`/api/logs?${params}`)
        .then(setRows)
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [search, level]);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">لاگ‌ها</h1>
        <p className="mt-1 text-xs text-ink-400">رویدادهای پنل: ورود، تغییر کاربران، نودها</p>
      </div>

      <Card>
        <div className="mb-4 grid gap-3 sm:grid-cols-3">
          <input
            className="input sm:col-span-2"
            placeholder="جستجو در متن رویداد…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select className="input" value={level} onChange={(e) => setLevel(e.target.value)}>
            <option value="">همه سطوح</option>
            <option value="info">اطلاع</option>
            <option value="warning">هشدار</option>
            <option value="error">خطا</option>
          </select>
        </div>

        {loading ? (
          <div className="grid place-items-center py-12">
            <Spinner className="h-6 w-6" />
          </div>
        ) : !rows.length ? (
          <Empty text="رویدادی ثبت نشده است." />
        ) : (
          <div className="space-y-2">
            {rows.map((log) => (
              <div
                key={log.id}
                className="flex flex-wrap items-center gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2 text-sm"
              >
                <Chip tone={log.level === "info" ? "default" : "brand"}>{log.action}</Chip>
                <span className="flex-1">{log.message}</span>
                <span className="text-[11px] text-ink-500">{log.actor}</span>
                {log.ip && (
                  <span className="font-mono text-[11px] text-ink-600" dir="ltr">
                    {log.ip}
                  </span>
                )}
                <span className="text-[11px] text-ink-500">{dateTime(log.created_at)}</span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
