import { useEffect, useState } from "react";

import { Card, Chip, Empty, Field, Modal, MultiSelect, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import { bytes, gb, number, toBytes, toman } from "../lib/format";
import type { Group, Inbound, Node } from "../lib/types";

const KINDS = [
  { value: "test", label: "تست" },
  { value: "daily", label: "روزانه" },
  { value: "monthly", label: "ماهانه" },
  { value: "multi_month", label: "چند ماهه" },
  { value: "custom", label: "سفارشی" },
];

const STRATEGIES = [
  { value: "no_reset", label: "بدون بازنشانی" },
  { value: "day", label: "روزانه" },
  { value: "week", label: "هفتگی" },
  { value: "month", label: "ماهانه" },
];

interface FormState {
  id?: number;
  name: string;
  title: string;
  kind: string;
  description: string;
  data_limit_gb: number;
  duration_days: number;
  device_limit: number;
  data_limit_strategy: string;
  on_hold: boolean;
  price: number;
  max_users: number;
  is_active: boolean;
  is_public: boolean;
  inbound_ids: number[];
  node_ids: number[];
}

const EMPTY: FormState = {
  name: "",
  title: "",
  kind: "monthly",
  description: "",
  data_limit_gb: 50,
  duration_days: 30,
  device_limit: 2,
  data_limit_strategy: "no_reset",
  on_hold: false,
  price: 0,
  max_users: 0,
  is_active: true,
  is_public: true,
  inbound_ids: [],
  node_ids: [],
};

export default function Groups() {
  const toast = useToast();
  const [groups, setGroups] = useState<Group[]>([]);
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [form, setForm] = useState<FormState | null>(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api
      .get<Group[]>("/api/groups")
      .then(setGroups)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    api.get<Inbound[]>("/api/inbounds").then(setInbounds).catch(() => {});
    api.get<Node[]>("/api/nodes").then(setNodes).catch(() => {});
  }, []);

  const save = async () => {
    if (!form) return;
    setSaving(true);
    const payload = {
      name: form.name,
      title: form.title,
      kind: form.kind,
      description: form.description,
      data_limit: toBytes(form.data_limit_gb),
      duration_days: form.duration_days,
      device_limit: form.device_limit,
      data_limit_strategy: form.data_limit_strategy,
      on_hold: form.on_hold,
      price: form.price,
      max_users: form.max_users,
      is_active: form.is_active,
      is_public: form.is_public,
      inbound_ids: form.inbound_ids,
      node_ids: form.node_ids,
    };
    try {
      if (form.id) await api.patch(`/api/groups/${form.id}`, payload);
      else await api.post("/api/groups", payload);
      toast("ذخیره شد");
      setForm(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (group: Group) => {
    if (!confirm(`گروه ${group.title || group.name} حذف شود؟`)) return;
    try {
      await api.del(`/api/groups/${group.id}`);
      toast("حذف شد");
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">گروه‌ها و پلن‌ها</h1>
          <p className="mt-1 text-xs text-ink-400">
            حجم، مدت، تعداد دستگاه و پروتکل‌های مجاز هر پلن را اینجا تعریف کنید
          </p>
        </div>
        <button className="btn-primary" onClick={() => setForm({ ...EMPTY })}>
          + گروه جدید
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : !groups.length ? (
        <Empty text="هنوز گروهی ساخته نشده — مثلاً «تست ۱ روزه»، «ماهانه ۵۰ گیگ»." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {groups.map((g) => (
            <Card key={g.id}>
              <div className="mb-3 flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-semibold">{g.title || g.name}</h3>
                  <p className="text-[11px] text-ink-500">{g.name}</p>
                </div>
                <Chip tone={g.is_active ? "green" : "default"}>
                  {g.is_active ? "فعال" : "غیرفعال"}
                </Chip>
              </div>
              <dl className="space-y-1.5 text-xs text-ink-300">
                <Line k="حجم" v={g.data_limit ? bytes(g.data_limit) : "نامحدود"} />
                <Line k="مدت" v={g.duration_days ? `${number(g.duration_days)} روز` : "بدون انقضا"} />
                <Line k="دستگاه هم‌زمان" v={g.device_limit || "نامحدود"} />
                <Line k="قیمت" v={g.price ? toman(g.price) : "—"} />
                <Line k="کاربران" v={`${number(g.users_count)}${g.max_users ? ` / ${g.max_users}` : ""}`} />
                <Line k="اینباندها" v={`${g.inbound_ids.length} مورد`} />
                <Line k="لوکیشن‌ها" v={g.node_ids.length ? `${g.node_ids.length} نود` : "همه نودها"} />
              </dl>
              <div className="mt-4 flex gap-2">
                <button
                  className="btn-ghost flex-1 text-xs"
                  onClick={() =>
                    setForm({
                      id: g.id,
                      name: g.name,
                      title: g.title,
                      kind: g.kind,
                      description: g.description,
                      data_limit_gb: gb(g.data_limit),
                      duration_days: g.duration_days,
                      device_limit: g.device_limit,
                      data_limit_strategy: g.data_limit_strategy,
                      on_hold: g.on_hold,
                      price: g.price,
                      max_users: g.max_users,
                      is_active: g.is_active,
                      is_public: g.is_public,
                      inbound_ids: g.inbound_ids,
                      node_ids: g.node_ids,
                    })
                  }
                >
                  ویرایش
                </button>
                <button className="btn-danger text-xs" onClick={() => remove(g)}>
                  حذف
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={form?.id ? "ویرایش گروه" : "گروه جدید"}
        wide
        footer={
          <>
            <button className="btn-ghost" onClick={() => setForm(null)}>
              انصراف
            </button>
            <button className="btn-primary" onClick={save} disabled={saving}>
              {saving ? <Spinner /> : "ذخیره"}
            </button>
          </>
        }
      >
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="شناسه (انگلیسی)">
              <input
                className="input"
                value={form.name}
                disabled={!!form.id}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </Field>
            <Field label="نام نمایشی">
              <input
                className="input"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </Field>
            <Field label="نوع">
              <select
                className="input"
                value={form.kind}
                onChange={(e) => setForm({ ...form, kind: e.target.value })}
              >
                {KINDS.map((k) => (
                  <option key={k.value} value={k.value}>
                    {k.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="بازنشانی دوره‌ای حجم">
              <select
                className="input"
                value={form.data_limit_strategy}
                onChange={(e) => setForm({ ...form, data_limit_strategy: e.target.value })}
              >
                {STRATEGIES.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="حجم (گیگابایت)" hint="۰ = نامحدود">
              <input
                type="number"
                className="input"
                value={form.data_limit_gb}
                onChange={(e) => setForm({ ...form, data_limit_gb: Number(e.target.value) })}
              />
            </Field>
            <Field label="مدت (روز)">
              <input
                type="number"
                className="input"
                value={form.duration_days}
                onChange={(e) => setForm({ ...form, duration_days: Number(e.target.value) })}
              />
            </Field>
            <Field label="دستگاه هم‌زمان" hint="۰ = نامحدود">
              <input
                type="number"
                className="input"
                value={form.device_limit}
                onChange={(e) => setForm({ ...form, device_limit: Number(e.target.value) })}
              />
            </Field>
            <Field label="قیمت (تومان)">
              <input
                type="number"
                className="input"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
              />
            </Field>
            <Field label="سقف تعداد کاربر" hint="۰ = نامحدود">
              <input
                type="number"
                className="input"
                value={form.max_users}
                onChange={(e) => setForm({ ...form, max_users: Number(e.target.value) })}
              />
            </Field>
            <div className="flex items-end gap-4">
              <Toggle
                checked={form.on_hold}
                onChange={(v) => setForm({ ...form, on_hold: v })}
                label="شروع از اولین اتصال"
              />
              <Toggle
                checked={form.is_active}
                onChange={(v) => setForm({ ...form, is_active: v })}
                label="فعال"
              />
            </div>
            <Field label="توضیحات" className="sm:col-span-2">
              <input
                className="input"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </Field>
            <Field label="اینباندهای مجاز" className="sm:col-span-2">
              <MultiSelect
                options={inbounds}
                selected={form.inbound_ids}
                onChange={(ids) => setForm({ ...form, inbound_ids: ids })}
                render={(i) => `${i.remark || i.tag} · ${i.protocol}`}
              />
            </Field>
            <Field
              label="لوکیشن‌های مجاز"
              hint="خالی بگذارید تا کاربر به همه نودها دسترسی داشته باشد"
              className="sm:col-span-2"
            >
              <MultiSelect
                options={nodes}
                selected={form.node_ids}
                onChange={(ids) => setForm({ ...form, node_ids: ids })}
                render={(n) => `${n.country ? n.country + " " : ""}${n.name}`}
              />
            </Field>
          </div>
        )}
      </Modal>
    </div>
  );
}

function Line({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between">
      <dt className="text-ink-500">{k}</dt>
      <dd className="tabular-nums">{v}</dd>
    </div>
  );
}
