import { useEffect, useState } from "react";

import {
  Card,
  Chip,
  Empty,
  Field,
  Modal,
  Progress,
  Spinner,
  StatusBadge,
  Toggle,
  useToast,
} from "../components/ui";
import { api } from "../lib/api";
import { bytes, dateTime, duration, speed } from "../lib/format";
import type { Node } from "../lib/types";

const CORES = [
  { value: "xray", label: "Xray / V2ray", hint: "VLESS، VMess، Trojan، Shadowsocks" },
  { value: "wireguard", label: "WireGuard", hint: "سریع و سبک" },
  { value: "openvpn", label: "OpenVPN", hint: "نصبش چند دقیقه طول می‌کشد (dhparam)" },
  { value: "ocserv", label: "OpenConnect / Cisco", hint: "AnyConnect" },
  { value: "l2tp", label: "L2TP/IPsec", hint: "strongSwan + xl2tpd" },
  { value: "pptp", label: "PPTP", hint: "به GRE نیاز دارد — از ایران معمولاً فیلتر است" },
];

interface FormState {
  id?: number;
  name: string;
  address: string;
  public_address: string;
  country: string;
  ssh_port: number;
  ssh_user: string;
  auth_method: "password" | "key";
  secret: string;
  key_passphrase: string;
  host_key: string;
  usage_coefficient: number;
  is_enabled: boolean;
  note: string;
  install_cores: string[];
}

const EMPTY: FormState = {
  name: "",
  address: "",
  public_address: "",
  country: "",
  ssh_port: 22,
  ssh_user: "root",
  auth_method: "password",
  secret: "",
  key_passphrase: "",
  host_key: "",
  usage_coefficient: 1,
  is_enabled: true,
  note: "",
  install_cores: ["xray"],
};

export default function Nodes() {
  const toast = useToast();
  const [nodes, setNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState | null>(null);
  const [busy, setBusy] = useState(false);
  const [testResult, setTestResult] = useState<string>("");
  const [logs, setLogs] = useState<{ node: Node; text: string } | null>(null);
  const [install, setInstall] = useState<{ node: Node; cores: string[] } | null>(null);

  const load = () => {
    setLoading(true);
    api
      .get<Node[]>("/api/nodes")
      .then(setNodes)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 20_000);
    return () => clearInterval(t);
  }, []);

  const test = async () => {
    if (!form) return;
    setBusy(true);
    setTestResult("");
    try {
      const res = await api.post<{ host_key: string; uname: string; root: boolean }>(
        "/api/nodes/test",
        {
          address: form.address,
          ssh_port: form.ssh_port,
          ssh_user: form.ssh_user,
          auth_method: form.auth_method,
          secret: form.secret,
          key_passphrase: form.key_passphrase,
          host_key: form.host_key,
        },
      );
      setForm({ ...form, host_key: res.host_key || form.host_key });
      setTestResult(`اتصال برقرار شد — ${res.uname.slice(0, 60)}`);
      toast("اتصال SSH موفق بود");
    } catch (e) {
      setTestResult(e instanceof Error ? e.message : "خطا");
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const save = async () => {
    if (!form) return;
    setBusy(true);
    try {
      if (form.id) {
        const { id, install_cores, ...rest } = form;
        await api.patch(`/api/nodes/${id}`, rest);
      } else {
        await api.post("/api/nodes", form);
      }
      toast("ذخیره شد — نصب هسته‌ها در پس‌زمینه انجام می‌شود");
      setForm(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const action = async (node: Node, path: string, message: string) => {
    try {
      await api.post(`/api/nodes/${node.id}/${path}`);
      toast(message);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    }
  };

  /** Sync returns a per-core report; a failing core must not look like success. */
  const syncNode = async (node: Node) => {
    try {
      const report = await api.post<Record<string, { ok?: boolean; error?: string }>>(
        `/api/nodes/${node.id}/sync`,
      );
      const failed = Object.entries(report).filter(([, r]) => r && r.ok === false);
      if (failed.length) {
        failed.forEach(([core, r]) =>
          toast(`${core}: ${(r.error || "خطای نامشخص").slice(0, 300)}`, "error"),
        );
      } else {
        toast("همگام‌سازی انجام شد");
      }
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    }
  };

  const runInstall = async () => {
    if (!install) return;
    if (!install.cores.length) return toast("هسته‌ای انتخاب نشده", "error");
    setBusy(true);
    try {
      await api.post(`/api/nodes/${install.node.id}/install`, { cores: install.cores });
      toast("نصب در پس‌زمینه شروع شد — چند دقیقه بعد کارت نود را ببین");
      setInstall(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const openLogs = async (node: Node) => {
    try {
      const res = await api.get<{ logs: string }>(`/api/nodes/${node.id}/logs?core=xray&lines=200`);
      setLogs({ node, text: res.logs });
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">نودها</h1>
          <p className="mt-1 text-xs text-ink-400">
            نصب هسته‌های VPN روی سرورهای دیگر از طریق SSH — فقط با IP، پورت و اطلاعات ورود.
            کاربران به‌طور خودکار با هر نود همگام می‌مانند و کلید میزبان SSH در لحظه‌ی افزودن
            پین می‌شود.
          </p>
        </div>
        <button className="btn-primary" onClick={() => setForm({ ...EMPTY })}>
          + افزودن نود
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : !nodes.length ? (
        <Empty text="هنوز نودی اضافه نشده — یکی اضافه کنید تا هسته‌های VPN را از طریق SSH روی آن نصب کنید." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {nodes.map((node) => (
            <Card key={node.id}>
              <div className="mb-3 flex items-start justify-between gap-2">
                <div>
                  <h3 className="flex items-center gap-2 font-semibold">
                    {node.country && <span>{node.country}</span>}
                    {node.name}
                    {node.is_default && <Chip tone="brand">پیش‌فرض</Chip>}
                  </h3>
                  <p className="font-mono text-[11px] text-ink-500">
                    {node.address}:{node.ssh_port} · {node.ssh_user}
                  </p>
                </div>
                <StatusBadge status={node.status} />
              </div>

              {node.status_message && (
                <p className="mb-3 rounded-lg bg-rose-500/10 px-3 py-2 text-[11px] text-rose-300">
                  {node.status_message}
                </p>
              )}

              <div className="mb-3 grid grid-cols-3 gap-3 text-xs text-ink-400">
                <Metric label="پردازنده" value={node.cpu_percent} />
                <Metric label="حافظه" value={node.mem_percent} />
                <Metric label="دیسک" value={node.disk_percent} />
              </div>

              <div className="mb-3 flex flex-wrap gap-3 text-[11px] text-ink-500">
                <span>↑ {speed(node.net_tx_speed)}</span>
                <span>↓ {speed(node.net_rx_speed)}</span>
                <span>کارکرد: {duration(node.uptime_seconds)}</span>
                <span>آخرین بررسی: {dateTime(node.last_seen)}</span>
              </div>

              <div className="mb-3 flex flex-wrap gap-1.5">
                {Object.entries(node.installed_cores || {})
                  .filter(([k]) => !k.startsWith("openvpn_"))
                  .map(([core, version]) => (
                    <Chip key={core} tone="green">
                      {core} {version !== "installed" ? version : ""}
                    </Chip>
                  ))}
                {!Object.keys(node.installed_cores || {}).length && (
                  <span className="text-[11px] text-ink-500">هسته‌ای نصب نشده</span>
                )}
              </div>

              {node.host_key && (
                <p className="mb-3 truncate font-mono text-[10px] text-ink-600">
                  کلید میزبان: {node.host_key}
                </p>
              )}

              <div className="flex flex-wrap gap-2">
                <button
                  className="btn-primary text-xs"
                  onClick={() =>
                    setInstall({
                      node,
                      cores: CORES.filter(
                        (c) => !(node.installed_cores || {})[c.value],
                      ).map((c) => c.value),
                    })
                  }
                >
                  + نصب هسته
                </button>
                <button className="btn-ghost text-xs" onClick={() => syncNode(node)}>
                  همگام‌سازی
                </button>
                <button className="btn-ghost text-xs" onClick={() => action(node, "collect", "آمار خوانده شد")}>
                  آمار
                </button>
                <button className="btn-ghost text-xs" onClick={() => openLogs(node)}>
                  لاگ
                </button>
                <button
                  className="btn-ghost text-xs"
                  onClick={() => action(node, "reverify", "کلید میزبان دوباره پین شد")}
                >
                  تأیید مجدد
                </button>
                <button
                  className="btn-ghost text-xs"
                  onClick={() =>
                    setForm({
                      id: node.id,
                      name: node.name,
                      address: node.address,
                      public_address: node.public_address,
                      country: node.country,
                      ssh_port: node.ssh_port,
                      ssh_user: node.ssh_user,
                      auth_method: node.auth_method,
                      secret: "",
                      key_passphrase: "",
                      host_key: node.host_key,
                      usage_coefficient: node.usage_coefficient,
                      is_enabled: node.is_enabled,
                      note: node.note,
                      install_cores: [],
                    })
                  }
                >
                  ویرایش
                </button>
                <button
                  className="btn-danger text-xs"
                  onClick={async () => {
                    if (!confirm(`نود ${node.name} حذف شود؟`)) return;
                    await api.del(`/api/nodes/${node.id}`);
                    toast("حذف شد");
                    load();
                  }}
                >
                  حذف
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={form?.id ? "ویرایش نود" : "افزودن نود"}
        wide
        footer={
          <>
            <button className="btn-ghost" onClick={() => setForm(null)}>
              انصراف
            </button>
            <button className="btn-ghost" onClick={test} disabled={busy}>
              تست اتصال
            </button>
            <button className="btn-primary" onClick={save} disabled={busy}>
              {busy ? <Spinner /> : form?.id ? "ذخیره" : "تست و افزودن"}
            </button>
          </>
        }
      >
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="نام">
              <input
                className="input"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </Field>
            <Field label="پرچم / کد کشور" hint="مثلاً 🇩🇪 یا DE">
              <input
                className="input"
                value={form.country}
                onChange={(e) => setForm({ ...form, country: e.target.value })}
              />
            </Field>
            <Field label="هاست / IP">
              <input
                className="input font-mono"
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
              />
            </Field>
            <Field label="آدرس عمومی برای کاربران" hint="اگر پشت تونل یا دامنه است">
              <input
                className="input font-mono"
                value={form.public_address}
                placeholder="خالی = همان IP بالا"
                onChange={(e) => setForm({ ...form, public_address: e.target.value })}
              />
            </Field>
            <Field label="پورت SSH">
              <input
                type="number"
                className="input"
                value={form.ssh_port}
                onChange={(e) => setForm({ ...form, ssh_port: Number(e.target.value) })}
              />
            </Field>
            <Field label="نام کاربری SSH" hint="root یا کاربری با sudo -n">
              <input
                className="input"
                value={form.ssh_user}
                onChange={(e) => setForm({ ...form, ssh_user: e.target.value })}
              />
            </Field>
            <Field label="روش احراز هویت">
              <select
                className="input"
                value={form.auth_method}
                onChange={(e) =>
                  setForm({ ...form, auth_method: e.target.value as "password" | "key" })
                }
              >
                <option value="password">گذرواژه</option>
                <option value="key">کلید خصوصی</option>
              </select>
            </Field>
            <Field
              label={form.auth_method === "password" ? "گذرواژه SSH" : "کلید خصوصی"}
              hint={form.id ? "خالی بگذارید تا تغییر نکند" : ""}
            >
              {form.auth_method === "password" ? (
                <input
                  type="password"
                  className="input"
                  value={form.secret}
                  onChange={(e) => setForm({ ...form, secret: e.target.value })}
                />
              ) : (
                <textarea
                  className="input h-24 font-mono text-[11px]"
                  value={form.secret}
                  placeholder="-----BEGIN OPENSSH PRIVATE KEY-----"
                  onChange={(e) => setForm({ ...form, secret: e.target.value })}
                />
              )}
            </Field>
            <Field label="ضریب مصرف" hint="۱ = عادی، ۲ = هر بایت دوبرابر حساب شود">
              <input
                type="number"
                step="0.1"
                className="input"
                value={form.usage_coefficient}
                onChange={(e) => setForm({ ...form, usage_coefficient: Number(e.target.value) })}
              />
            </Field>
            <div className="flex items-end">
              <Toggle
                checked={form.is_enabled}
                onChange={(v) => setForm({ ...form, is_enabled: v })}
                label="فعال"
              />
            </div>
            {!form.id && (
              <Field label="هسته‌هایی که نصب شوند" className="sm:col-span-2">
                <div className="flex flex-wrap gap-2">
                  {CORES.map((core) => {
                    const on = form.install_cores.includes(core.value);
                    return (
                      <button
                        key={core.value}
                        type="button"
                        className={
                          on
                            ? "rounded-lg border border-brand-500 bg-brand-500/20 px-3 py-1.5 text-xs text-brand-200"
                            : "rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-ink-300"
                        }
                        onClick={() =>
                          setForm({
                            ...form,
                            install_cores: on
                              ? form.install_cores.filter((c) => c !== core.value)
                              : [...form.install_cores, core.value],
                          })
                        }
                      >
                        {core.label}
                      </button>
                    );
                  })}
                </div>
              </Field>
            )}
            {form.host_key && (
              <Field label="کلید میزبان (پین‌شده)" className="sm:col-span-2">
                <input className="input font-mono text-[11px]" readOnly value={form.host_key} />
              </Field>
            )}
            {testResult && (
              <p className="sm:col-span-2 rounded-lg bg-white/5 px-3 py-2 text-[11px] text-ink-300">
                {testResult}
              </p>
            )}
          </div>
        )}
      </Modal>

      {/* install cores on an existing node */}
      <Modal
        open={!!install}
        onClose={() => setInstall(null)}
        title={`نصب هسته روی ${install?.node.name || ""}`}
        footer={
          <>
            <button className="btn-ghost" onClick={() => setInstall(null)}>
              انصراف
            </button>
            <button className="btn-primary" onClick={runInstall} disabled={busy}>
              {busy ? <Spinner /> : "شروع نصب"}
            </button>
          </>
        }
      >
        {install && (
          <div className="space-y-2">
            {CORES.map((core) => {
              const installed = (install.node.installed_cores || {})[core.value];
              const checked = install.cores.includes(core.value);
              return (
                <button
                  key={core.value}
                  type="button"
                  onClick={() =>
                    setInstall({
                      ...install,
                      cores: checked
                        ? install.cores.filter((c) => c !== core.value)
                        : [...install.cores, core.value],
                    })
                  }
                  className={
                    "flex w-full items-center justify-between gap-3 rounded-xl border px-3 py-2.5 text-right transition " +
                    (checked
                      ? "border-brand-500 bg-brand-500/15"
                      : "border-white/10 bg-white/5 hover:border-white/20")
                  }
                >
                  <span>
                    <span className="block text-sm">{core.label}</span>
                    <span className="block text-[11px] text-ink-500">{core.hint}</span>
                  </span>
                  {installed ? (
                    <Chip tone="green">نصب‌شده {installed !== "installed" ? installed : ""}</Chip>
                  ) : (
                    <Chip>نصب نشده</Chip>
                  )}
                </button>
              );
            })}
            <p className="pt-2 text-[11px] leading-5 text-ink-500">
              نصب در پس‌زمینه انجام می‌شود و بسته به هسته چند دقیقه طول می‌کشد.
              هسته‌ای که از قبل نصب است دوباره نصب نمی‌شود، فقط تنظیماتش بازنویسی می‌گردد.
              بعد از نصب، یادت باشد پورت هر پروتکل را در فایروال باز کنی.
            </p>
          </div>
        )}
      </Modal>

      <Modal open={!!logs} onClose={() => setLogs(null)} title={`لاگ ${logs?.node.name || ""}`} wide>
        <pre className="max-h-[55vh] overflow-auto rounded-xl bg-ink-950 p-3 text-left font-mono text-[11px] leading-5 text-ink-300" dir="ltr">
          {logs?.text || "خالی"}
        </pre>
      </Modal>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-1 flex justify-between">
        <span>{label}</span>
        <span className="tabular-nums">{value.toFixed(0)}%</span>
      </div>
      <Progress value={value} total={100} />
    </div>
  );
}
