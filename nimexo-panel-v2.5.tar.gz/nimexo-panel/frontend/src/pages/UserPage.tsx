import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import {
  CopyButton,
  Progress,
  QrButton,
  Spinner,
  StatusBadge,
  useToast,
} from "../components/ui";
import { api } from "../lib/api";
import { bytes, dateOnly, number } from "../lib/format";
import type { SubInfo } from "../lib/types";

const CORE_STYLE: Record<string, { color: string; icon: string; title: string; bullets: string[] }> = {
  xray: {
    color: "from-brand-600 to-brand-400",
    icon: "◆",
    title: "V2ray / Xray",
    bullets: ["عبور از فیلترینگ", "سرعت بالا", "پشتیبانی همه دستگاه‌ها"],
  },
  openvpn: {
    color: "from-orange-600 to-orange-400",
    icon: "◷",
    title: "OpenVPN",
    bullets: ["امنیت بسیار بالا", "قابلیت عبور از فیلترینگ", "پروتکل متن‌باز"],
  },
  wireguard: {
    color: "from-rose-600 to-rose-400",
    icon: "☀",
    title: "WireGuard",
    bullets: ["سرعت فوق‌العاده", "مصرف کم باتری", "سبک و مدرن"],
  },
  ocserv: {
    color: "from-sky-600 to-sky-400",
    icon: "⛨",
    title: "Cisco AnyConnect",
    bullets: ["پایدار روی موبایل", "سازگار با همه دستگاه‌ها", "امنیت سطح بالا"],
  },
  l2tp: {
    color: "from-violet-600 to-violet-400",
    icon: "⛨",
    title: "L2TP / IPsec",
    bullets: ["سرعت بالا و پایدار", "سازگار با همه دستگاه‌ها", "بدون نیاز به برنامه"],
  },
  pptp: {
    color: "from-teal-600 to-teal-400",
    icon: "⛨",
    title: "PPTP",
    bullets: ["ساده و سبک", "پشتیبانی داخلی در ویندوز", "بدون نیاز به برنامه"],
  },
};

/** Username/password protocols have no share link — show the fields instead. */
function CredentialCard({
  credentials,
  label,
}: {
  credentials: NonNullable<SubInfo["configs"][number]["credentials"]>;
  label: string;
}) {
  const rows: [string, string][] = [
    ["آدرس سرور", credentials.port ? `${credentials.host}:${credentials.port}` : credentials.host],
    ["نام کاربری", credentials.username],
    ["گذرواژه", credentials.password],
  ];
  if (credentials.psk) rows.push(["کلید مشترک (PSK)", credentials.psk]);

  return (
    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
      <p className="mb-2 text-sm">{label}</p>
      <div className="space-y-2">
        {rows.map(([key, value]) => (
          <div key={key} className="flex items-center gap-2">
            <span className="w-28 shrink-0 text-[11px] text-ink-400">{key}</span>
            <input className="input font-mono text-[11px]" readOnly dir="ltr" value={value} />
            <CopyButton value={value} />
          </div>
        ))}
      </div>
      {credentials.hint && (
        <p className="mt-2 text-[11px] leading-5 text-ink-500">{credentials.hint}</p>
      )}
    </div>
  );
}

/** Download a config through fetch so a server-side error is actually shown. */
function DownloadButton({ url, name }: { url: string; name: string }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const go = async () => {
    setBusy(true);
    try {
      const res = await fetch(url);
      const text = await res.text();
      if (!res.ok) {
        let message = text;
        try {
          message = JSON.parse(text).detail || text;
        } catch {
          /* plain text error */
        }
        throw new Error(message);
      }
      const blob = new Blob([text], { type: "application/octet-stream" });
      const href = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = href;
      link.download = name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(href), 1000);
    } catch (e) {
      toast(e instanceof Error ? e.message : "دانلود ناموفق بود", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <button className="btn-ghost px-2.5 py-1 text-xs" onClick={go} disabled={busy}>
      {busy ? <Spinner /> : "دریافت کانفیگ"}
    </button>
  );
}

export default function UserPage() {
  const { subId } = useParams();
  const [info, setInfo] = useState<SubInfo | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get<SubInfo>(`/api/sub/${subId}/info`)
      .then(setInfo)
      .catch((e) => setError(e.message));
  }, [subId]);

  if (error)
    return (
      <div className="grid min-h-screen place-items-center p-6 text-center">
        <div className="card max-w-sm">
          <p className="mb-2 text-4xl">🔎</p>
          <h1 className="mb-1 font-bold">اشتراک پیدا نشد</h1>
          <p className="text-xs text-ink-400">{error}</p>
          <a className="btn-ghost mt-4 inline-flex" href="/migrate">
            انتقال حساب از پنل قبلی
          </a>
        </div>
      </div>
    );

  if (!info)
    return (
      <div className="grid min-h-screen place-items-center">
        <Spinner className="h-6 w-6 text-brand-400" />
      </div>
    );

  const grouped = info.configs.reduce<Record<string, typeof info.configs>>((acc, cfg) => {
    (acc[cfg.core] ||= []).push(cfg);
    return acc;
  }, {});

  return (
    <div className="mx-auto max-w-2xl space-y-5 p-4 pb-16">
      <header className="pt-6 text-center">
        <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-brand-400 text-2xl font-bold text-white shadow-glow">
          N
        </span>
        <h1 className="text-lg font-bold">{info.username}</h1>
        <div className="mt-2 flex justify-center gap-2">
          <StatusBadge status={info.status} />
          {info.group && (
            <span className="badge bg-white/5 text-ink-300">{info.group}</span>
          )}
        </div>
      </header>

      <section className="card">
        <div className="mb-4 grid grid-cols-3 gap-3 text-center">
          <div>
            <p className="text-[11px] text-ink-400">حجم مصرفی</p>
            <p className="mt-1 font-bold tabular-nums">{bytes(info.used_traffic)}</p>
          </div>
          <div>
            <p className="text-[11px] text-ink-400">حجم باقی‌مانده</p>
            <p className="mt-1 font-bold tabular-nums">
              {info.data_limit ? bytes(info.remaining) : "نامحدود"}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-ink-400">روز باقی‌مانده</p>
            <p className="mt-1 font-bold tabular-nums">
              {info.days_left === null ? "∞" : number(info.days_left)}
            </p>
          </div>
        </div>
        <Progress
          value={info.used_traffic}
          total={info.data_limit || info.used_traffic || 1}
          className="h-2"
        />
        <div className="mt-2 flex justify-between text-[11px] text-ink-500">
          <span>{info.data_limit ? bytes(info.data_limit) : "بدون محدودیت"}</span>
          <span>انقضا: {dateOnly(info.expire_at)}</span>
        </div>
        {info.device_limit > 0 && (
          <p className="mt-3 text-[11px] text-ink-500">
            حداکثر {number(info.device_limit)} دستگاه هم‌زمان
          </p>
        )}
      </section>

      <section className="card">
        <h2 className="mb-2 text-sm font-semibold">لینک اشتراک</h2>
        <p className="mb-3 text-[11px] text-ink-400">
          این لینک را در برنامه‌هایی مثل v2rayNG، Streisand، Hiddify یا V2Box وارد کنید.
        </p>
        <div className="flex gap-2">
          <input
            className="input font-mono text-[11px]"
            readOnly
            dir="ltr"
            value={info.subscription_url}
          />
          <CopyButton value={info.subscription_url} />
          <QrButton url={info.subscription_qr} title="QR لینک اشتراک" />
        </div>
      </section>

      {Object.entries(grouped).map(([core, configs]) => {
        const style = CORE_STYLE[core] || CORE_STYLE.xray;
        return (
          <section key={core} className="card">
            <div className="mb-3 flex items-center gap-3">
              <span
                className={`grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br ${style.color} text-lg text-white`}
              >
                {style.icon}
              </span>
              <div>
                <h3 className="font-semibold">{style.title}</h3>
                <p className="text-[11px] text-emerald-400">● فعال</p>
              </div>
            </div>
            <ul className="mb-4 space-y-1 text-[11px] text-ink-400">
              {style.bullets.map((b) => (
                <li key={b}>• {b}</li>
              ))}
            </ul>
            <div className="space-y-2">
              {configs.map((cfg) =>
                cfg.credentials ? (
                  <CredentialCard
                    key={`${cfg.inbound_id}-${cfg.node_id}`}
                    credentials={cfg.credentials}
                    label={`${cfg.country ? cfg.country + " " : ""}${cfg.node}`}
                  />
                ) : (
                  <div
                    key={`${cfg.inbound_id}-${cfg.node_id}`}
                    className="flex items-center justify-between gap-2 rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
                  >
                    <span className="text-sm">
                      {cfg.country && <span className="ml-1">{cfg.country}</span>}
                      {cfg.node}
                      <span className="block text-[10px] text-ink-500">{cfg.remark}</span>
                    </span>
                    <span className="flex shrink-0 gap-1">
                      {cfg.link && <CopyButton value={cfg.link} label="کپی کانفیگ" />}
                      {cfg.download && (
                        <DownloadButton
                          url={cfg.download}
                          name={`${info.username}-${cfg.node}.${
                            cfg.core === "wireguard" ? "conf" : "ovpn"
                          }`}
                        />
                      )}
                      {cfg.qr && (
                        <QrButton
                          url={cfg.qr}
                          title={`QR — ${cfg.node} · ${cfg.remark}`}
                        />
                      )}
                    </span>
                  </div>
                ),
              )}
            </div>
          </section>
        );
      })}

      {!info.configs.length && (
        <p className="rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-ink-400">
          هنوز سرویسی به این حساب اختصاص داده نشده است. با پشتیبانی تماس بگیرید.
        </p>
      )}

      <footer className="pt-4 text-center text-[11px] text-ink-600">
        © {new Date().getFullYear()} {info.brand} — تمامی حقوق محفوظ است
      </footer>
    </div>
  );
}
