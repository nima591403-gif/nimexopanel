import { useState } from "react";

import { CopyButton, Spinner } from "../components/ui";
import { api } from "../lib/api";
import { bytes, dateOnly } from "../lib/format";

interface Claimed {
  username: string;
  sub_id: string;
  subscription_url: string;
  page_url: string;
  data_limit: number;
  used_traffic: number;
  expire_at: string | null;
}

export default function Migrate() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Claimed | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await api.post<Claimed>("/api/migrate/claim", { username, password });
      setResult(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : "حسابی با این مشخصات پیدا نشد");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-brand-400 text-2xl font-bold text-white shadow-glow">
            ⇄
          </span>
          <h1 className="text-lg font-bold">انتقال حساب به پنل جدید</h1>
          <p className="mt-2 text-xs leading-6 text-ink-400">
            نام کاربری و گذرواژه‌ی حساب فعلی خود را وارد کنید. حجم مصرفی، روزهای باقی‌مانده و
            مشخصات حساب شما به‌طور خودکار منتقل می‌شود.
          </p>
        </div>

        {result ? (
          <div className="card space-y-4">
            <p className="rounded-lg bg-emerald-500/15 px-3 py-2 text-center text-sm text-emerald-300">
              حساب «{result.username}» با موفقیت منتقل شد
            </p>
            <div className="grid grid-cols-3 gap-3 text-center text-xs">
              <div>
                <p className="text-ink-400">مصرف</p>
                <p className="mt-1 font-bold">{bytes(result.used_traffic)}</p>
              </div>
              <div>
                <p className="text-ink-400">حجم</p>
                <p className="mt-1 font-bold">
                  {result.data_limit ? bytes(result.data_limit) : "نامحدود"}
                </p>
              </div>
              <div>
                <p className="text-ink-400">انقضا</p>
                <p className="mt-1 font-bold">{dateOnly(result.expire_at)}</p>
              </div>
            </div>
            <div>
              <p className="label">لینک اشتراک جدید</p>
              <div className="flex gap-2">
                <input
                  className="input font-mono text-[11px]"
                  dir="ltr"
                  readOnly
                  value={result.subscription_url}
                />
                <CopyButton value={result.subscription_url} />
              </div>
            </div>
            <a className="btn-primary w-full" href={result.page_url}>
              مشاهده‌ی صفحه‌ی حساب
            </a>
          </div>
        ) : (
          <form onSubmit={submit} className="card">
            <label className="label">نام کاربری در پنل قبلی</label>
            <input
              className="input mb-3"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="مثلاً user123"
              autoFocus
            />
            <label className="label">گذرواژه</label>
            <input
              className="input mb-4"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {error && (
              <p className="mb-3 rounded-lg bg-rose-500/15 px-3 py-2 text-xs text-rose-300">
                {error}
              </p>
            )}
            <button className="btn-primary w-full" disabled={busy}>
              {busy ? <Spinner /> : "انتقال حساب"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
