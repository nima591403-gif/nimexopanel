import { useEffect, useMemo, useState } from "react";

import {
  Card,
  CopyButton,
  Empty,
  Field,
  Modal,
  MultiSelect,
  Progress,
  QrButton,
  Spinner,
  StatusBadge,
  Toggle,
  useToast,
} from "../components/ui";
import { api } from "../lib/api";
import { bytes, dateOnly, daysLeft, gb, number, toBytes } from "../lib/format";
import type { Group, Inbound, Node, Page, User, UserStatus } from "../lib/types";

const STATUS_OPTIONS: { value: UserStatus | ""; label: string }[] = [
  { value: "", label: "همه وضعیت‌ها" },
  { value: "active", label: "فعال" },
  { value: "disabled", label: "غیرفعال" },
  { value: "expired", label: "منقضی" },
  { value: "limited", label: "اتمام حجم" },
  { value: "on_hold", label: "در انتظار اتصال" },
];

interface FormState {
  id?: number;
  username: string;
  password: string;
  note: string;
  group_id: number | null;
  data_limit_gb: number;
  duration_days: number;
  device_limit: number;
  status: UserStatus;
  inbound_ids: number[];
  node_ids: number[];
  telegram_id: string;
}

const EMPTY: FormState = {
  username: "",
  password: "",
  note: "",
  group_id: null,
  data_limit_gb: 0,
  duration_days: 30,
  device_limit: 0,
  status: "active",
  inbound_ids: [],
  node_ids: [],
  telegram_id: "",
};

export default function Users() {
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<UserStatus | "">("");
  const [groupId, setGroupId] = useState<number | "">("");
  const [data, setData] = useState<Page<User> | null>(null);
  const [groups, setGroups] = useState<Group[]>([]);
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<number[]>([]);
  const [form, setForm] = useState<FormState | null>(null);
  const [saving, setSaving] = useState(false);
  const [detail, setDetail] = useState<User | null>(null);

  const query = useMemo(() => {
    const params = new URLSearchParams({ page: String(page), size: "50" });
    if (search) params.set("search", search);
    if (status) params.set("status", status);
    if (groupId) params.set("group_id", String(groupId));
    return params.toString();
  }, [page, search, status, groupId]);

  const load = () => {
    setLoading(true);
    api
      .get<Page<User>>(`/api/users?${query}`)
      .then(setData)
      .catch((e) => toast(e.message, "error"))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  useEffect(() => {
    api.get<Group[]>("/api/groups").then(setGroups).catch(() => {});
    api.get<Inbound[]>("/api/inbounds").then(setInbounds).catch(() => {});
    api.get<Node[]>("/api/nodes").then(setNodes).catch(() => {});
  }, []);

  const openCreate = () => setForm({ ...EMPTY });
  const openEdit = (user: User) =>
    setForm({
      id: user.id,
      username: user.username,
      password: user.password,
      note: user.note,
      group_id: user.group_id,
      data_limit_gb: gb(user.data_limit),
      duration_days: daysLeft(user.expire_at) ?? 0,
      device_limit: user.device_limit,
      status: user.status,
      inbound_ids: user.inbound_ids,
      node_ids: user.node_ids,
      telegram_id: user.telegram_id ? String(user.telegram_id) : "",
    });

  const save = async () => {
    if (!form) return;
    setSaving(true);
    const payload: Record<string, unknown> = {
      note: form.note,
      group_id: form.group_id,
      data_limit: toBytes(form.data_limit_gb),
      device_limit: form.device_limit,
      status: form.status,
      inbound_ids: form.inbound_ids,
      node_ids: form.node_ids,
      telegram_id: form.telegram_id ? Number(form.telegram_id) : null,
      password: form.password || undefined,
    };
    if (form.duration_days > 0) payload.duration_days = form.duration_days;
    try {
      if (form.id) {
        await api.patch(`/api/users/${form.id}`, payload);
        toast("کاربر بروزرسانی شد");
      } else {
        await api.post("/api/users", { ...payload, username: form.username });
        toast("کاربر ساخته شد");
      }
      setForm(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const bulk = async (action: string, value?: number | string) => {
    if (!selected.length) return toast("کاربری انتخاب نشده", "error");
    try {
      await api.post("/api/users/bulk", { user_ids: selected, action, value });
      toast("انجام شد");
      setSelected([]);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    }
  };

  const toggleStatus = async (user: User) => {
    await api.patch(`/api/users/${user.id}`, {
      status: user.status === "active" ? "disabled" : "active",
    });
    load();
  };

  const remove = async (user: User) => {
    if (!confirm(`کاربر ${user.username} حذف شود؟`)) return;
    await api.del(`/api/users/${user.id}`);
    toast("حذف شد");
    load();
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">کاربران</h1>
          <p className="mt-1 text-xs text-ink-400">
            مدیریت حساب‌های VPN و دسترسی‌ها — {number(data?.total)} کاربر
          </p>
        </div>
        <button className="btn-primary" onClick={openCreate}>
          + افزودن کاربر
        </button>
      </div>

      <Card>
        <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <input
            className="input"
            placeholder="جستجو در نام کاربری، یادداشت، UUID…"
            value={search}
            onChange={(e) => {
              setPage(1);
              setSearch(e.target.value);
            }}
          />
          <select
            className="input"
            value={status}
            onChange={(e) => {
              setPage(1);
              setStatus(e.target.value as UserStatus | "");
            }}
          >
            {STATUS_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <select
            className="input"
            value={groupId}
            onChange={(e) => {
              setPage(1);
              setGroupId(e.target.value ? Number(e.target.value) : "");
            }}
          >
            <option value="">همه گروه‌ها</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.title || g.name}
              </option>
            ))}
          </select>
          {selected.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <button className="btn-ghost text-xs" onClick={() => bulk("enable")}>
                فعال ({selected.length})
              </button>
              <button className="btn-ghost text-xs" onClick={() => bulk("disable")}>
                غیرفعال
              </button>
              <button className="btn-ghost text-xs" onClick={() => bulk("add_days", 30)}>
                +۳۰ روز
              </button>
              <button className="btn-danger text-xs" onClick={() => bulk("delete")}>
                حذف
              </button>
            </div>
          )}
        </div>

        {loading ? (
          <div className="grid place-items-center py-16 text-ink-400">
            <Spinner className="h-6 w-6" />
          </div>
        ) : !data?.items.length ? (
          <Empty text="کاربری یافت نشد — برای ساخت اولین حساب روی «افزودن کاربر» بزنید." />
        ) : (
          <div className="-mx-5 overflow-x-auto px-5">
            <table className="w-full min-w-[860px]">
              <thead className="border-b border-white/5">
                <tr>
                  <th className="th w-8">
                    <input
                      type="checkbox"
                      checked={selected.length === data.items.length}
                      onChange={(e) =>
                        setSelected(e.target.checked ? data.items.map((u) => u.id) : [])
                      }
                    />
                  </th>
                  <th className="th">کاربر</th>
                  <th className="th">گروه</th>
                  <th className="th">وضعیت</th>
                  <th className="th">مصرف / حجم</th>
                  <th className="th">انقضا</th>
                  <th className="th"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {data.items.map((user) => {
                  const left = daysLeft(user.expire_at);
                  return (
                    <tr key={user.id} className="hover:bg-white/[0.03]">
                      <td className="td">
                        <input
                          type="checkbox"
                          checked={selected.includes(user.id)}
                          onChange={(e) =>
                            setSelected((prev) =>
                              e.target.checked
                                ? [...prev, user.id]
                                : prev.filter((i) => i !== user.id),
                            )
                          }
                        />
                      </td>
                      <td className="td">
                        <button
                          className="flex items-center gap-2 text-right"
                          onClick={() => setDetail(user)}
                        >
                          <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-500/20 text-xs text-brand-200">
                            {user.username[0]?.toUpperCase()}
                          </span>
                          <span>
                            <span className="block font-medium">{user.username}</span>
                            {user.is_online && (
                              <span className="text-[10px] text-emerald-400">آنلاین</span>
                            )}
                          </span>
                        </button>
                      </td>
                      <td className="td text-ink-300">{user.group_name || "—"}</td>
                      <td className="td">
                        <StatusBadge status={user.status} />
                      </td>
                      <td className="td w-48">
                        <div className="mb-1 text-xs tabular-nums text-ink-300">
                          {bytes(user.used_traffic)} /{" "}
                          {user.data_limit ? bytes(user.data_limit) : "نامحدود"}
                        </div>
                        <Progress
                          value={user.used_traffic}
                          total={user.data_limit || user.used_traffic || 1}
                        />
                      </td>
                      <td className="td text-xs text-ink-300">
                        {user.expire_at ? (
                          <>
                            {dateOnly(user.expire_at)}
                            <span className="block text-[10px] text-ink-500">
                              {left} روز مانده
                            </span>
                          </>
                        ) : (
                          "هرگز"
                        )}
                      </td>
                      <td className="td">
                        <div className="flex justify-end gap-1">
                          <CopyButton value={user.subscription_url} label="لینک" />
                          <button
                            className="btn-ghost px-2 py-1 text-xs"
                            onClick={() => openEdit(user)}
                          >
                            ویرایش
                          </button>
                          <button
                            className="btn-ghost px-2 py-1 text-xs"
                            onClick={() => toggleStatus(user)}
                          >
                            {user.status === "active" ? "توقف" : "فعال"}
                          </button>
                          <button
                            className="btn-danger px-2 py-1 text-xs"
                            onClick={() => remove(user)}
                          >
                            حذف
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {data && data.total > data.size && (
          <div className="mt-4 flex items-center justify-between text-xs text-ink-400">
            <span>
              صفحه {page} از {Math.ceil(data.total / data.size)}
            </span>
            <div className="flex gap-2">
              <button
                className="btn-ghost px-3 py-1"
                disabled={page === 1}
                onClick={() => setPage((p) => p - 1)}
              >
                قبلی
              </button>
              <button
                className="btn-ghost px-3 py-1"
                disabled={page >= Math.ceil(data.total / data.size)}
                onClick={() => setPage((p) => p + 1)}
              >
                بعدی
              </button>
            </div>
          </div>
        )}
      </Card>

      {/* create / edit */}
      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={form?.id ? `ویرایش ${form.username}` : "افزودن کاربر"}
        wide
        footer={
          <>
            <button className="btn-ghost" onClick={() => setForm(null)}>
              انصراف
            </button>
            <button className="btn-primary" onClick={save} disabled={saving}>
              {saving ? <Spinner /> : "ذخیره"}
            </button>
          </>
        }
      >
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="نام کاربری">
              <input
                className="input"
                value={form.username}
                disabled={!!form.id}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
              />
            </Field>
            <Field label="گذرواژه" hint="برای OpenVPN / Cisco / L2TP استفاده می‌شود">
              <input
                className="input"
                value={form.password}
                placeholder="خالی = تولید خودکار"
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </Field>
            <Field label="گروه / پلن">
              <select
                className="input"
                value={form.group_id ?? ""}
                onChange={(e) => {
                  const id = e.target.value ? Number(e.target.value) : null;
                  const g = groups.find((x) => x.id === id);
                  setForm({
                    ...form,
                    group_id: id,
                    data_limit_gb: g ? gb(g.data_limit) : form.data_limit_gb,
                    duration_days: g?.duration_days ?? form.duration_days,
                    device_limit: g?.device_limit ?? form.device_limit,
                  });
                }}
              >
                <option value="">بدون گروه</option>
                {groups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.title || g.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="وضعیت">
              <select
                className="input"
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as UserStatus })}
              >
                {STATUS_OPTIONS.filter((o) => o.value).map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="حجم (گیگابایت)" hint="۰ = نامحدود">
              <input
                type="number"
                className="input"
                value={form.data_limit_gb}
                onChange={(e) => setForm({ ...form, data_limit_gb: Number(e.target.value) })}
              />
            </Field>
            <Field label="مدت (روز)" hint="۰ = بدون انقضا">
              <input
                type="number"
                className="input"
                value={form.duration_days}
                onChange={(e) => setForm({ ...form, duration_days: Number(e.target.value) })}
              />
            </Field>
            <Field label="حداکثر دستگاه هم‌زمان" hint="۰ = نامحدود">
              <input
                type="number"
                className="input"
                value={form.device_limit}
                onChange={(e) => setForm({ ...form, device_limit: Number(e.target.value) })}
              />
            </Field>
            <Field label="آیدی تلگرام">
              <input
                className="input"
                value={form.telegram_id}
                onChange={(e) => setForm({ ...form, telegram_id: e.target.value })}
              />
            </Field>
            <Field label="یادداشت" className="sm:col-span-2">
              <input
                className="input"
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
              />
            </Field>
            <Field
              label="اینباندها"
              hint="خالی = همان‌هایی که گروه تعیین کرده"
              className="sm:col-span-2"
            >
              <MultiSelect
                options={inbounds}
                selected={form.inbound_ids}
                onChange={(ids) => setForm({ ...form, inbound_ids: ids })}
                render={(i) => `${i.remark || i.tag} · ${i.protocol}`}
              />
            </Field>
            <Field
              label="لوکیشن‌ها (نودها)"
              hint="خالی = همه نودهای مجاز گروه"
              className="sm:col-span-2"
            >
              <MultiSelect
                options={nodes}
                selected={form.node_ids}
                onChange={(ids) => setForm({ ...form, node_ids: ids })}
                render={(n) => `${n.country ? n.country + " " : ""}${n.name}`}
              />
            </Field>
          </div>
        )}
      </Modal>

      {/* detail */}
      <Modal open={!!detail} onClose={() => setDetail(null)} title={detail?.username || ""}>
        {detail && (
          <div className="space-y-3 text-sm">
            <Row label="وضعیت" value={<StatusBadge status={detail.status} />} />
            <Row label="گروه" value={detail.group_name || "—"} />
            <Row
              label="مصرف"
              value={`${bytes(detail.used_traffic)} از ${
                detail.data_limit ? bytes(detail.data_limit) : "نامحدود"
              }`}
            />
            <Row label="انقضا" value={dateOnly(detail.expire_at)} />
            <Row label="UUID" value={<code className="text-xs">{detail.uuid}</code>} />
            <Row label="گذرواژه" value={<code className="text-xs">{detail.password}</code>} />
            <div>
              <p className="label">لینک اشتراک</p>
              <div className="flex items-center gap-2">
                <input className="input font-mono text-xs" readOnly value={detail.subscription_url} />
                <CopyButton value={detail.subscription_url} />
                <QrButton
                  url={`/sub/${detail.sub_id}/qr`}
                  title={`QR اشتراک — ${detail.username}`}
                />
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                className="btn-ghost text-xs"
                onClick={async () => {
                  await api.post(`/api/users/${detail.id}/reset-traffic`);
                  toast("مصرف صفر شد");
                  setDetail(null);
                  load();
                }}
              >
                صفر کردن مصرف
              </button>
              <button
                className="btn-ghost text-xs"
                onClick={async () => {
                  if (!confirm("لینک قبلی از کار می‌افتد. ادامه؟")) return;
                  await api.post(`/api/users/${detail.id}/revoke-sub`);
                  toast("لینک جدید ساخته شد");
                  setDetail(null);
                  load();
                }}
              >
                ابطال و ساخت لینک جدید
              </button>
              <a
                className="btn-ghost text-xs"
                href={`/u/${detail.sub_id}`}
                target="_blank"
                rel="noreferrer"
              >
                صفحه‌ی کاربر
              </a>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-white/5 pb-2">
      <span className="text-xs text-ink-400">{label}</span>
      <span>{value}</span>
    </div>
  );
}
