import { useEffect, useState } from "react";

import { Card, Chip, Empty, Spinner } from "../components/ui";
import { api } from "../lib/api";
import { bytes, dateTime } from "../lib/format";
import type { Connection } from "../lib/types";

export default function Connections() {
  const [rows, setRows] = useState<Connection[]>([]);
  const [activeOnly, setActiveOnly] = useState(true);
  const [loading, setLoading] = useState(true);

  const load = () => {
    api
      .get<Connection[]>(`/api/stats/connections?active_only=${activeOnly}`)
      .then(setRows)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 10_000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeOnly]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">اتصالات</h1>
          <p className="mt-1 text-xs text-ink-400">نشست‌های زنده‌ی کاربران روی نودها</p>
        </div>
        <div className="flex gap-2">
          <button
            className={activeOnly ? "btn-primary text-xs" : "btn-ghost text-xs"}
            onClick={() => setActiveOnly(true)}
          >
            فقط آنلاین
          </button>
          <button
            className={!activeOnly ? "btn-primary text-xs" : "btn-ghost text-xs"}
            onClick={() => setActiveOnly(false)}
          >
            همه
          </button>
        </div>
      </div>

      <Card>
        {loading ? (
          <div className="grid place-items-center py-16">
            <Spinner className="h-6 w-6" />
          </div>
        ) : !rows.length ? (
          <Empty text="اتصال فعالی وجود ندارد." />
        ) : (
          <div className="-mx-5 overflow-x-auto px-5">
            <table className="w-full min-w-[720px]">
              <thead className="border-b border-white/5">
                <tr>
                  <th className="th">کاربر</th>
                  <th className="th">نود</th>
                  <th className="th">پروتکل</th>
                  <th className="th">IP</th>
                  <th className="th">آپلود</th>
                  <th className="th">دانلود</th>
                  <th className="th">شروع</th>
                  <th className="th">آخرین فعالیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {rows.map((c) => (
                  <tr key={c.id} className="hover:bg-white/[0.03]">
                    <td className="td font-medium">{c.username}</td>
                    <td className="td">{c.node_name || "—"}</td>
                    <td className="td">
                      <Chip tone={c.is_active ? "green" : "default"}>{c.protocol || "—"}</Chip>
                    </td>
                    <td className="td font-mono text-xs" dir="ltr">
                      {c.ip || "—"}
                    </td>
                    <td className="td tabular-nums">{bytes(c.up)}</td>
                    <td className="td tabular-nums">{bytes(c.down)}</td>
                    <td className="td text-xs text-ink-400">{dateTime(c.started_at)}</td>
                    <td className="td text-xs text-ink-400">{dateTime(c.last_seen)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
