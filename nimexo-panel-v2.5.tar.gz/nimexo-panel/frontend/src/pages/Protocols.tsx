import { useEffect, useState } from "react";

import { Card, Chip, Empty, Field, Modal, MultiSelect, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import { number } from "../lib/format";
import type { Inbound, Node } from "../lib/types";

const PROTOCOLS = [
  { value: "vless", label: "VLESS", core: "xray" },
  { value: "vmess", label: "VMess", core: "xray" },
  { value: "trojan", label: "Trojan", core: "xray" },
  { value: "shadowsocks", label: "Shadowsocks", core: "xray" },
  { value: "wireguard", label: "WireGuard", core: "wireguard" },
  { value: "openvpn", label: "OpenVPN", core: "openvpn" },
  { value: "ocserv", label: "OpenConnect / Cisco AnyConnect", core: "ocserv" },
  { value: "l2tp", label: "L2TP/IPsec", core: "l2tp" },
  { value: "pptp", label: "PPTP", core: "pptp" },
];

const XRAY_PROTOCOLS = ["vless", "vmess", "trojan", "shadowsocks"];
const NETWORKS = ["tcp", "ws", "grpc", "kcp", "httpupgrade", "xhttp"];
const SECURITIES = ["none", "tls", "reality"];
const TABS = [
  { key: "all", label: "نمای کلی" },
  { key: "xray", label: "V2ray / Xray" },
  { key: "openvpn", label: "OpenVPN" },
  { key: "wireguard", label: "WireGuard" },
  { key: "ocserv", label: "Cisco AnyConnect" },
  { key: "l2tp", label: "L2TP/IPsec" },
  { key: "pptp", label: "PPTP" },
];

const SETTINGS_HINTS: Record<string, string> = {
  wireguard: 'مثال: {"subnet":"10.66.0.0/24","mtu":1280,"dns":"1.1.1.1, 8.8.8.8"}',
  openvpn: 'مثال: {"proto":"tcp","subnet":"10.20.0.0","mtu":1280,"cipher":"AES-128-GCM"}',
  ocserv: 'مثال: {"subnet":"10.30.0.0","mtu":1280,"udp":true,"max_same":2}',
  l2tp: 'مثال: {"psk":"کلید-مشترک","local_ip":"10.40.0.1","range":"10.40.0.10-10.40.0.250","mtu":1280}',
  pptp: 'مثال: {"local_ip":"10.50.0.1","range":"10.50.0.10-10.50.0.250","mtu":1280}',
  shadowsocks: 'مثال: {"method":"2022-blake3-aes-256-gcm"}',
};

interface FormState {
  id?: number;
  tag: string;
  remark: string;
  protocol: string;
  core: string;
  port: number;
  network: string;
  security: string;
  sni: string;
  host: string;
  path: string;
  service_name: string;
  flow: string;
  fingerprint: string;
  reality_public_key: string;
  reality_private_key: string;
  reality_short_ids: string;
  reality_dest: string;
  cert_path: string;
  key_path: string;
  alpn: string;
  multi_mode: boolean;
  settings: string;
  is_enabled: boolean;
  is_default: boolean;
  sniffing: boolean;
  node_ids: number[];
}

const EMPTY: FormState = {
  tag: "",
  remark: "",
  protocol: "vless",
  core: "xray",
  port: 2053,
  network: "tcp",
  security: "reality",
  sni: "dl.google.com",
  host: "",
  path: "",
  service_name: "",
  flow: "xtls-rprx-vision",
  fingerprint: "chrome",
  reality_public_key: "",
  reality_private_key: "",
  reality_short_ids: "",
  reality_dest: "",
  cert_path: "",
  key_path: "",
  alpn: "",
  multi_mode: false,
  settings: "{}",
  is_enabled: true,
  is_default: false,
  sniffing: false,
  node_ids: [],
};

export default function Protocols() {
  const toast = useToast();
  const [tab, setTab] = useState("all");
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState | null>(null);
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    api
      .get<Inbound[]>("/api/inbounds")
      .then(setInbounds)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    api.get<Node[]>("/api/nodes").then(setNodes).catch(() => {});
  }, []);

  const genReality = async () => {
    if (!form) return;
    const keys = await api.post<{ private_key: string; public_key: string; short_ids: string[] }>(
      "/api/inbounds/reality-keys",
    );
    setForm({
      ...form,
      reality_private_key: keys.private_key,
      reality_public_key: keys.public_key,
      reality_short_ids: keys.short_ids.join(","),
    });
    toast("کلیدهای Reality ساخته شد");
  };

  const save = async () => {
    if (!form) return;
    setSaving(true);
    let settings: Record<string, unknown> = {};
    try {
      settings = JSON.parse(form.settings || "{}");
    } catch {
      setSaving(false);
      return toast("تنظیمات اضافه JSON معتبر نیست", "error");
    }
    if (form.network === "grpc") settings.multi_mode = form.multi_mode;
    const payload = {
      tag: form.tag,
      remark: form.remark,
      protocol: form.protocol,
      core: PROTOCOLS.find((p) => p.value === form.protocol)?.core || "xray",
      port: form.port,
      network: form.network,
      security: form.security,
      sni: form.sni,
      host: form.host,
      path: form.path,
      service_name: form.service_name,
      flow: form.flow,
      fingerprint: form.fingerprint,
      reality_public_key: form.reality_public_key,
      reality_private_key: form.reality_private_key,
      reality_short_ids: form.reality_short_ids
        ? form.reality_short_ids.split(",").map((s) => s.trim()).filter(Boolean)
        : [],
      reality_dest: form.reality_dest,
      reality_server_names: form.sni ? [form.sni] : [],
      cert_path: form.cert_path,
      key_path: form.key_path,
      alpn: form.alpn,
      settings,
      is_enabled: form.is_enabled,
      is_default: form.is_default,
      sniffing: form.sniffing,
      node_ids: form.node_ids,
    };
    try {
      if (form.id) await api.patch(`/api/inbounds/${form.id}`, payload);
      else await api.post("/api/inbounds", payload);
      toast("ذخیره و روی نودها اعمال شد");
      setForm(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const shown = inbounds.filter((i) => tab === "all" || i.core === tab);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">پروتکل‌ها</h1>
          <p className="mt-1 text-xs text-ink-400">
            همه پروتکل‌های VPN در یک‌جا — وضعیت، تنظیمات شبکه، کاربران و نودها
          </p>
        </div>
        <button className="btn-primary" onClick={() => setForm({ ...EMPTY })}>
          + افزودن اینباند
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={
              tab === t.key
                ? "rounded-full bg-gradient-to-l from-brand-600 to-brand-400 px-4 py-2 text-sm text-white"
                : "rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-ink-300"
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid place-items-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : !shown.length ? (
        <Empty text="اینباندی در این دسته وجود ندارد." />
      ) : (
        <Card>
          <div className="-mx-5 overflow-x-auto px-5">
            <table className="w-full min-w-[760px]">
              <thead className="border-b border-white/5">
                <tr>
                  <th className="th">نام</th>
                  <th className="th">پروتکل</th>
                  <th className="th">ترنسپورت</th>
                  <th className="th">امنیت</th>
                  <th className="th">پورت</th>
                  <th className="th">نودها</th>
                  <th className="th">کاربران</th>
                  <th className="th"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {shown.map((i) => (
                  <tr key={i.id} className="hover:bg-white/[0.03]">
                    <td className="td">
                      <span className="font-medium">{i.remark || i.tag}</span>
                      {i.is_default && <Chip tone="brand">پیش‌فرض همه</Chip>}
                      <span className="block text-[10px] text-ink-500">{i.tag}</span>
                    </td>
                    <td className="td uppercase">{i.protocol}</td>
                    <td className="td">{i.network}</td>
                    <td className="td">{i.security}</td>
                    <td className="td tabular-nums">{i.port}</td>
                    <td className="td max-w-xs whitespace-normal">
                      <div className="flex flex-wrap gap-1">
                        {i.node_inbounds.map((ni) => {
                          const node = nodes.find((n) => n.id === ni.node_id);
                          return (
                            <span
                              key={ni.node_id}
                              title={ni.sync_error || "همگام شد"}
                              className={
                                ni.sync_error
                                  ? "badge bg-rose-500/15 text-rose-300"
                                  : "badge bg-emerald-500/15 text-emerald-300"
                              }
                            >
                              {ni.sync_error ? "⚠ " : ""}
                              {node?.name || ni.node_id}
                            </span>
                          );
                        })}
                        {!i.node_inbounds.length && (
                          <span className="text-[11px] text-ink-500">اعمال نشده</span>
                        )}
                      </div>
                      {i.node_inbounds
                        .filter((ni) => ni.sync_error)
                        .map((ni) => (
                          <p
                            key={`err-${ni.node_id}`}
                            className="mt-1 text-[10px] leading-4 text-rose-300"
                          >
                            {ni.sync_error}
                          </p>
                        ))}
                    </td>
                    <td className="td tabular-nums">{number(i.users_count)}</td>
                    <td className="td">
                      <div className="flex justify-end gap-1">
                        <button
                          className="btn-ghost px-2 py-1 text-xs"
                          onClick={() =>
                            setForm({
                              id: i.id,
                              tag: i.tag,
                              remark: i.remark,
                              protocol: i.protocol,
                              core: i.core,
                              port: i.port,
                              network: i.network,
                              security: i.security,
                              sni: i.sni,
                              host: i.host,
                              path: i.path,
                              service_name: i.service_name,
                              flow: i.flow,
                              fingerprint: i.fingerprint,
                              reality_public_key: i.reality_public_key,
                              reality_private_key: i.reality_private_key,
                              reality_short_ids: (i.reality_short_ids || []).join(","),
                              reality_dest: i.reality_dest,
                              cert_path: i.cert_path || "",
                              key_path: i.key_path || "",
                              alpn: i.alpn || "",
                              multi_mode: Boolean(
                                (i.settings as Record<string, unknown>)?.multi_mode,
                              ),
                              settings: JSON.stringify(i.settings || {}, null, 2),
                              is_enabled: i.is_enabled,
                              is_default: i.is_default,
                              sniffing: i.sniffing,
                              node_ids: i.node_inbounds.map((n) => n.node_id),
                            })
                          }
                        >
                          ویرایش
                        </button>
                        <button
                          className="btn-danger px-2 py-1 text-xs"
                          onClick={async () => {
                            if (!confirm(`اینباند ${i.tag} حذف شود؟`)) return;
                            await api.del(`/api/inbounds/${i.id}`);
                            toast("حذف شد");
                            load();
                          }}
                        >
                          حذف
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={form?.id ? `ویرایش ${form.tag}` : "اینباند جدید"}
        wide
        footer={
          <>
            <button className="btn-ghost" onClick={() => setForm(null)}>
              انصراف
            </button>
            <button className="btn-primary" onClick={save} disabled={saving}>
              {saving ? <Spinner /> : "ذخیره و اعمال"}
            </button>
          </>
        }
      >
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="تگ (یکتا)">
              <input
                className="input font-mono"
                value={form.tag}
                disabled={!!form.id}
                onChange={(e) => setForm({ ...form, tag: e.target.value })}
              />
            </Field>
            <Field label="نام نمایشی">
              <input
                className="input"
                value={form.remark}
                onChange={(e) => setForm({ ...form, remark: e.target.value })}
              />
            </Field>
            <Field label="پروتکل">
              <select
                className="input"
                value={form.protocol}
                onChange={(e) => setForm({ ...form, protocol: e.target.value })}
              >
                {PROTOCOLS.map((p) => (
                  <option key={p.value} value={p.value}>
                    {p.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="پورت">
              <input
                type="number"
                className="input"
                value={form.port}
                onChange={(e) => setForm({ ...form, port: Number(e.target.value) })}
              />
            </Field>

            {form.protocol === "pptp" && (
              <p className="sm:col-span-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] text-amber-300">
                PPTP به پروتکل GRE نیاز دارد که در مسیر ایران معمولاً فیلتر است؛
                فقط اگر مطمئنی مسیرت GRE را عبور می‌دهد از آن استفاده کن.
              </p>
            )}

            {XRAY_PROTOCOLS.includes(form.protocol) && (
              <>
                <Field label="ترنسپورت">
                  <select
                    className="input"
                    value={form.network}
                    onChange={(e) => setForm({ ...form, network: e.target.value })}
                  >
                    {NETWORKS.map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="امنیت">
                  <select
                    className="input"
                    value={form.security}
                    onChange={(e) => setForm({ ...form, security: e.target.value })}
                  >
                    {SECURITIES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="SNI / سرورنیم">
                  <input
                    className="input"
                    value={form.sni}
                    onChange={(e) => setForm({ ...form, sni: e.target.value })}
                  />
                </Field>
                <Field label="Fingerprint">
                  <input
                    className="input"
                    value={form.fingerprint}
                    onChange={(e) => setForm({ ...form, fingerprint: e.target.value })}
                  />
                </Field>
                {["ws", "httpupgrade", "xhttp"].includes(form.network) && (
                  <>
                    <Field label="Path">
                      <input
                        className="input"
                        value={form.path}
                        onChange={(e) => setForm({ ...form, path: e.target.value })}
                      />
                    </Field>
                    <Field label="Host">
                      <input
                        className="input"
                        value={form.host}
                        onChange={(e) => setForm({ ...form, host: e.target.value })}
                      />
                    </Field>
                  </>
                )}
                {form.network === "grpc" && (
                  <>
                    <Field label="Service Name" hint="در کلاینت همین مقدار وارد می‌شود">
                      <div className="flex gap-2">
                        <input
                          className="input font-mono"
                          value={form.service_name}
                          onChange={(e) =>
                            setForm({ ...form, service_name: e.target.value })
                          }
                        />
                        <button
                          type="button"
                          className="btn-ghost shrink-0 text-xs"
                          onClick={() =>
                            setForm({
                              ...form,
                              service_name: Math.random().toString(36).slice(2, 10),
                            })
                          }
                        >
                          تولید
                        </button>
                      </div>
                    </Field>
                    <div className="flex items-end">
                      <Toggle
                        checked={form.multi_mode}
                        onChange={(v) => setForm({ ...form, multi_mode: v })}
                        label="Multi Mode"
                      />
                    </div>
                    {form.security === "none" && (
                      <p className="sm:col-span-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] leading-5 text-amber-300">
                        gRPC بدون TLS تقریباً در هیچ کلاینتی وصل نمی‌شود. امنیت را روی
                        <span className="font-mono"> tls </span>
                        بگذارید و از صفحه‌ی «گواهی‌ها» برای دامنه‌تان گواهی بگیرید،
                        یا از <span className="font-mono">reality</span> استفاده کنید.
                      </p>
                    )}
                  </>
                )}
                {form.security === "tls" && (
                  <>
                    <Field
                      label="مسیر گواهی (fullchain.pem)"
                      hint="از صفحه‌ی «گواهی‌ها» بگیرید تا خودکار پر شود"
                    >
                      <input
                        className="input font-mono text-[11px]"
                        dir="ltr"
                        value={form.cert_path}
                        onChange={(e) => setForm({ ...form, cert_path: e.target.value })}
                      />
                    </Field>
                    <Field label="مسیر کلید (privkey.pem)">
                      <input
                        className="input font-mono text-[11px]"
                        dir="ltr"
                        value={form.key_path}
                        onChange={(e) => setForm({ ...form, key_path: e.target.value })}
                      />
                    </Field>
                    <Field label="ALPN" hint="مثلاً h2,http/1.1 — برای gRPC معمولاً h2">
                      <input
                        className="input"
                        dir="ltr"
                        value={form.alpn}
                        onChange={(e) => setForm({ ...form, alpn: e.target.value })}
                      />
                    </Field>
                  </>
                )}

                {form.security === "reality" && (
                  <>
                    <Field label="Reality dest" hint="مثلاً dl.google.com:443">
                      <input
                        className="input"
                        value={form.reality_dest}
                        onChange={(e) => setForm({ ...form, reality_dest: e.target.value })}
                      />
                    </Field>
                    <Field label="Short IDs" hint="با کاما جدا کنید">
                      <input
                        className="input font-mono"
                        value={form.reality_short_ids}
                        onChange={(e) => setForm({ ...form, reality_short_ids: e.target.value })}
                      />
                    </Field>
                    <Field label="کلید عمومی">
                      <input
                        className="input font-mono text-[11px]"
                        value={form.reality_public_key}
                        onChange={(e) => setForm({ ...form, reality_public_key: e.target.value })}
                      />
                    </Field>
                    <Field label="کلید خصوصی">
                      <div className="flex gap-2">
                        <input
                          className="input font-mono text-[11px]"
                          value={form.reality_private_key}
                          onChange={(e) =>
                            setForm({ ...form, reality_private_key: e.target.value })
                          }
                        />
                        <button className="btn-ghost shrink-0 text-xs" onClick={genReality}>
                          تولید
                        </button>
                      </div>
                    </Field>
                  </>
                )}
                {form.protocol === "vless" && (
                  <Field label="Flow" hint="برای Reality معمولاً xtls-rprx-vision">
                    <input
                      className="input"
                      value={form.flow}
                      onChange={(e) => setForm({ ...form, flow: e.target.value })}
                    />
                  </Field>
                )}
              </>
            )}

            <Field
              label="تنظیمات اضافه (JSON)"
              hint={SETTINGS_HINTS[form.protocol] || "برای این پروتکل تنظیم اضافه‌ای لازم نیست"}
              className="sm:col-span-2"
            >
              <textarea
                className="input h-24 font-mono text-[11px]"
                dir="ltr"
                value={form.settings}
                onChange={(e) => setForm({ ...form, settings: e.target.value })}
              />
            </Field>

            <Field label="نودهایی که این اینباند روی آن‌ها بالا بیاید" className="sm:col-span-2">
              <MultiSelect
                options={nodes}
                selected={form.node_ids}
                onChange={(ids) => setForm({ ...form, node_ids: ids })}
                render={(n) => `${n.country ? n.country + " " : ""}${n.name}`}
                empty="ابتدا یک نود اضافه کنید"
              />
            </Field>

            <div className="flex flex-wrap items-center gap-5 sm:col-span-2">
              <Toggle
                checked={form.is_enabled}
                onChange={(v) => setForm({ ...form, is_enabled: v })}
                label="فعال"
              />
              <Toggle
                checked={form.is_default}
                onChange={(v) => setForm({ ...form, is_default: v })}
                label="به همه کاربران اضافه شود"
              />
              <Toggle
                checked={form.sniffing}
                onChange={(v) => setForm({ ...form, sniffing: v })}
                label="Sniffing"
              />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
