import { useEffect, useState } from "react";

import { Card, Chip, Empty, Field, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import type { Inbound, Node } from "../lib/types";

interface NodeCerts {
  node_id: number;
  node: string;
  certbot?: boolean;
  error: string;
  certs: { domain: string; cert: string; key: string; expires: string }[];
}

export default function Certificates() {
  const toast = useToast();
  const [rows, setRows] = useState<NodeCerts[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const [nodeId, setNodeId] = useState<number | "">("");
  const [domain, setDomain] = useState("");
  const [email, setEmail] = useState("");
  const [method, setMethod] = useState<"http" | "cloudflare">("cloudflare");
  const [cfToken, setCfToken] = useState("");
  const [staging, setStaging] = useState(false);
  const [applyTo, setApplyTo] = useState<number | "">("");
  const [result, setResult] = useState<string>("");

  const load = () => {
    setLoading(true);
    api
      .get<NodeCerts[]>("/api/certificates")
      .then(setRows)
      .catch((e) => toast(e.message, "error"))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    api.get<Node[]>("/api/nodes").then((n) => {
      setNodes(n);
      if (n.length) setNodeId(n[0].id);
    });
    api.get<Inbound[]>("/api/inbounds").then(setInbounds).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const issue = async () => {
    if (!nodeId || !domain.trim()) return toast("نود و دامنه لازم است", "error");
    setBusy(true);
    setResult("");
    try {
      const res = await api.post<{ domain: string; cert: string; expires: string; applied_to?: string }>(
        "/api/certificates/issue",
        {
          node_id: nodeId,
          domain: domain.trim(),
          email,
          method,
          cf_token: cfToken,
          staging,
          apply_to_inbound_id: applyTo || null,
        },
      );
      setResult(
        `گواهی ${res.domain} صادر شد — انقضا: ${res.expires}` +
          (res.applied_to ? ` و روی اینباند ${res.applied_to} اعمال شد` : ""),
      );
      toast("گواهی صادر شد");
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
      setResult(e instanceof Error ? e.message : "");
    } finally {
      setBusy(false);
    }
  };

  const tlsInbounds = inbounds.filter((i) => i.core === "xray" && i.security === "tls");

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">گواهی‌ها</h1>
        <p className="mt-1 text-xs leading-6 text-ink-400">
          گرفتن گواهی رایگان Let's Encrypt برای دامنه‌تان روی هر نود، و اعمال مستقیم آن
          روی اینباندهای TLS (مثل gRPC و WebSocket).
        </p>
      </div>

      <Card title="صدور گواهی جدید">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="نود">
            <select
              className="input"
              value={nodeId}
              onChange={(e) => setNodeId(e.target.value ? Number(e.target.value) : "")}
            >
              {nodes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.country ? `${n.country} ` : ""}
                  {n.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="دامنه" hint="مثلاً sub.example.com — باید به آی‌پی همین نود اشاره کند">
            <input
              className="input font-mono"
              dir="ltr"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
            />
          </Field>
          <Field label="روش تأیید">
            <select
              className="input"
              value={method}
              onChange={(e) => setMethod(e.target.value as "http" | "cloudflare")}
            >
              <option value="cloudflare">Cloudflare DNS (بدون نیاز به پورت ۸۰)</option>
              <option value="http">HTTP روی پورت ۸۰</option>
            </select>
          </Field>
          <Field label="ایمیل" hint="برای هشدار انقضا — اختیاری">
            <input
              className="input"
              dir="ltr"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Field>
          {method === "cloudflare" && (
            <Field
              label="توکن API کلادفلر"
              hint="توکن با دسترسی Zone:DNS:Edit روی همان دامنه"
              className="sm:col-span-2"
            >
              <input
                className="input font-mono text-[11px]"
                dir="ltr"
                type="password"
                value={cfToken}
                onChange={(e) => setCfToken(e.target.value)}
              />
            </Field>
          )}
          {method === "http" && (
            <p className="sm:col-span-2 rounded-lg bg-amber-500/10 px-3 py-2 text-[11px] leading-5 text-amber-300">
              این روش پورت ۸۰ نود را برای چند ثانیه لازم دارد و باید از بیرون قابل
              دسترس باشد. اگر ارائه‌دهنده‌ات پورت ۸۰ را بسته، روش Cloudflare را انتخاب کن.
            </p>
          )}
          <Field label="اعمال روی اینباند" hint="مسیر گواهی خودکار در اینباند ذخیره می‌شود">
            <select
              className="input"
              value={applyTo}
              onChange={(e) => setApplyTo(e.target.value ? Number(e.target.value) : "")}
            >
              <option value="">— هیچ‌کدام —</option>
              {tlsInbounds.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.remark || i.tag} · {i.protocol}/{i.network}
                </option>
              ))}
            </select>
          </Field>
          <div className="flex items-end">
            <Toggle checked={staging} onChange={setStaging} label="حالت آزمایشی (staging)" />
          </div>
        </div>

        <div className="mt-4 flex items-center gap-3">
          <button className="btn-primary" onClick={issue} disabled={busy}>
            {busy ? <Spinner /> : "صدور گواهی"}
          </button>
          {busy && <span className="text-xs text-ink-400">ممکن است تا یک دقیقه طول بکشد…</span>}
        </div>
        {result && (
          <p className="mt-3 rounded-lg bg-white/5 px-3 py-2 text-[11px] leading-5 text-ink-300">
            {result}
          </p>
        )}
      </Card>

      {loading ? (
        <div className="grid place-items-center py-12">
          <Spinner className="h-6 w-6" />
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {rows.map((row) => (
            <Card key={row.node_id} title={row.node}>
              {row.error ? (
                <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-[11px] text-rose-300">
                  {row.error}
                </p>
              ) : !row.certs.length ? (
                <Empty text="گواهی‌ای روی این نود نیست." />
              ) : (
                <div className="space-y-2">
                  {row.certs.map((c) => (
                    <div
                      key={c.domain}
                      className="rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-sm" dir="ltr">
                          {c.domain}
                        </span>
                        <Chip tone="green">معتبر</Chip>
                      </div>
                      <p className="mt-1 text-[11px] text-ink-500" dir="ltr">
                        {c.cert}
                      </p>
                      <p className="text-[11px] text-ink-500">انقضا: {c.expires}</p>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
