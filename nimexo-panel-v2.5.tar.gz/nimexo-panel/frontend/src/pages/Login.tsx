import { useState } from "react";
import { useNavigate } from "react-router-dom";

import { api } from "../lib/api";
import { Spinner } from "../components/ui";

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await api.login(username, password);
      navigate("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "ورود ناموفق بود");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center p-4">
      <form onSubmit={submit} className="card w-full max-w-sm">
        <div className="mb-6 text-center">
          <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-600 to-brand-400 text-2xl font-bold text-white shadow-glow">
            N
          </span>
          <h1 className="text-lg font-bold">ورود به NimexoPanel</h1>
          <p className="mt-1 text-xs text-ink-400">پنل مدیریت حرفه‌ای سرورهای VPN</p>
        </div>

        <label className="label">نام کاربری</label>
        <input
          className="input mb-3"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          autoFocus
          autoComplete="username"
        />

        <label className="label">گذرواژه</label>
        <input
          className="input mb-4"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
        />

        {error && (
          <p className="mb-3 rounded-lg bg-rose-500/15 px-3 py-2 text-xs text-rose-300">{error}</p>
        )}

        <button className="btn-primary w-full" disabled={busy}>
          {busy ? <Spinner /> : "ورود"}
        </button>
      </form>
    </div>
  );
}
