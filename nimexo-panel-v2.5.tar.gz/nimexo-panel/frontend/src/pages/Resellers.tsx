import { useEffect, useState } from "react";

import {
  Card,
  Chip,
  Empty,
  Field,
  Modal,
  MultiSelect,
  Progress,
  Spinner,
  Toggle,
  useToast,
} from "../components/ui";
import { api } from "../lib/api";
import { bytes, dateOnly, dateTime, gb, number, toBytes, toman } from "../lib/format";
import type { Group, Inbound, Node, Reseller, ResellerTransaction } from "../lib/types";

interface FormState {
  id?: number;
  username: string;
  password: string;
  note: string;
  telegram_id: string;
  traffic_gb: number;
  user_quota: number;
  price: number;
  expire_at: string;
  suspend_on_exhausted: boolean;
  is_active: boolean;
  allowed_group_ids: number[];
  allowed_inbound_ids: number[];
  allowed_node_ids: number[];
}

const EMPTY: FormState = {
  username: "",
  password: "",
  note: "",
  telegram_id: "",
  traffic_gb: 100,
  user_quota: 0,
  price: 0,
  expire_at: "",
  suspend_on_exhausted: true,
  is_active: true,
  allowed_group_ids: [],
  allowed_inbound_ids: [],
  allowed_node_ids: [],
};

export default function Resellers() {
  const toast = useToast();
  const [rows, setRows] = useState<Reseller[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState | null>(null);
  const [saving, setSaving] = useState(false);
  const [credit, setCredit] = useState<{ reseller: Reseller; gb: number; price: number; note: string } | null>(null);
  const [ledger, setLedger] = useState<{ reseller: Reseller; items: ResellerTransaction[] } | null>(null);

  const load = () => {
    setLoading(true);
    api
      .get<Reseller[]>("/api/resellers")
      .then(setRows)
      .catch((e) => toast(e.message, "error"))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    api.get<Group[]>("/api/groups").then(setGroups).catch(() => {});
    api.get<Inbound[]>("/api/inbounds").then(setInbounds).catch(() => {});
    api.get<Node[]>("/api/nodes").then(setNodes).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async () => {
    if (!form) return;
    setSaving(true);
    const common = {
      note: form.note,
      telegram_id: form.telegram_id ? Number(form.telegram_id) : null,
      user_quota: form.user_quota,
      expire_at: form.expire_at ? new Date(form.expire_at).toISOString() : null,
      suspend_on_exhausted: form.suspend_on_exhausted,
      allowed_group_ids: form.allowed_group_ids,
      allowed_inbound_ids: form.allowed_inbound_ids,
      allowed_node_ids: form.allowed_node_ids,
    };
    try {
      if (form.id) {
        await api.patch(`/api/resellers/${form.id}`, {
          ...common,
          is_active: form.is_active,
          ...(form.password ? { password: form.password } : {}),
        });
      } else {
        await api.post("/api/resellers", {
          ...common,
          username: form.username,
          password: form.password,
          traffic_quota: toBytes(form.traffic_gb),
          price: form.price,
        });
      }
      toast("ذخیره شد");
      setForm(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const submitCredit = async () => {
    if (!credit) return;
    setSaving(true);
    try {
      await api.post(`/api/resellers/${credit.reseller.id}/credit`, {
        amount: toBytes(credit.gb),
        price: credit.price,
        note: credit.note,
      });
      toast(`${credit.gb} گیگ به ${credit.reseller.username} اضافه شد`);
      setCredit(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const openLedger = async (reseller: Reseller) => {
    const items = await api.get<ResellerTransaction[]>(
      `/api/resellers/${reseller.id}/transactions`,
    );
    setLedger({ reseller, items });
  };

  const remove = async (reseller: Reseller) => {
    if (!confirm(`نماینده ${reseller.username} حذف شود؟`)) return;
    try {
      await api.del(`/api/resellers/${reseller.id}`);
      toast("حذف شد");
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">نمایندگان</h1>
          <p className="mt-1 text-xs leading-6 text-ink-400">
            به هر نماینده حجم می‌فروشید؛ او با همان حجم برای خودش کاربر می‌سازد.
            وقتی حجمش تمام شود کاربرانش خودکار قطع می‌شوند و با شارژ دوباره برمی‌گردند.
          </p>
        </div>
        <button className="btn-primary" onClick={() => setForm({ ...EMPTY })}>
          + نماینده جدید
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-16">
          <Spinner className="h-6 w-6" />
        </div>
      ) : !rows.length ? (
        <Empty text="هنوز نماینده‌ای تعریف نشده است." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {rows.map((r) => (
            <Card key={r.id}>
              <div className="mb-3 flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-semibold">{r.username}</h3>
                  <p className="text-[11px] text-ink-500">
                    {number(r.users_active)} فعال از {number(r.users_total)} کاربر
                  </p>
                </div>
                <div className="flex gap-1">
                  {r.exhausted && <Chip>حجم تمام شد</Chip>}
                  <Chip tone={r.is_active ? "green" : "default"}>
                    {r.is_active ? "فعال" : "غیرفعال"}
                  </Chip>
                </div>
              </div>

              <div className="mb-2 flex justify-between text-xs tabular-nums text-ink-300">
                <span>{bytes(r.traffic_used)}</span>
                <span>{r.traffic_quota ? bytes(r.traffic_quota) : "نامحدود"}</span>
              </div>
              <Progress value={r.traffic_used} total={r.traffic_quota || r.traffic_used || 1} />
              <p className="mt-2 text-xs text-ink-400">
                باقی‌مانده:{" "}
                <span className="tabular-nums">
                  {r.traffic_remaining === null ? "نامحدود" : bytes(r.traffic_remaining)}
                </span>
              </p>

              <dl className="mt-3 space-y-1 text-[11px] text-ink-400">
                <div className="flex justify-between">
                  <dt>سقف کاربر</dt>
                  <dd>{r.user_quota || "نامحدود"}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>انقضای نمایندگی</dt>
                  <dd>{dateOnly(r.expire_at)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>آخرین ورود</dt>
                  <dd>{r.last_login_at ? dateTime(r.last_login_at) : "—"}</dd>
                </div>
              </dl>

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  className="btn-primary flex-1 text-xs"
                  onClick={() => setCredit({ reseller: r, gb: 50, price: 0, note: "" })}
                >
                  شارژ حجم
                </button>
                <button className="btn-ghost text-xs" onClick={() => openLedger(r)}>
                  تراکنش‌ها
                </button>
                <button
                  className="btn-ghost text-xs"
                  onClick={() =>
                    setForm({
                      id: r.id,
                      username: r.username,
                      password: "",
                      note: r.note,
                      telegram_id: r.telegram_id ? String(r.telegram_id) : "",
                      traffic_gb: gb(r.traffic_quota),
                      user_quota: r.user_quota,
                      price: 0,
                      expire_at: r.expire_at ? r.expire_at.slice(0, 10) : "",
                      suspend_on_exhausted: r.suspend_on_exhausted,
                      is_active: r.is_active,
                      allowed_group_ids: r.allowed_group_ids,
                      allowed_inbound_ids: r.allowed_inbound_ids,
                      allowed_node_ids: r.allowed_node_ids,
                    })
                  }
                >
                  ویرایش
                </button>
                <button className="btn-danger text-xs" onClick={() => remove(r)}>
                  حذف
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* create / edit */}
      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={form?.id ? `ویرایش ${form.username}` : "نماینده جدید"}
        wide
        footer={
          <>
            <button className="btn-ghost" onClick={() => setForm(null)}>
              انصراف
            </button>
            <button className="btn-primary" onClick={save} disabled={saving}>
              {saving ? <Spinner /> : "ذخیره"}
            </button>
          </>
        }
      >
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="نام کاربری">
              <input
                className="input"
                value={form.username}
                disabled={!!form.id}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
              />
            </Field>
            <Field label="گذرواژه" hint={form.id ? "خالی بگذارید تا تغییر نکند" : ""}>
              <input
                className="input"
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </Field>
            {!form.id && (
              <>
                <Field label="حجم اولیه (گیگابایت)">
                  <input
                    type="number"
                    className="input"
                    value={form.traffic_gb}
                    onChange={(e) => setForm({ ...form, traffic_gb: Number(e.target.value) })}
                  />
                </Field>
                <Field label="مبلغ پرداختی (تومان)">
                  <input
                    type="number"
                    className="input"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                  />
                </Field>
              </>
            )}
            <Field label="سقف تعداد کاربر" hint="۰ = نامحدود">
              <input
                type="number"
                className="input"
                value={form.user_quota}
                onChange={(e) => setForm({ ...form, user_quota: Number(e.target.value) })}
              />
            </Field>
            <Field label="انقضای نمایندگی">
              <input
                type="date"
                className="input"
                value={form.expire_at}
                onChange={(e) => setForm({ ...form, expire_at: e.target.value })}
              />
            </Field>
            <Field label="آیدی تلگرام">
              <input
                className="input"
                value={form.telegram_id}
                onChange={(e) => setForm({ ...form, telegram_id: e.target.value })}
              />
            </Field>
            <Field label="یادداشت">
              <input
                className="input"
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
              />
            </Field>
            <div className="flex flex-wrap items-end gap-5 sm:col-span-2">
              <Toggle
                checked={form.suspend_on_exhausted}
                onChange={(v) => setForm({ ...form, suspend_on_exhausted: v })}
                label="با اتمام حجم، کاربرانش قطع شوند"
              />
              {form.id && (
                <Toggle
                  checked={form.is_active}
                  onChange={(v) => setForm({ ...form, is_active: v })}
                  label="فعال"
                />
              )}
            </div>
            <Field
              label="گروه‌های مجاز"
              hint="خالی = همه گروه‌ها"
              className="sm:col-span-2"
            >
              <MultiSelect
                options={groups}
                selected={form.allowed_group_ids}
                onChange={(ids) => setForm({ ...form, allowed_group_ids: ids })}
                render={(g) => g.title || g.name}
              />
            </Field>
            <Field label="اینباندهای مجاز" hint="خالی = همه" className="sm:col-span-2">
              <MultiSelect
                options={inbounds}
                selected={form.allowed_inbound_ids}
                onChange={(ids) => setForm({ ...form, allowed_inbound_ids: ids })}
                render={(i) => `${i.remark || i.tag} · ${i.protocol}`}
              />
            </Field>
            <Field label="نودهای مجاز" hint="خالی = همه" className="sm:col-span-2">
              <MultiSelect
                options={nodes}
                selected={form.allowed_node_ids}
                onChange={(ids) => setForm({ ...form, allowed_node_ids: ids })}
                render={(n) => `${n.country ? n.country + " " : ""}${n.name}`}
              />
            </Field>
          </div>
        )}
      </Modal>

      {/* credit */}
      <Modal
        open={!!credit}
        onClose={() => setCredit(null)}
        title={`شارژ حجم — ${credit?.reseller.username || ""}`}
        footer={
          <>
            <button className="btn-ghost" onClick={() => setCredit(null)}>
              انصراف
            </button>
            <button className="btn-primary" onClick={submitCredit} disabled={saving}>
              {saving ? <Spinner /> : "افزودن"}
            </button>
          </>
        }
      >
        {credit && (
          <div className="space-y-4">
            <Field label="حجم (گیگابایت)" hint="عدد منفی حجم را کم می‌کند">
              <input
                type="number"
                className="input"
                value={credit.gb}
                onChange={(e) => setCredit({ ...credit, gb: Number(e.target.value) })}
              />
            </Field>
            <Field label="مبلغ دریافتی (تومان)">
              <input
                type="number"
                className="input"
                value={credit.price}
                onChange={(e) => setCredit({ ...credit, price: Number(e.target.value) })}
              />
            </Field>
            <Field label="توضیح">
              <input
                className="input"
                value={credit.note}
                onChange={(e) => setCredit({ ...credit, note: e.target.value })}
              />
            </Field>
            <p className="text-xs text-ink-400">
              موجودی فعلی:{" "}
              {credit.reseller.traffic_remaining === null
                ? "نامحدود"
                : bytes(credit.reseller.traffic_remaining)}
            </p>
          </div>
        )}
      </Modal>

      {/* ledger */}
      <Modal
        open={!!ledger}
        onClose={() => setLedger(null)}
        title={`تراکنش‌های ${ledger?.reseller.username || ""}`}
        wide
      >
        {!ledger?.items.length ? (
          <Empty text="تراکنشی ثبت نشده است." />
        ) : (
          <table className="w-full">
            <thead className="border-b border-white/5">
              <tr>
                <th className="th">تاریخ</th>
                <th className="th">حجم</th>
                <th className="th">موجودی پس از آن</th>
                <th className="th">مبلغ</th>
                <th className="th">توضیح</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ledger.items.map((t) => (
                <tr key={t.id}>
                  <td className="td text-xs">{dateTime(t.created_at)}</td>
                  <td
                    className={
                      t.amount >= 0 ? "td tabular-nums text-emerald-300" : "td tabular-nums text-rose-300"
                    }
                  >
                    {t.amount >= 0 ? "+" : "−"}
                    {bytes(Math.abs(t.amount))}
                  </td>
                  <td className="td tabular-nums">{bytes(t.balance_after)}</td>
                  <td className="td text-xs">{t.price ? toman(t.price) : "—"}</td>
                  <td className="td text-xs text-ink-400">{t.note || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Modal>
    </div>
  );
}
