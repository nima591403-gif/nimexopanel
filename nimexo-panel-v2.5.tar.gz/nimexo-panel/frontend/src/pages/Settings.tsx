import { useEffect, useState } from "react";

import { Card, Chip, Field, Spinner, Toggle, useToast } from "../components/ui";
import { api } from "../lib/api";
import { duration } from "../lib/format";

interface SystemInfo {
  brand: string;
  version: string;
  python: string;
  platform: string;
  timezone: string;
  sub_base_url: string;
  uptime: number;
}

interface AdminRow {
  id: number;
  username: string;
  role: string;
  is_active: boolean;
}

interface PanelSettings {
  brand_name: string;
  panel_domain: string;
  panel_public_url: string;
  sub_domain: string;
  sub_path: string;
  sub_port: number;
  sub_https: boolean | null;
  sub_profile_title: string;
  sub_base_url: string;
  page_base_url: string;
}

export default function Settings() {
  const toast = useToast();
  const [info, setInfo] = useState<SystemInfo | null>(null);
  const [admins, setAdmins] = useState<AdminRow[]>([]);
  const [panel, setPanel] = useState<PanelSettings | null>(null);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);

  const loadPanel = () =>
    api.get<PanelSettings>("/api/panel-settings").then(setPanel).catch(() => {});

  useEffect(() => {
    api.get<SystemInfo>("/api/system/info").then(setInfo).catch(() => {});
    api.get<AdminRow[]>("/api/admins").then(setAdmins).catch(() => {});
    loadPanel();
  }, []);

  const savePanel = async () => {
    if (!panel) return;
    setBusy(true);
    try {
      const saved = await api.patchPut<PanelSettings>("/api/panel-settings", {
        brand_name: panel.brand_name,
        panel_domain: panel.panel_domain,
        panel_public_url: panel.panel_public_url,
        sub_domain: panel.sub_domain,
        sub_path: panel.sub_path,
        sub_port: Number(panel.sub_port),
        sub_https: panel.sub_https,
        sub_profile_title: panel.sub_profile_title,
      });
      setPanel(saved);
      toast("ذخیره شد — لینک‌های جدید از همین آدرس ساخته می‌شوند");
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const changePassword = async () => {
    setBusy(true);
    try {
      await api.post("/api/auth/change-password", {
        current_password: current,
        new_password: next,
      });
      toast("گذرواژه تغییر کرد");
      setCurrent("");
      setNext("");
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  const maintenance = async (path: string, label: string) => {
    setBusy(true);
    try {
      await api.post(`/api/system/${path}`);
      toast(`${label} انجام شد`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "خطا", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">تنظیمات</h1>
        <p className="mt-1 text-xs text-ink-400">اطلاعات پنل، حساب مدیریت و عملیات نگهداری</p>
      </div>

      <Card
        title="دامنه و لینک اشتراک"
        subtitle="این مقادیر تعیین می‌کنند لینک کاربران با چه آدرسی ساخته شود"
      >
        {!panel ? (
          <Spinner />
        ) : (
          <>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="نام برند">
                <input
                  className="input"
                  value={panel.brand_name}
                  onChange={(e) => setPanel({ ...panel, brand_name: e.target.value })}
                />
              </Field>
              <Field label="دامنه پنل" hint="برای صفحه‌ی کاربر و مستندات">
                <input
                  className="input font-mono"
                  dir="ltr"
                  value={panel.panel_domain}
                  onChange={(e) => setPanel({ ...panel, panel_domain: e.target.value })}
                />
              </Field>
              <Field label="آدرس عمومی پنل" hint="مثلاً https://panel.example.com:2067">
                <input
                  className="input font-mono text-[11px]"
                  dir="ltr"
                  value={panel.panel_public_url}
                  onChange={(e) =>
                    setPanel({ ...panel, panel_public_url: e.target.value })
                  }
                />
              </Field>
              <Field label="دامنه لینک اشتراک" hint="می‌تواند دامنه‌ی سرور ایران باشد">
                <input
                  className="input font-mono"
                  dir="ltr"
                  value={panel.sub_domain}
                  onChange={(e) => setPanel({ ...panel, sub_domain: e.target.value })}
                />
              </Field>
              <Field label="پورت لینک اشتراک" hint="مثلاً ۲۰۹۷">
                <input
                  type="number"
                  className="input"
                  value={panel.sub_port}
                  onChange={(e) => setPanel({ ...panel, sub_port: Number(e.target.value) })}
                />
              </Field>
              <Field label="مسیر لینک" hint="پیش‌فرض sub">
                <input
                  className="input font-mono"
                  dir="ltr"
                  value={panel.sub_path}
                  onChange={(e) => setPanel({ ...panel, sub_path: e.target.value })}
                />
              </Field>
              <Field label="عنوان پروفایل در کلاینت">
                <input
                  className="input"
                  value={panel.sub_profile_title}
                  onChange={(e) =>
                    setPanel({ ...panel, sub_profile_title: e.target.value })
                  }
                />
              </Field>
              <div className="flex items-end">
                <Toggle
                  checked={panel.sub_https === true}
                  onChange={(v) => setPanel({ ...panel, sub_https: v })}
                  label="لینک اشتراک با https"
                />
              </div>
            </div>

            <p className="mt-4 rounded-lg bg-white/5 px-3 py-2 font-mono text-[11px] text-ink-300" dir="ltr">
              {panel.sub_base_url}/&lt;sub_id&gt;
            </p>
            <p className="mt-2 text-[11px] leading-5 text-ink-500">
              پورتی که خود پنل روی آن گوش می‌دهد از فایل{" "}
              <span className="font-mono">/opt/nimexo/.env</span> خوانده می‌شود
              (<span className="font-mono">PORT</span> و{" "}
              <span className="font-mono">SUB_PORT</span>). بعد از تغییر آن‌ها یک‌بار
              <span className="font-mono"> systemctl restart nimexo-panel </span>
              لازم است.
            </p>

            <button className="btn-primary mt-4" onClick={savePanel} disabled={busy}>
              {busy ? <Spinner /> : "ذخیره"}
            </button>
          </>
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="اطلاعات پنل">
          {info ? (
            <dl className="space-y-2 text-sm">
              <Row k="نسخه" v={info.version} />
              <Row k="پایتون" v={info.python} />
              <Row k="سیستم" v={<span className="text-xs">{info.platform}</span>} />
              <Row k="منطقه زمانی" v={info.timezone} />
              <Row k="زمان کارکرد" v={duration(info.uptime)} />
              <Row
                k="آدرس پایه‌ی اشتراک"
                v={<code className="text-[11px]">{info.sub_base_url}</code>}
              />
            </dl>
          ) : (
            <Spinner />
          )}
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("sync-all", "همگام‌سازی همه نودها")}
            >
              همگام‌سازی همه نودها
            </button>
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("collect", "خواندن آمار")}
            >
              خواندن آمار ترافیک
            </button>
            <button
              className="btn-ghost text-xs"
              disabled={busy}
              onClick={() => maintenance("enforce", "بررسی محدودیت‌ها")}
            >
              بررسی انقضا و حجم
            </button>
            <a className="btn-ghost text-xs" href="/api/docs" target="_blank" rel="noreferrer">
              مستندات API
            </a>
          </div>
        </Card>

        <Card title="تغییر گذرواژه">
          <div className="space-y-3">
            <Field label="گذرواژه فعلی">
              <input
                type="password"
                className="input"
                value={current}
                onChange={(e) => setCurrent(e.target.value)}
              />
            </Field>
            <Field label="گذرواژه جدید">
              <input
                type="password"
                className="input"
                value={next}
                onChange={(e) => setNext(e.target.value)}
              />
            </Field>
            <button className="btn-primary" onClick={changePassword} disabled={busy || !next}>
              {busy ? <Spinner /> : "ذخیره"}
            </button>
          </div>
        </Card>
      </div>

      <Card title="مدیران" subtitle="فقط مدیر ارشد می‌تواند مدیران را ببیند و تغییر دهد">
        {admins.length ? (
          <div className="space-y-2">
            {admins.map((a) => (
              <div
                key={a.id}
                className="flex items-center justify-between rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
              >
                <span className="text-sm">{a.username}</span>
                <div className="flex gap-2">
                  <Chip tone="brand">
                    {a.role === "sudo" ? "مدیر ارشد" : a.role === "reseller" ? "نماینده" : "مدیر"}
                  </Chip>
                  <Chip tone={a.is_active ? "green" : "default"}>
                    {a.is_active ? "فعال" : "غیرفعال"}
                  </Chip>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-ink-500">
            دسترسی مدیر ارشد لازم است یا هنوز مدیری ثبت نشده.
          </p>
        )}
      </Card>
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between border-b border-white/5 pb-2">
      <dt className="text-ink-400">{k}</dt>
      <dd>{v}</dd>
    </div>
  );
}
