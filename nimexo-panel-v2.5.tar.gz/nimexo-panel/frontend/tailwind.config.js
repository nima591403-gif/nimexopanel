/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Vazirmatn", "system-ui", "Segoe UI", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
      colors: {
        brand: {
          50: "#f4f0ff",
          100: "#ebe3ff",
          200: "#d9caff",
          300: "#bfa2ff",
          400: "#a06fff",
          500: "#8b3dff",
          600: "#7c22f0",
          700: "#6a17cc",
          800: "#5816a6",
          900: "#491585",
          950: "#2c0a57",
        },
        ink: {
          50: "#f6f6fb",
          100: "#ececf6",
          200: "#d5d5e8",
          300: "#b0b0d0",
          400: "#8484b3",
          500: "#666699",
          600: "#4f4f7d",
          700: "#3f3f64",
          800: "#252540",
          850: "#1b1b33",
          900: "#141428",
          950: "#0b0b1a",
        },
      },
      boxShadow: {
        glow: "0 0 30px -8px rgba(139, 61, 255, 0.55)",
      },
    },
  },
  plugins: [],
};
